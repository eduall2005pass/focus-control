#!/usr/bin/env python3
# Focus Reminder — Ubuntu System Wide (GTK, no extra install)
# Premium redesign: design tokens, clear action hierarchy, full interaction
# states, keyboard support, confirmation for destructive actions.
# - Every 10 min: fullscreen system-wide alert (SKIPPED while ChatGPT/Gemini in use)
# - OpenCode/browser running -> alert MUST appear
# - Actions: Back to Work (primary) / Goal / Emergency Lockout / Study /
#            Power Off (destructive, confirm)
# Auto-started via systemd user service + autostart desktop file.

import atexit
import base64
import email.policy
import fcntl
import glob
import hashlib
import html
import hmac
import json
import math
import os
import re
import secrets
import shutil
import signal
import socket
import sqlite3
import stat
import subprocess
import tempfile
import threading
import time
import unicodedata
import urllib.parse
from email.parser import BytesParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
import gi
gi.require_version("Gtk", "3.0")
try:
    gi.require_foreign("cairo")  # gives Cairo contexts/strokes support
except Exception:
    pass
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf, Gio, Pango

try:
    gi.require_version("WebKit2", "4.1")
    from gi.repository import WebKit2
except Exception:  # WebKit not available -> study view disabled, app still runs
    WebKit2 = None

FOCUS_VERSION = "2.0.27"

FOCUS_MINUTES = 10
SUSPEND_MINUTES = 30
SITE_WINDOW_MINUTES = 15  # study site visited within last N min -> studying

# Deen/study websites — visiting these counts as study, alert is skipped
STUDY_DOMAINS = ["muslimbangla.com"]

OPENCODE_PROCS = "opencode|OpenCode"
BROWSER_PROCS = "chrome|chromium|firefox|brave|msedge|edge"
# Study / teaching essentials — alert NEVER appears while these run
STUDY_PROCS = ("evince|atril|okular|zathura|xournalpp|soffice.bin|libreoffice|"
               "foliate|calibre|mupdf|gazboard|pdfarranger|FoxitReader")

# ---------- whole-device tracking config ----------
TRACK_SAMPLE_SEC = 5             # activity sampling interval
TRACK_IDLE_THRESHOLD_SEC = 120   # inactivity beyond this pauses counting
TRACK_FLUSH_EVERY = 6            # flush ledger every N samples (~30s)
DAILY_WASTE_LIMIT_MIN = 120      # daily non-study limit shown on dashboard
DEFAULT_NON_STUDY = True         # unclassified apps count as non-study
APP_OVERRIDES = {}               # e.g. {"code": "study"} — comm/class -> study|waste
LEDGER_DIR = os.path.expanduser("~/.local/share/focus-reminder")
HOOK_PATH = os.path.join(LEDGER_DIR, "focus-hook.json")
# Optional integration point: any tool/extension may write
# {"app": "msedge", "domain": "youtube.com", "ts": 1730000000} to HOOK_PATH.
# Fresh (<20s) hook data wins over all other providers. Records stay local.

# Rotating motivation: Qur'an (with reference) + study focus quotes
QUOTES = [
    ("By time, indeed mankind is in loss \u2014 except those who believe, "
     "do righteous deeds, and urge one another to truth and patience.",
     "Qur\u2019an 103:1\u20133 (Surah Al-\u02bbAsr)"),
    ("Indeed, with hardship comes ease.",
     "Qur\u2019an 94:6 (Surah Ash-Sharh)"),
    ("And that man shall have nothing but what he strives for.",
     "Qur\u2019an 53:39 (Surah An-Najm)"),
    ("So when you are free from your duties, then stand up for worship. "
     "And to your Lord direct your longing.",
     "Qur\u2019an 94:7\u20138 (Surah Ash-Sharh)"),
    ("Allah does not burden a soul beyond what it can bear.",
     "Qur\u2019an 2:286 (Surah Al-Baqarah)"),
    ("And He found you lost and guided you.",
     "Qur\u2019an 93:7 (Surah Ad-Duha)"),
    ("You don\u2019t have to be great to start, but you have to start to be great.",
     "Zig Ziglar"),
    ("Success is the sum of small efforts, repeated day in and day out.",
     "Robert Collier"),
    ("Don\u2019t watch the clock; do what it does. Keep going.",
     "Sam Levenson"),
]
_quote_index = 0

# ---------- design tokens ----------
NAVY_900 = "#10264a"
NAVY_800 = "#19376d"
NAVY_700 = "#214d86"
BLUE_600 = "#2563eb"
BLUE_700 = "#1d4ed8"
BLUE_100 = "#dbeafe"
BLUE_300 = "#93c5fd"
INK_900 = "#111827"
GRAY_500 = "#475569"
GRAY_400 = "#64748b"
GRAY_300 = "#94a3b8"
LINE = "#e2e8f0"
BG_SOFT = "#f1f5f9"
BTN_NEUTRAL = "#eef2f7"
RED_600 = "#dc2626"
RED_700 = "#b91c1c"
WHITE = "#ffffff"

FONT_TITLE = "Inter, 'Plus Jakarta Sans', Ubuntu, sans-serif"
FONT_BODY = "Inter, 'Plus Jakarta Sans', 'Noto Sans', sans-serif"

SPACE = 8  # 8px spacing base


def build_css(compact=False, animations=True):
    trans = "transition: background 120ms ease, box-shadow 120ms ease;" if animations else ""
    title_size = 24 if compact else 30
    card_pad = 20 if compact else 32
    card_w_note = ""  # width set via set_size_request instead
    return f"""
.window-bg {{ background: linear-gradient(135deg, {NAVY_900} 0%, {NAVY_800} 60%, {NAVY_700} 100%); }}
.card {{
  background: {WHITE};
  border: 1px solid {LINE};
  border-radius: 22px;
  padding: {card_pad}px;
  box-shadow: 0 18px 60px rgba(16, 38, 74, 0.35);
}}
.accent {{
  background: linear-gradient(90deg, {BLUE_600}, #38bdf8);
  border-radius: 4px;
  min-height: 6px;
  min-width: 120px;
}}
.eyebrow {{
  background: {BLUE_100}; color: {BLUE_700};
  font-family: {FONT_BODY}; font-weight: bold; font-size: 12px;
  letter-spacing: 2px;
  border-radius: 20px; padding: 8px 20px;
}}
.prio {{
  background: #fee2e2; color: #b91c1c;
  font-family: {FONT_BODY}; font-weight: bold; font-size: 12px;
  letter-spacing: 2px;
  border-radius: 20px; padding: 8px 20px;
}}
.headline {{
  font-family: {FONT_TITLE}; font-size: {title_size}px; font-weight: 800; color: {INK_900};
}}
.body {{
  font-family: {FONT_BODY}; font-size: 15px; color: {GRAY_500};
}}
.guide {{
  background: {BG_SOFT}; color: #334155;
  font-family: {FONT_BODY}; font-size: 14px;
  border: 1px solid {LINE};
  border-radius: 12px; padding: 14px 18px;
}}
button {{
  font-family: {FONT_BODY}; font-size: 15px;
  border-radius: 12px; padding: 12px 24px;
  {trans}
}}
button:focus {{ outline: 2px solid {BLUE_300}; outline-offset: 2px; }}
.btn-primary {{
  background: linear-gradient(180deg, #2f6df6, {BLUE_700});
  color: white; font-weight: bold;
  box-shadow: 0 6px 20px rgba(37, 99, 235, 0.4);
}}
.btn-primary:hover {{ background: linear-gradient(180deg, #3b78f7, #1e40af); }}
.btn-primary:active {{ background: {BLUE_700}; box-shadow: none; }}
.btn-primary:disabled {{ background: #c7d7f8; color: #f1f5f9; box-shadow: none; }}
.btn-secondary {{
  background: {BTN_NEUTRAL}; color: {INK_900};
  border: 1px solid {LINE};
}}
.btn-secondary:hover {{ background: #e3e9f2; }}
.btn-secondary:active {{ background: #d5dce6; box-shadow: none; }}
.btn-secondary:disabled {{ background: {BG_SOFT}; color: {GRAY_300}; }}
.btn-danger {{
  background: {WHITE}; color: {RED_600};
  border: 1.5px solid {RED_600}; font-weight: bold;
}}
.btn-danger:hover {{ background: {RED_600}; color: white; }}
.btn-danger:active {{ background: {RED_700}; color: white; border-color: {RED_700}; }}
.btn-danger:disabled {{ color: {GRAY_300}; border-color: {LINE}; }}
.caption {{ font-family: {FONT_BODY}; font-size: 12px; color: {GRAY_300}; }}
.goalrow {{
  background: {WHITE};
  border: 1px solid {LINE};
  border-radius: 14px; padding: 12px 16px;
}}
.goaldonerow {{ background: #f8fafc; }}
.goaltext {{ font-family: {FONT_BODY}; font-size: 14px; color: {INK_900}; }}
.goaldone {{ font-family: {FONT_BODY}; font-size: 14px; color: {GRAY_300}; }}
.chip {{
  background: {BG_SOFT}; color: {GRAY_400};
  font-family: {FONT_BODY}; font-size: 12px;
  border: 1px solid {LINE};
  border-radius: 999px; padding: 4px 12px;
}}
.chipdate {{ background: #eff6ff; color: {BLUE_700}; border-color: #bfdbfe; }}
.chiptime {{ background: #fffbeb; color: #b45309; border-color: #fde68a; }}
.tgl {{ font-size: 17px; border-radius: 999px; padding: 4px 9px; }}
.tglplain {{ color: #cbd5e1; }}
.tgldone {{ color: {BLUE_600}; }}
.lockbar {{ min-height: 12px; border-radius: 8px; }}
.unlockat {{ font-family: {FONT_BODY}; font-size: 12px; color: {GRAY_400}; }}
.delbtn {{
  color: {RED_600}; font-family: {FONT_BODY}; font-size: 14px; font-weight: bold;
  border-radius: 8px; padding: 6px 10px;
}}
.delbtn:hover {{ background: #fee2e2; }}
.mini {{
  background: {BTN_NEUTRAL}; color: {INK_900};
  font-family: {FONT_BODY}; font-size: 12px;
  border: 1px solid {LINE}; border-radius: 8px; padding: 6px 10px;
}}
.quote {{
  font-family: {FONT_BODY}; font-size: 14px; font-style: italic; color: {BLUE_700};
}}
.quoteref {{ font-family: {FONT_BODY}; font-size: 12px; color: {GRAY_300}; }}
.lock-time {{
  font-family: {FONT_TITLE}; font-size: 66px; font-weight: 800; color: {INK_900};
}}
.dialog-title {{ font-family: {FONT_TITLE}; font-size: 20px; font-weight: 800; color: {INK_900}; }}
.dash {{
  background: {INK_900};
  border-radius: 14px; padding: 16px 18px;
}}
.dasheye {{
  font-family: {FONT_BODY}; font-size: 11px; font-weight: bold;
  letter-spacing: 2px; color: {BLUE_300};
}}
.dashbig {{
  font-family: {FONT_TITLE}; font-size: 40px; font-weight: 800; color: white;
}}
.dashsub {{ font-family: {FONT_BODY}; font-size: 12px; color: #cbd5e1; }}
.dashrow {{ font-family: {FONT_BODY}; font-size: 13px; color: #e2e8f0; }}
.dashbar {{ min-height: 10px; border-radius: 6px; }}
.dashtop {{ font-family: {FONT_BODY}; font-size: 12px; color: #cbd5e1; }}
""".encode()


def animations_enabled():
    try:
        return Gtk.Settings.get_default().get_property("gtk-enable-animations")
    except Exception:
        return True


def is_compact_screen():
    try:
        d = Gdk.Display.get_default()
        m = d.get_primary_monitor() or d.get_monitor(0)
        g = m.get_geometry()
        return g.width < 1000 or g.height < 750
    except Exception:
        return False

# ---------- helpers ----------

_HOST = ["flatpak-spawn", "--host"] if os.environ.get("FLATPAK_ID") else []


def _run(cmd, **kw):
    """Run a system command; inside Flatpak, execute it on the host."""
    if _HOST:
        cmd = _HOST + list(cmd)
    return subprocess.run(cmd, **kw)  # noqa: direct call intended (avoids recursion)

def notify(msg):
    try:
        _run(["notify-send", "Focus Reminder", msg], timeout=5)
    except Exception:
        pass


def _proc_running(pattern):
    try:
        out = _run(["pgrep", "-x", pattern],
                             capture_output=True, text=True, timeout=5).stdout
        return bool(out.strip())
    except Exception:
        return False


def study_app_running():
    """PDF/document viewer, whiteboard etc. running -> studying, never nag."""
    return _proc_running(STUDY_PROCS)


def must_alert():
    """OpenCode or browser running -> reminder MUST appear, no skip."""
    return _proc_running(OPENCODE_PROCS) or _proc_running(BROWSER_PROCS)


def _query_copy(db_path, query):
    """Copy a (possibly locked) sqlite db to tmp and run query -> first cell or None."""
    tmp = None
    try:
        fd, tmp = tempfile.mkstemp(suffix=".sqlite")
        os.close(fd)
        shutil.copy(db_path, tmp)
        con = sqlite3.connect(f"file:{tmp}?mode=ro", uri=True, timeout=5)
        row = con.execute(query).fetchone()
        con.close()
        return row[0] if row else None
    except Exception:
        return None
    finally:
        try:
            if tmp:
                os.remove(tmp)
        except Exception:
            pass


def _web_recent(domains, window_min):
    """True if any of the domains was visited recently (Chromium + Firefox)."""
    cond = " OR ".join(f"url LIKE '%{d}%'" for d in domains)
    homes = ["google-chrome", "chromium", "BraveSoftware/Brave-Browser", "microsoft-edge"]
    for home in homes:
        for profile in ["Default", "Profile 1", "Profile 2"]:
            p = os.path.expanduser(f"~/.config/{home}/{profile}/History")
            if not os.path.exists(p):
                continue
            latest = _query_copy(p, f"SELECT max(last_visit_time) FROM urls WHERE {cond}")
            if latest:
                unix_ts = latest / 1_000_000 - 11_644_473_600  # Chrome epoch -> unix
                if time.time() - unix_ts < window_min * 60:
                    return True
    for p in glob.glob(os.path.expanduser("~/.mozilla/firefox/*.default*/places.sqlite")):
        latest = _query_copy(
            p, f"SELECT max(visit_date) FROM moz_historyvisits "
               f"JOIN moz_places ON moz_historyvisits.place_id = moz_places.id "
               f"WHERE {cond}")
        if latest:
            if time.time() - latest / 1_000_000 < window_min * 60:
                return True
    return False


def study_site_recent():
    """Deen/study sites (e.g. muslimbangla.com) visited recently -> studying."""
    try:
        return _web_recent(STUDY_DOMAINS, SITE_WINDOW_MINUTES)
    except Exception as e:
        print(f"Study-site check error (fail-open): {e}", flush=True)
        return False


def lock_session():
    try:
        _run(["loginctl", "lock-session"], timeout=10)
    except Exception as e:
        print(f"lock-session failed: {e}", flush=True)


suspend_until = 0
SUSPEND_STATE = os.path.join(LEDGER_DIR, "suspend.state")
PAM_LOCK_FLAG = os.path.join(LEDGER_DIR, "pam-lock-requested")
SHELL_LOCKOUT_FLAG = os.path.join(LEDGER_DIR, "shell-lockout-active")
GTK_LOCKOUT_READY = os.path.join(LEDGER_DIR, "gtk-lockout-ready")
STUDY_ACTIVE_FLAG = os.path.join(LEDGER_DIR, "study-active.flag")
# Written as soon as Study Mode starts loading and cleared when its window maps.
# The Shell extension uses it to lock the desktop down during startup too, so
# the desktop cannot be right-clicked before the fullscreen Study window exists.
STUDY_STARTING_FLAG = os.path.join(LEDGER_DIR, "study-starting.flag")
LOCKOUT_EXTENSION_UUID = "focus-lockout@medisparkbd"
# True while Study Mode hands the screen to an external Edge app window; the
# Study focus guard must not steal focus back until Edge is closed.
EXTERNAL_BROWSER_ACTIVE = False
WIFI_ACTIVE_FLAG = os.path.join(LEDGER_DIR, "wifi-active.flag")
STUDY_SUSPEND_STATE = os.path.join(LEDGER_DIR, "study-suspended.state")
STUDY_VIOLATIONS_STATE = os.path.join(LEDGER_DIR, "study-violations.json")
NEXT_ALERT_STATE = os.path.join(LEDGER_DIR, "next-alert.state")


def _touch_study_active():
    try:
        os.makedirs(LEDGER_DIR, exist_ok=True)
        with open(STUDY_ACTIVE_FLAG, "w") as f:
            f.write(str(time.time()))
    except Exception:
        pass


def _clear_study_active():
    try:
        if os.path.exists(STUDY_ACTIVE_FLAG):
            os.remove(STUDY_ACTIVE_FLAG)
    except Exception:
        pass


def _touch_study_starting():
    try:
        os.makedirs(LEDGER_DIR, exist_ok=True)
        with open(STUDY_STARTING_FLAG, "w") as f:
            f.write(str(time.time()))
    except Exception:
        pass


def _clear_study_starting():
    try:
        if os.path.exists(STUDY_STARTING_FLAG):
            os.remove(STUDY_STARTING_FLAG)
    except Exception:
        pass


def _touch_wifi_active():
    try:
        os.makedirs(LEDGER_DIR, exist_ok=True)
        with open(WIFI_ACTIVE_FLAG, "w") as f:
            f.write(str(time.time()))
    except Exception:
        pass


def _clear_wifi_active():
    try:
        if os.path.exists(WIFI_ACTIVE_FLAG):
            os.remove(WIFI_ACTIVE_FLAG)
    except Exception:
        pass


def _load_next_alert():
    try:
        with open(NEXT_ALERT_STATE) as f:
            return float(f.read().strip())
    except Exception:
        return 0


def _save_next_alert(ts):
    try:
        os.makedirs(LEDGER_DIR, exist_ok=True)
        with open(NEXT_ALERT_STATE, "w") as f:
            f.write(str(float(ts)))
    except Exception as e:
        print(f"next alert save error: {e}", flush=True)
SUSPEND_CHECKPOINT_STATE = os.path.join(LEDGER_DIR, "suspend-checkpoint.json")
LOCKOUT_SCHEDULE_STATE = os.path.join(LEDGER_DIR, "lockout-schedule.json")


def _atomic_write(path, content):
    os.makedirs(LEDGER_DIR, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".focus-state-", dir=LEDGER_DIR)
    try:
        with os.fdopen(fd, "w") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
        dir_fd = os.open(LEDGER_DIR, os.O_RDONLY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _get_study_suspended_until():
    try:
        if os.path.isfile(STUDY_SUSPEND_STATE):
            with open(STUDY_SUSPEND_STATE) as f:
                ts = float(f.read().strip())
            return ts if ts > time.time() else 0.0
    except Exception:
        pass
    return 0.0


def _is_study_suspended():
    until = _get_study_suspended_until()
    if until > time.time():
        return True
    if until > 0:
        try:
            os.remove(STUDY_SUSPEND_STATE)
        except OSError:
            pass
    return False


_last_violation_recorded = 0.0
_study_block_count_updater = None


def _record_input_violation():
    global _last_violation_recorded
    now = time.time()
    if now - _last_violation_recorded < 0.5:
        return _get_recent_violation_count(), False
    _last_violation_recorded = now
    recent = []
    try:
        if os.path.isfile(STUDY_VIOLATIONS_STATE):
            with open(STUDY_VIOLATIONS_STATE) as f:
                recent = [float(t) for t in json.load(f) if now - float(t) <= 300.0]
    except Exception:
        recent = []
    recent.append(now)
    try:
        os.makedirs(LEDGER_DIR, exist_ok=True)
        _atomic_write(STUDY_VIOLATIONS_STATE, json.dumps(recent))
    except Exception as e:
        print(f"violations write error: {e}", flush=True)
    count = len(recent)
    if count >= 10:
        suspend_deadline = now + 30 * 60
        try:
            _atomic_write(STUDY_SUSPEND_STATE, str(float(suspend_deadline)))
        except Exception as e:
            print(f"study suspend write error: {e}", flush=True)
        current_lockout = _load_suspend_state()
        if current_lockout < suspend_deadline:
            _save_suspend_state(suspend_deadline, mode="active")
            _begin_lockout_schedule(30)
        return count, True
    return count, False


def _get_recent_violation_count():
    now = time.time()
    try:
        if os.path.isfile(STUDY_VIOLATIONS_STATE):
            with open(STUDY_VIOLATIONS_STATE) as f:
                return len([float(t) for t in json.load(f) if now - float(t) <= 300.0])
    except Exception:
        pass
    return 0


def _trigger_study_suspension():
    global _study_win
    notify("Study Mode suspended for 30 minutes due to 10 blocked keywords.")
    if _study_win is not None:
        try:
            _study_win.destroy()
        except Exception:
            pass


def _save_suspend_state(ts, mode="active"):
    try:
        os.makedirs(LEDGER_DIR, exist_ok=True)
        now = time.time()
        _atomic_write(SUSPEND_STATE, str(float(ts)))
        schedule = _load_lockout_schedule(ts)
        stage_remaining = None
        if schedule:
            stage = int(schedule.get("stage", 0))
            stage_remaining = max(0.0, float(schedule["stage_start"])
                                  + int(schedule["segments"][stage]) - now)
        checkpoint = {
            "remaining_seconds": max(0.0, float(ts) - now),
            "stage_remaining_seconds": stage_remaining,
            "mode": mode,
            "saved_at": now,
            "schedule": schedule,
        }
        _atomic_write(SUSPEND_CHECKPOINT_STATE, json.dumps(checkpoint))
    except Exception as e:
        print(f"suspend state save error: {e}", flush=True)


def _load_suspend_state():
    try:
        with open(SUSPEND_STATE) as f:
            return float(f.read().strip())
    except Exception:
        return 0


def _restore_suspend_checkpoint():
    """Return the persisted absolute deadline (powered-off time counts too)."""
    end = _load_suspend_state()
    if end <= 0:
        try:
            with open(SUSPEND_CHECKPOINT_STATE) as f:
                checkpoint = json.load(f)
            end = (float(checkpoint.get("saved_at", 0))
                   + max(0.0, float(checkpoint.get("remaining_seconds", 0))))
        except Exception:
            end = 0
    return end


def _consume_pam_lock_flag():
    """Consume the login-time end timestamp written by focus-pam-lock.sh."""
    try:
        with open(PAM_LOCK_FLAG) as f:
            end_ts = float(f.read().strip())
    except Exception:
        return 0
    try:
        os.remove(PAM_LOCK_FLAG)
    except OSError:
        pass  # root may own the PAM-created flag directory
    return end_ts


def _clear_suspend_state():
    for path in (SUSPEND_STATE, SUSPEND_CHECKPOINT_STATE):
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass


def _save_lockout_schedule(schedule):
    try:
        os.makedirs(LEDGER_DIR, exist_ok=True)
        with open(LOCKOUT_SCHEDULE_STATE, "w") as f:
            json.dump(schedule, f)
    except Exception as e:
        print(f"lockout schedule save error: {e}", flush=True)


def _load_lockout_schedule(end_ts=None):
    try:
        with open(LOCKOUT_SCHEDULE_STATE) as f:
            schedule = json.load(f)
        if (isinstance(schedule, dict) and isinstance(schedule.get("segments"), list)
                and schedule["segments"] and 0 <= int(schedule.get("stage", 0))
                < len(schedule["segments"])):
            return schedule
    except Exception:
        pass
    if end_ts is None:
        end_ts = _load_suspend_state()
    seconds = max(0, int(end_ts - time.time()))
    if seconds:
        now = time.time()
        return {"segments": [seconds], "stage": 0, "stage_start": now,
                "origin_start": now}
    return None


def _schedule_end(schedule):
    return float(schedule["stage_start"]) + sum(
        int(x) for x in schedule["segments"][int(schedule["stage"]):])


def _clear_lockout_schedule():
    try:
        if os.path.exists(LOCKOUT_SCHEDULE_STATE):
            os.remove(LOCKOUT_SCHEDULE_STATE)
    except Exception:
        pass


def _begin_lockout_schedule(minutes):
    now = time.time()
    schedule = {"segments": [int(minutes * 60)], "stage": 0, "stage_start": now,
                "origin_start": now}
    _save_lockout_schedule(schedule)
    return now + int(minutes * 60)


def enforce_suspension_until(end_ts):
    """Non-skippable: re-enforce after reboot/poweroff until countdown ends."""
    end_ts = max(float(end_ts or 0), _load_suspend_state())
    if end_ts > _load_suspend_state():
        # PAM and the system boot service may have recovered the deadline from
        # different durable markers. Persist the later one before showing UI.
        _save_suspend_state(end_ts, mode="active")
    _shell_saved = _gnome_lockdown()
    _sigs = _lockout_exe_signatures()
    _lockout_proc_sweep(_sigs)

    # When called from GTK UI/tray, do not block the GTK main event loop.
    # The background systemd enforcer daemon and GNOME Shell extension overlay
    # actively enforce the lockout. Blocking here causes Mutter "Force Quit" dialogs.
    if Gtk.main_level() > 0:
        return

    try:
        while time.time() < end_ts:
            saved_end = _load_suspend_state()
            if saved_end > end_ts:
                end_ts = saved_end
            _lockout_proc_sweep(_sigs)
            time.sleep(0.5)
    except Exception as e:
        print(f"lockout enforce retry: {e}", flush=True)
    finally:
        _gnome_restore(_shell_saved)
        if _load_suspend_state() <= time.time():
            _clear_suspend_state()
            _clear_lockout_schedule()


def do_suspend(minutes=SUSPEND_MINUTES):
    """Start a durable emergency lockout without triggering broken hardware sleep."""
    do_pseudo_lockout(minutes, label="Emergency lockout")


def do_pseudo_lockout(minutes=SUSPEND_MINUTES, label="Focus lockout"):
    """Lock the device for N minutes WITHOUT sleeping (pseudo lockout).

    Device stays powered on but locked/countdown-blocked, so a logout, reboot
    or power-off cannot skip it: the remaining time is checkpointed and
    re-enforced on the next start.
    """
    global suspend_until
    end = _begin_lockout_schedule(minutes)
    suspend_until = end
    _save_suspend_state(end, mode="active")
    notify(f"{label} for {_fmt_short(minutes * 60)}. Device stays on and locked.")
    print(f"{label}: {minutes} min (no sleep) until "
          f"{time.strftime('%H:%M', time.localtime(end))}.", flush=True)
    _shell_saved = _gnome_lockdown()
    _sigs = _lockout_exe_signatures()
    _lockout_proc_sweep(_sigs)

    # When called from GTK UI/tray, do not block the GTK main event loop.
    # The background systemd enforcer daemon and GNOME Shell extension overlay
    # actively enforce the lockout. Blocking here causes Mutter "Force Quit" dialogs.
    if Gtk.main_level() > 0:
        return

    try:
        # GNOME Shell Focus Lockout overlay owns the screen!
        while time.time() < end:
            _lockout_proc_sweep(_sigs)
            time.sleep(0.5)
            cur_end = _load_suspend_state()
            if cur_end > end:
                end = cur_end
    except Exception as e:
        print(f"pseudo lockout error: {e}", flush=True)
    finally:
        _gnome_restore(_shell_saved)
        # Only clear if our own deadline is over (power-off keeps it for restart).
        if _load_suspend_state() <= time.time():
            suspend_until = 0
            _clear_suspend_state()
            _clear_lockout_schedule()
    print("Pseudo lockout ended — normal reminders resumed.", flush=True)


def _shell_overlay_active():
    try:
        return time.time() - os.path.getmtime(SHELL_LOCKOUT_FLAG) <= 5
    except OSError:
        return False


_startup_ready_sent = False


def _systemd_startup_ready():
    """Release GNOME startup only after the lockout window has been shown."""
    global _startup_ready_sent
    if _startup_ready_sent:
        return
    notify_socket = os.environ.get("NOTIFY_SOCKET")
    if not notify_socket:
        return
    try:
        address = ("\0" + notify_socket[1:]
                   if notify_socket.startswith("@") else notify_socket)
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        try:
            sock.connect(address)
            sock.sendall(b"READY=1\nSTATUS=Focus Reminder ready")
        finally:
            sock.close()
        _startup_ready_sent = True
    except Exception as e:
        print(f"systemd startup notification error: {e}", flush=True)


def power_off():
    # Chain: session API (no extra perms) -> system poweroff (may ask password).
    notify("Shutting down...")
    try:
        r = _run(
            ["gdbus", "call", "--session", "--dest", "org.gnome.SessionManager",
             "--object-path", "/org/gnome/SessionManager",
             "--method", "org.gnome.SessionManager.Shutdown"],
            capture_output=True, text=True, timeout=15)
        if r.returncode == 0:
            print("poweroff via SessionManager OK", flush=True)
            return
        print(f"SessionManager.Shutdown failed: {(r.stderr or r.stdout).strip()}", flush=True)
    except Exception as e:
        print(f"SessionManager.Shutdown error: {e}", flush=True)
    try:
        r = _run(
            ["gdbus", "call", "--session", "--dest", "org.gnome.SessionManager",
             "--object-path", "/org/gnome/SessionManager",
             "--method", "org.gnome.SessionManager.RequestShutdown"],
            capture_output=True, text=True, timeout=15)
        if r.returncode == 0:
            print("poweroff via RequestShutdown OK (system dialog shown)", flush=True)
            return
        print(f"RequestShutdown failed: {(r.stderr or r.stdout).strip()}", flush=True)
    except Exception as e:
        print(f"RequestShutdown error: {e}", flush=True)
    try:
        r = _run(["systemctl", "poweroff"],
                           capture_output=True, text=True, timeout=15)
        if r.returncode == 0:
            print("poweroff via systemctl OK", flush=True)
            return
        err = (r.stderr or r.stdout).strip()
    except Exception as e:
        err = str(e)
    print(f"poweroff FAILED: {err}", flush=True)
    notify(f"Power off failed: {err}")

# ---------- whole-device activity tracker ----------
# Honest capability map (GNOME Wayland):
#   idle time      -> org.gnome.Mutter.IdleMonitor (works)
#   screen lock    -> org.gnome.ScreenSaver (works)
#   active X-app   -> xprop on XWayland (partial: native Wayland apps invisible)
#   active domain  -> browser history sampling + optional hook file (no tab API)
#   Introspect.GetWindows is denied on this compositor, so it is NOT used.

STUDY_APP_SET = {s.lower() for s in STUDY_PROCS.split("|")}
BROWSER_APP_SET = {s.lower() for s in BROWSER_PROCS.split("|")}


def _has_display():
    # Service may have started before graphical session — try importing
    # DISPLAY / WAYLAND_DISPLAY from the systemd user environment manager.
    if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
        try:
            out = subprocess.check_output(
                ["systemctl", "--user", "show-environment"],
                timeout=5, text=True, stderr=subprocess.DEVNULL,
            )
            for line in out.splitlines():
                if line.startswith("DISPLAY="):
                    os.environ["DISPLAY"] = line.split("=", 1)[1]
                elif line.startswith("WAYLAND_DISPLAY="):
                    os.environ["WAYLAND_DISPLAY"] = line.split("=", 1)[1]
                elif line.startswith("XAUTHORITY="):
                    os.environ.setdefault("XAUTHORITY", line.split("=", 1)[1])
                elif line.startswith("XDG_RUNTIME_DIR="):
                    os.environ.setdefault("XDG_RUNTIME_DIR", line.split("=", 1)[1])
        except Exception:
            pass

    wayland = os.environ.get("WAYLAND_DISPLAY")
    if wayland:
        wayland_path = (wayland if os.path.isabs(wayland) else
                        os.path.join(os.environ.get("XDG_RUNTIME_DIR", ""), wayland))
        try:
            if stat.S_ISSOCK(os.stat(wayland_path).st_mode):
                return True
        except OSError:
            pass

    display = os.environ.get("DISPLAY", "")
    if display:
        # Local X11/Xwayland displays are usable only after their socket exists.
        # Remote DISPLAY values have no local socket and keep their old behavior.
        local_display = display
        if local_display.startswith("unix:"):
            local_display = local_display[5:]
        if local_display.startswith(":"):
            number = local_display[1:].split(".", 1)[0]
            if number.isdigit():
                try:
                    return stat.S_ISSOCK(os.stat(f"/tmp/.X11-unix/X{number}").st_mode)
                except OSError:
                    return False
        else:
            return True
    return False


def _gtk_display_ready():
    """Initialize GTK only when the imported graphical session is usable."""
    try:
        result = Gtk.init_check([])
        ok = bool(result[0] if isinstance(result, tuple) else result)
        if ok:
            try:
                import gi.overrides.Gtk as ogtk
                ogtk.initialized = True
            except Exception:
                pass
            return True
        return False
    except TypeError:
        try:
            ok = bool(Gtk.init_check())
            if ok:
                try:
                    import gi.overrides.Gtk as ogtk
                    ogtk.initialized = True
                except Exception:
                    pass
                return True
            return False
        except Exception:
            return Gdk.Display.get_default() is not None
    except Exception:
        return Gdk.Display.get_default() is not None


def _idle_ms():
    try:
        out = _run(
            ["gdbus", "call", "--session", "--dest", "org.gnome.Mutter.IdleMonitor",
             "--object-path", "/org/gnome/Mutter/IdleMonitor/Core",
             "--method", "org.gnome.Mutter.IdleMonitor.GetIdletime"],
            capture_output=True, text=True, timeout=5).stdout
        return int("".join(c for c in out if c.isdigit()) or 0)
    except Exception:
        return 0


def _screen_locked():
    try:
        out = _run(
            ["gdbus", "call", "--session", "--dest", "org.gnome.ScreenSaver",
             "--object-path", "/org/gnome/ScreenSaver",
             "--method", "org.gnome.ScreenSaver.GetActive"],
            capture_output=True, text=True, timeout=5).stdout
        return "true" in out.lower()
    except Exception:
        return False


def _xwayland_active():
    """Best-effort active app via XWayland. None when unknown/unsupported."""
    try:
        root = _run(["xprop", "-root", "_NET_ACTIVE_WINDOW"],
                              capture_output=True, text=True, timeout=5).stdout
        if "#" not in root:
            return None
        wid = root.split("#")[-1].strip().split(",")[0].strip()
        if not wid or wid == "0x0":
            return None
        info = _run(["xprop", "-id", wid, "WM_CLASS"],
                              capture_output=True, text=True, timeout=5).stdout
        if "=" not in info or "not found" in info:
            return None
        toks = [t.strip().strip('"') for t in info.split("=", 1)[-1].split(",")]
        return toks[-1].lower() or None
    except Exception:
        return None


def _read_hook():
    """Optional integration: fresh hook file wins. Returns (app, domain) or None."""
    try:
        if not os.path.exists(HOOK_PATH):
            return None
        with open(HOOK_PATH) as f:
            d = json.load(f)
        if time.time() - float(d.get("ts", 0)) > 20:
            return None
        return (str(d.get("app") or "").lower() or None,
                str(d.get("domain") or "").lower() or None)
    except Exception:
        return None


def _last_domain():
    """Most recent history URL's domain across browsers. (domain, ts) or (None, 0)."""
    best, best_ts = None, 0
    homes = ["google-chrome", "chromium", "BraveSoftware/Brave-Browser", "microsoft-edge"]
    for home in homes:
        for profile in ["Default", "Profile 1", "Profile 2"]:
            p = os.path.expanduser(f"~/.config/{home}/{profile}/History")
            if not os.path.exists(p):
                continue
            row = _query_copy(p, "SELECT url, last_visit_time FROM urls "
                                 "ORDER BY last_visit_time DESC LIMIT 1")
            if row:
                ts = row[1] / 1_000_000 - 11_644_473_600
                if ts > best_ts:
                    best_ts = ts
                    best = (urlparse(row[0]).hostname or "").lower()
    for p in glob.glob(os.path.expanduser("~/.mozilla/firefox/*.default*/places.sqlite")):
        row = _query_copy(
            p, "SELECT url, visit_date FROM moz_historyvisits "
               "JOIN moz_places ON moz_historyvisits.place_id = moz_places.id "
               "ORDER BY visit_date DESC LIMIT 1")
        if row:
            ts = row[0] / 1_000_000
            if ts > best_ts:
                best_ts = ts
                best = (urlparse(row[1]).hostname or "").lower()
    return best, best_ts


def classify_app(app):
    a = (app or "").lower()
    if not a:
        return "unknown"
    if a in APP_OVERRIDES:
        return APP_OVERRIDES[a]
    if a in STUDY_APP_SET:
        return "study"
    if a in BROWSER_APP_SET:
        return "browser"
    return "waste" if DEFAULT_NON_STUDY else "study"


def classify_domain(dom):
    # AI is NOT study: only STUDY_DOMAINS count as study, everything else is waste.
    d = (dom or "").lower().lstrip("www.")
    if not d:
        return None
    for s in STUDY_DOMAINS:
        if d == s or d.endswith("." + s):
            return "study"
    return "waste"


def _fmt_hms(sec):
    sec = max(0, int(sec))
    return f"{sec // 3600:02d}:{(sec % 3600) // 60:02d}:{sec % 60:02d}"


def _fmt_short(sec):
    sec = max(0, int(sec))
    if sec >= 3600:
        return f"{sec // 3600}h {(sec % 3600) // 60}m"
    if sec >= 60:
        return f"{sec // 60}m"
    return f"{sec}s"


class Tracker:
    def __init__(self):
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.day = None
        self.agg = {"study": 0, "waste": 0, "by_app": {}, "by_domain": {}}
        self.cur = None          # open segment {start, end, app, domain, cls}
        self.state = "unknown"   # current activity label
        self.state_cls = "unknown"
        self.samples = 0
        self.limit_notified = False
        self.limit_pending = False
        self.domain_cache = (None, 0)  # (domain, checked_at)
        os.makedirs(LEDGER_DIR, exist_ok=True)
        self._load_day(time.strftime("%Y-%m-%d"))

    def _path(self, day):
        return os.path.join(LEDGER_DIR, f"ledger-{day}.json")

    def _load_day(self, day):
        self.day = day
        self.limit_notified = False
        self.limit_pending = False
        self.agg = {"study": 0, "waste": 0, "by_app": {}, "by_domain": {}}
        self.cur = None
        try:
            if os.path.exists(self._path(day)):
                with open(self._path(day)) as f:
                    d = json.load(f)
                for k in ("study", "waste"):
                    self.agg[k] = int(d.get(k, 0))
                self.agg["by_app"] = dict(d.get("by_app", {}))
                self.agg["by_domain"] = dict(d.get("by_domain", {}))
        except Exception as e:
            print(f"ledger load error: {e}", flush=True)

    def flush(self):
        with self.lock:
            day, agg = self.day, self.agg
        try:
            segs = []
            try:
                if os.path.exists(self._path(day)):
                    with open(self._path(day)) as f:
                        segs = json.load(f).get("segments", [])
            except Exception:
                pass
            # note: open segment is NOT stored here; it is finalized into
            # aggregates on the next sample / class change / day rollover.
            with open(self._path(day), "w") as f:
                json.dump({"date": day, "study": agg["study"], "waste": agg["waste"],
                           "by_app": agg["by_app"], "by_domain": agg["by_domain"],
                           "segments": segs[-500:]}, f)
        except Exception as e:
            print(f"ledger flush error: {e}", flush=True)

    def _finalize(self, end):
        c = self.cur
        if not c:
            return
        dur = max(0, end - c["start"])
        if dur > 0 and c["cls"] in ("study", "waste"):
            self.agg[c["cls"]] += int(dur)
            key = c["domain"] or c["app"] or "unknown"
            d = self.agg["by_domain"] if c["domain"] else self.agg["by_app"]
            d[key] = int(d.get(key, 0)) + int(dur)
        self.cur = None

    def _cached_domain(self, now):
        dom, checked = self.domain_cache
        if now - checked > 60:
            try:
                dom, _ = _last_domain()
            except Exception:
                dom = None
            self.domain_cache = (dom, now)
        return self.domain_cache[0]

    def sample(self):
        t = time.time()
        with self.lock:
            if time.strftime("%Y-%m-%d", time.localtime(t)) != self.day:
                self._finalize(t)
                self.flush()
                self._load_day(time.strftime("%Y-%m-%d", time.localtime(t)))
            if not _has_display():
                # boot/service without graphical session: nothing to show, pause
                self._finalize(t)
                self.state, self.state_cls = "No display", "idle"
                return
            if _screen_locked() or _idle_ms() / 1000 > TRACK_IDLE_THRESHOLD_SEC:
                self._finalize(t)
                self.state, self.state_cls = ("Locked", "idle") if _screen_locked() else ("Idle", "idle")
                return
            hook = _read_hook()
            if hook and (hook[0] or hook[1]):
                app, domain = hook
            else:
                app = _xwayland_active()
                domain = None
                if app in BROWSER_APP_SET or _proc_running(BROWSER_PROCS):
                    domain = self._cached_domain(t)
            if domain:
                cls = classify_domain(domain) or "waste"
                label = domain
            elif app:
                c = classify_app(app)
                if c == "browser":
                    d2 = self._cached_domain(t)
                    if d2:
                        cls, label, domain = classify_domain(d2) or "waste", d2, d2
                    else:
                        cls, label = "waste", app + " (browser)"
                elif c == "unknown":
                    cls, label = ("waste", "Unknown") if DEFAULT_NON_STUDY else ("study", "Unknown")
                else:
                    cls, label = c, app
            else:
                cls, label = ("waste", "Unknown") if DEFAULT_NON_STUDY else ("study", "Unknown")
                app = "unknown"
            if self.cur and self.cur["cls"] == cls and self.cur["app"] == (app or "") \
                    and self.cur["domain"] == (domain or ""):
                self.cur["end"] = t
            else:
                self._finalize(t)
                self.cur = {"start": t, "end": t, "app": app or "",
                            "domain": domain or "", "cls": cls}
            self.state, self.state_cls = label, cls
            total_waste = self.agg["waste"]
            if self.cur and self.cur["cls"] == "waste":
                total_waste += int(t - self.cur["start"])
            if total_waste >= DAILY_WASTE_LIMIT_MIN * 60 and not self.limit_notified:
                self.limit_notified = True
                self.limit_pending = True
                print("Daily waste limit crossed.", flush=True)
            self.samples += 1
            if self.samples % TRACK_FLUSH_EVERY == 0:
                self.flush()

    def snapshot(self):
        now = time.time()
        with self.lock:
            waste = self.agg["waste"]
            study = self.agg["study"]
            if self.cur:
                live = max(0, now - self.cur["start"])
                if self.cur["cls"] == "waste":
                    waste += int(live)
                elif self.cur["cls"] == "study":
                    study += int(live)
            return {"waste": waste, "study": study,
                    "state": self.state, "state_cls": self.state_cls,
                    "by_app": dict(self.agg["by_app"]),
                    "by_domain": dict(self.agg["by_domain"])}

    def loop(self):
        while not self.stop_event.is_set():
            try:
                self.sample()
            except Exception as e:
                print(f"tracker sample error: {e}", flush=True)
            self.stop_event.wait(TRACK_SAMPLE_SEC)


_tracker = None


def start_tracker():
    global _tracker
    if _tracker is None:
        _tracker = Tracker()
        atexit.register(_tracker.flush)
        threading.Thread(target=_tracker.loop, daemon=True).start()
    return _tracker


def track_snapshot():
    if _tracker is None:
        return {"waste": 0, "study": 0, "state": "Tracker off",
                "state_cls": "unknown", "by_app": {}, "by_domain": {}}
    return _tracker.snapshot()


# ---------- UI primitives ----------

def _apply_css(win):
    css = Gtk.CssProvider()
    css.load_from_data(build_css(compact=is_compact_screen(),
                                 animations=animations_enabled()))
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )
    win.get_style_context().add_class("window-bg")


def _new_fullscreen(title):
    try:
        import gi.overrides.Gtk as ogtk
        ogtk.initialized = True
    except Exception:
        pass
    win = Gtk.Window(title=title)
    win.fullscreen()
    win.set_keep_above(True)
    win.set_decorated(False)
    win.set_skip_taskbar_hint(True)
    win.set_skip_pager_hint(True)
    win.stick()  # visible on ALL workspaces — never hidden elsewhere
    win.set_position(Gtk.WindowPosition.CENTER)
    return win


# Keys GNOME steals at compositor level (overview/recent/app-switcher).
# Disabled during lockout, restored verbatim afterwards.
_LOCKDOWN_KEYS = [
    ("org.gnome.mutter", "overlay-key", "''"),                       # Super -> overview
    ("org.gnome.desktop.interface", "enable-hot-corners", "false"),  # hot corner
    ("org.gnome.desktop.wm.keybindings", "switch-applications", "@as []"),  # Super+Tab / Alt+Tab
    ("org.gnome.desktop.wm.keybindings", "switch-applications-backward", "@as []"),
    ("org.gnome.desktop.wm.keybindings", "switch-windows", "@as []"),        # Alt+Tab (windows)
    ("org.gnome.desktop.wm.keybindings", "switch-windows-backward", "@as []"),
    ("org.gnome.desktop.wm.keybindings", "panel-run-dialog", "@as []"),      # Alt+F2
    ("org.gnome.desktop.wm.keybindings", "unmaximize", "@as []"),            # Super+Down shrink
    ("org.gnome.desktop.wm.keybindings", "begin-move", "@as []"),            # Alt+F7 move
    ("org.gnome.desktop.wm.keybindings", "begin-resize", "@as []"),          # Alt+F8 resize
    ("org.gnome.shell.keybindings", "toggle-overview", "@as []"),            # Super+S
    ("org.gnome.shell.keybindings", "toggle-application-view", "@as []"),    # Super+A
    ("org.gnome.desktop.notifications", "show-banners", "false"),  # banners can launch apps
]


def _gnome_lockdown():
    """Disable shell-escape keys. Returns saved (schema, key, raw) list for restore."""
    saved = []
    for schema, key, locked_val in _LOCKDOWN_KEYS:
        try:
            r = _run(["gsettings", "get", schema, key],
                     capture_output=True, text=True, timeout=10)
            raw = r.stdout.strip() if r.returncode == 0 else None
        except Exception as e:
            print(f"lockdown get {schema} {key}: {e}", flush=True)
            raw = None
        if raw is None:
            continue
        saved.append((schema, key, raw))
        try:
            _run(["gsettings", "set", schema, key, locked_val], timeout=10)
        except Exception as e:
            print(f"lockdown set {schema} {key}: {e}", flush=True)
    for dext in ("ubuntu-dock@ubuntu.com", "ding@rastersoft.com",
                 "gtk4-ding@smedius.gitlab.com", "desktop-icons@csoriano",
                 "desktop-icons-ng@rastersoft.com"):
        try:
            _run(["gnome-extensions", "disable", dext], timeout=5)
        except Exception:
            pass
    try:
        _run(["pkill", "-9", "-f", "dingManager.js|adw-ding|gtk4-ding"], timeout=5)
    except Exception:
        pass
    try:
        _run(["pkill", "-9", "-f", "gnome-control-center|gnome-tweaks"], timeout=5)
    except Exception:
        pass
    try:
        _run(["pkill", "-9", "-f", "agetty"], timeout=5)
        _run(["pkill", "-9", "-x", "login"], timeout=5)
    except Exception:
        pass
    return saved


def _gnome_restore(saved):
    for schema, key, raw in saved:
        try:
            _run(["gsettings", "set", schema, key, raw], timeout=10)
        except Exception as e:
            print(f"lockdown restore {schema} {key}: {e}", flush=True)
    for dext in ("ubuntu-dock@ubuntu.com", "ding@rastersoft.com",
                 "gtk4-ding@smedius.gitlab.com"):
        try:
            _run(["gnome-extensions", "enable", dext], timeout=5)
        except Exception:
            pass
    try:
        p_backup = os.path.expanduser("~/.local/share/focus-reminder/panels-backup.json")
        if os.path.exists(p_backup):
            os.remove(p_backup)
    except Exception:
        pass


def _gnome_heal():
    """Self-heal stale lockdown (crash/reboot during lockout left keys off)."""
    defaults = {
        ("org.gnome.mutter", "overlay-key"): "'Super'",
        ("org.gnome.desktop.wm.keybindings", "switch-applications"): "['<Super>Tab']",
        ("org.gnome.desktop.wm.keybindings", "switch-windows"): "['<Alt>Tab']",
        ("org.gnome.desktop.notifications", "show-banners"): "true",
    }
    for (schema, key), good in defaults.items():
        try:
            r = _run(["gsettings", "get", schema, key],
                     capture_output=True, text=True, timeout=10)
            cur = r.stdout.strip() if r.returncode == 0 else None
        except Exception:
            cur = None
        if cur is None or cur == good:
            continue
        locked_look = cur in ("''", "@as []", "false")
        if locked_look:
            try:
                _run(["gsettings", "set", schema, key, good], timeout=10)
                print(f"self-heal: restored {schema} {key}", flush=True)
            except Exception as e:
                print(f"self-heal failed {schema} {key}: {e}", flush=True)
    try:
        _run(["gnome-extensions", "enable", "ubuntu-dock@ubuntu.com"], timeout=5)
    except Exception:
        pass
    try:
        _run(["gnome-extensions", "enable", "ding@rastersoft.com"], timeout=5)
    except Exception:
        pass
    try:
        p_backup = os.path.expanduser("~/.local/share/focus-reminder/panels-backup.json")
        if os.path.exists(p_backup):
            os.remove(p_backup)
    except Exception:
        pass


_last_extension_check = 0.0


def _ensure_shell_extension_enabled(force=False):
    """Re-enable the Shell lockout extension if it was switched off during a
    lockout or Study Mode. Best-effort; throttled because it runs from the
    1-second sweeps."""
    global _last_extension_check
    now = time.time()
    if not force and now - _last_extension_check < 2.5:
        return
    _last_extension_check = now
    try:
        r = _run(["gsettings", "get", "org.gnome.shell", "enabled-extensions"],
                 capture_output=True, text=True, timeout=5)
        if r.returncode == 0 and LOCKOUT_EXTENSION_UUID in (r.stdout or ""):
            return
    except Exception:
        pass
    try:
        _run(["gnome-extensions", "enable", LOCKOUT_EXTENSION_UUID], timeout=8)
        print("self-heal: re-enabled Shell lockout extension", flush=True)
    except Exception as e:
        print(f"self-heal: could not enable Shell lockout extension: {e}", flush=True)


# Binaries that must not run while the device is suspended (browsers, which can
# open anything incl. AI agents; terminals/VT-launched shells; AI CLIs).
# Matched by exact basename of argv[0] — never by substring, never self.
LOCKOUT_PROC_DENY = frozenset({
    "chrome", "google-chrome", "google-chrome-stable", "chromium",
    "chromium-browser", "ungoogled-chromium", "firefox", "firefox-esr",
    "brave", "brave-browser", "msedge", "microsoft-edge", "opera",
    "vivaldi", "torbrowser", "tor-browser", "zen", "floorp",
    "librewolf", "waterfox", "epiphany", "qutebrowser", "falkon",
    "midori",
    "gnome-terminal", "gnome-terminal-server", "ptyxis", "ptyxis-agent", "kgx",
    "xterm", "konsole", "alacritty", "kitty", "tilix", "terminator", "wezterm",
    "foot", "x-terminal-emulator",
    "opencode", "claude", "gemini", "aichat", "tgpt", "sgpt",
    "codex", "cursor-agent", "aider", "ollama", "kilo", ".kilo", "cline",
    "cursor", "copilot", "agy", "windsurf", "trae", "amazon-q",
    "roocode", "continue", "goose", "goose-cli",
    "openhands", "crush", "amp", "devin", "cody", "tabby",
    "junie", "kiro", "antigravity",
    "gnome-control-center", "gnome-settings", "gnome-tweaks", "dconf-editor",
    "gnome-extensions-app", "gnome-shell-extension-prefs",
    "extension-manager", "gnome-shell-extension-manager",
    "systemsettings", "systemsettings5", "kdesystemsettings",
    "xfce4-settings-manager", "software-properties-gtk", "update-manager",
    "agetty", "login", "sulogin",
})


def _lockout_exe_signatures():
    """One-time fingerprint of denylisted binaries: basenames, (dev, ino)
    pairs (catches renames/hardlinks), and size->sha256 (catches copies).
    Built once per lockout so renames/copies/spoofs can't dodge the sweep."""
    names, inos, hashes = set(), set(), {}
    dirs = (os.environ.get("PATH", "").split(":")
            + [os.path.expanduser("~/.local/bin"),
               os.path.expanduser("~/.opencode/bin")])
    seen = set()
    for name in LOCKOUT_PROC_DENY:
        names.add(name)
        for d in dirs:
            # real binary by PATH name (often our shim) + shadowed-aside real binary
            for p in (os.path.join(d, name),
                      os.path.join(d, "." + name + ".focus-real")):
                if p in seen:
                    continue
                seen.add(p)
                try:
                    if not os.path.exists(p):
                        continue
                    st = os.stat(p)
                    if not stat.S_ISREG(st.st_mode):
                        continue
                    inos.add((st.st_dev, st.st_ino))
                    h = hashlib.sha256()
                    with open(p, "rb") as f:
                        for chunk in iter(lambda: f.read(65536), b""):
                            h.update(chunk)
                    hashes.setdefault(st.st_size, set()).add(h.hexdigest())
                except Exception:
                    pass
    return {"inos": inos, "hashes": hashes}


def _exe_matches(exe, st, sigs):
    """True if a /proc/PID/exe target is a denylisted binary in any disguise."""
    try:
        if os.path.basename(exe.split(" (deleted)")[0]).lower() in LOCKOUT_PROC_DENY:
            return True
        if (st.st_dev, st.st_ino) in sigs["inos"]:
            return True
        cands = sigs["hashes"].get(st.st_size)
        if cands:
            h = hashlib.sha256()
            with open(exe, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            if h.hexdigest() in cands:
                return True
    except Exception:
        pass
    return False


def _lockout_proc_sweep(sigs=None):
    """SIGKILL denylisted processes, however disguised. Best-effort;
    skips self and unowned PIDs."""
    me = os.getpid()
    # Study Mode opens NotebookLM/websites in Microsoft Edge app windows; those
    # must survive the lockout sweep while the study window is open.
    study_active = os.path.exists(STUDY_ACTIVE_FLAG)
    if (study_active or os.path.exists(STUDY_STARTING_FLAG)
            or _load_suspend_state() > time.time()):
        # The desktop right-click menu can open Settings -> Extensions and
        # disable the Shell overlay. Put it back if that happened.
        _ensure_shell_extension_enabled()
    try:
        pids = [p for p in os.listdir("/proc") if p.isdigit()]
    except Exception:
        return
    for pid in pids:
        try:
            if int(pid) == me:
                continue
            exe = os.readlink(f"/proc/{pid}/exe")
            exe_name = os.path.basename(exe.split(" (deleted)")[0]).lower()
            if "ibus" in os.path.basename(exe) or "input-method" in exe:
                continue  # never kill input methods (Avro/Bengali typing)
            if study_active and exe_name in (
                    "msedge", "microsoft-edge", "microsoft-edge-stable"):
                continue
            st = os.stat(exe)
            if _exe_matches(exe, st, sigs or {"inos": set(), "hashes": {}}):
                os.kill(int(pid), signal.SIGKILL)
                continue
            # Also catch node/python wrappers and AI agents/terminals by cmdline
            try:
                with open(f"/proc/{pid}/cmdline", "rb") as f:
                    cmd_raw = f.read().decode("utf-8", errors="ignore").lower()
                if any(w in cmd_raw for w in (
                    "kilo", "@kilocode", ".kilo", "ptyxis", "gnome-terminal", "kgx",
                    "opencode", "claude", "aider", "ollama", "windsurf"
                )):
                    os.kill(int(pid), signal.SIGKILL)
                    continue
            except Exception:
                pass
        except Exception:
            pass


def _swallow_shell_keys(win):
    """App-level backup: swallow Super / Alt+Tab if compositor passes them through."""
    def _on_key(_w, ev):
        try:
            if ev.keyval in (Gdk.KEY_Super_L, Gdk.KEY_Super_R):
                return True
            mods = ev.state & Gtk.accelerator_get_default_mod_mask()
            if mods & Gdk.ModifierType.MOD1_MASK and ev.keyval in (
                    Gdk.KEY_Tab, Gdk.KEY_ISO_Left_Tab):
                return True
        except Exception:
            pass
        return False
    win.connect("key-press-event", _on_key)


def _arm_focus_guard(win, is_lockout=False):
    """Re-raise + re-fullscreen the window if anything steals focus or shrinks it."""
    def _reassert():
        try:
            if not win.get_visible():
                return
            if EXTERNAL_BROWSER_ACTIVE:
                return
            if is_lockout and _typing_win is not None:
                return
            active = win.is_active() or win.has_toplevel_focus()
            if active:
                # If a text field or an inline TreeView editor currently owns
                # the cursor, leave it alone. Re-presenting the toplevel here
                # is what was kicking the cursor out of Reading History edits.
                focus = win.get_focus()
                while focus is not None:
                    if isinstance(focus, Gtk.Entry):
                        return
                    focus = focus.get_parent()
            gdkwin = win.get_window()
            if (gdkwin is not None
                    and not (gdkwin.get_state() & Gdk.WindowState.FULLSCREEN)):
                win.fullscreen()
            # Never call present() while the window/to entry already has
            # focus: doing that every 500 ms steals the cursor from Gtk.Entry
            # widgets and inline TreeView cell editors (Reading History).
            if not active:
                win.present()
        except Exception:
            pass

    def _on_focus_out(*_):
        GLib.idle_add(_reassert)
        return False
    win.connect("focus-out-event", _on_focus_out)

    def _guard():
        _reassert()
        return True
    return GLib.timeout_add(500, _guard)


def _new_card(width=None):
    if width is None:
        width = 560 if is_compact_screen() else 880
    outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    outer.set_halign(Gtk.Align.CENTER)
    outer.set_valign(Gtk.Align.CENTER)
    card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2 * SPACE)
    card.get_style_context().add_class("card")
    card.set_size_request(width, -1)
    card.set_margin_top(20); card.set_margin_bottom(20)
    card.set_margin_start(20); card.set_margin_end(20)
    outer.add(card)
    return outer, card


def _accent():
    a = Gtk.Box()
    a.get_style_context().add_class("accent")
    a.set_halign(Gtk.Align.CENTER)
    a.set_size_request(120, 6)
    return a


def _eyebrow(text):
    e = Gtk.Label(label=text)
    e.get_style_context().add_class("eyebrow")
    e.set_halign(Gtk.Align.CENTER)
    return e


def _sudo_check(pw):
    """Verify the system (sudo) password. Never stored or logged."""
    try:
        if not pw:
            return False
        r = _run(["sudo", "-S", "-v"], input=pw + "\n",
                           capture_output=True, text=True, timeout=30)
        return r.returncode == 0
    except Exception as e:
        print(f"sudo verify error: {e}", flush=True)
        return False


def confirm_dialog(parent, title, heading, message, ok_label, danger=True,
                   passcode=None):
    """Modal confirmation. passcode: None | 'verify' | 'set'. Returns True only deliberate Confirm."""
    dlg = Gtk.Dialog(title=title, transient_for=parent, modal=True)
    dlg.set_keep_above(True)
    dlg.set_skip_taskbar_hint(True)
    try:
        dlg.get_content_area().set_spacing(12)
        dlg.get_content_area().set_margin_top(20)
        dlg.get_content_area().set_margin_bottom(8)
        dlg.get_content_area().set_margin_start(24)
        dlg.get_content_area().set_margin_end(24)
    except Exception:
        pass
    t = Gtk.Label(label=heading)
    t.get_style_context().add_class("dialog-title")
    t.set_halign(Gtk.Align.START)
    m = Gtk.Label(label=message)
    m.get_style_context().add_class("body")
    m.set_halign(Gtk.Align.START)
    dlg.get_content_area().pack_start(t, False, False, 0)
    dlg.get_content_area().pack_start(m, False, False, 0)
    btn_cancel = dlg.add_button("Cancel", Gtk.ResponseType.CANCEL)
    btn_ok = dlg.add_button(ok_label, Gtk.ResponseType.OK)
    if danger:
        btn_ok.get_style_context().add_class("btn-danger")
    else:
        btn_ok.get_style_context().add_class("btn-primary")
    btn_cancel.get_style_context().add_class("btn-secondary")
    err = Gtk.Label(label="")
    err.get_style_context().add_class("caption")
    pin_entry = None
    if passcode == "verify":
        plab = Gtk.Label(label="Enter system (sudo) password:")
        plab.get_style_context().add_class("body")
        plab.set_halign(Gtk.Align.START)
        dlg.get_content_area().pack_start(plab, False, False, 0)
        pin_entry = Gtk.Entry()
        pin_entry.set_visibility(False)
        pin_entry.set_max_length(64)
        pin_entry.set_placeholder_text("System password")
        dlg.get_content_area().pack_start(pin_entry, False, False, 0)
    dlg.get_content_area().pack_start(err, False, False, 0)
    dlg.set_default_response(Gtk.ResponseType.CANCEL)  # Enter = safe, Esc = cancel
    dlg.show_all()
    if pin_entry:
        pin_entry.grab_focus()
        pin_entry.connect("activate", lambda *_: dlg.response(Gtk.ResponseType.OK))
    while True:
        resp = dlg.run()
        if resp != Gtk.ResponseType.OK:
            dlg.destroy()
            return False
        if passcode == "verify":
            pw = pin_entry.get_text()
            pin_entry.set_text("")
            if _sudo_check(pw):
                del pw
                dlg.destroy()
                return True
            err.set_text("Wrong system password — try again.")
        else:
            dlg.destroy()
            return True


def confirm_power_off(parent):
    """Modal confirmation. Returns True only on deliberate Confirm."""
    return confirm_dialog(parent, "Confirm Power Off", "Power off this device?",
                          "The machine will shut down immediately.\nUnsaved work may be lost.",
                          "\u23fb  Power Off", danger=True)


def confirm_suspend(parent, label):
    """Emergency lockout confirmation WITH system-password check."""
    return confirm_dialog(parent, "Confirm Emergency Lockout",
                          f"Start emergency lockout {label}?",
                          "The screen stays on so this computer does not get stuck in sleep.\nThe countdown resumes after a power-off or restart.",
                          "\u23f8  Start Lockout", danger=False, passcode="verify")

TYPING_DIR = os.path.expanduser("~/Documents/typing test")
GOALS_PATH = os.path.join(LEDGER_DIR, "goals.json")


def _load_goals():
    try:
        with open(GOALS_PATH) as f:
            d = json.load(f)
        return d if isinstance(d, list) else []
    except Exception:
        return []


def _save_goals(goals):
    try:
        os.makedirs(LEDGER_DIR, exist_ok=True)
        with open(GOALS_PATH, "w") as f:
            json.dump(goals, f)
    except Exception as e:
        print(f"goals save error: {e}", flush=True)


def _add_goal(text, date, time_):
    goals = _load_goals()
    goals.append({"id": time.time_ns(), "text": text.strip(),
                  "date": date.strip(), "time": time_.strip(),
                  "done": False, "created": time.time()})
    _save_goals(goals)


def _toggle_goal(gid):
    goals = _load_goals()
    for g in goals:
        if g.get("id") == gid:
            g["done"] = not g.get("done")
    _save_goals(goals)


def _delete_goal(gid):
    _save_goals([g for g in _load_goals() if g.get("id") != gid])


_typing_win = None
_typing_view = None
_typing_parent = None
_typing_auto_closing = False

_study_win = None
_study_parent = None
_study_auto_closing = False


def _save_typing_text(text):
    """Save typing content. Returns path or None. Visible errors via notify."""
    if not (text or "").strip():
        notify("Nothing to save yet.")
        return None
    try:
        os.makedirs(TYPING_DIR, exist_ok=True)
        path = os.path.join(TYPING_DIR, time.strftime("typing-%Y%m%d-%H%M%S.txt"))
        with open(path, "w") as f:
            f.write(text)
        notify(f"Typing saved: {os.path.basename(path)}")
        return path
    except Exception as e:
        print(f"typing save error: {e}", flush=True)
        notify("Typing save failed.")
        return None


def _close_typing_autosave():
    """Called when lockout ends while typing is open: autosave + close all typing UI."""
    global _typing_auto_closing
    if _typing_win is None:
        return
    try:
        buf = _typing_view.get_buffer()
        text = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), True)
        if text.strip():
            _save_typing_text(text)
            print("typing autosaved on lockout end.", flush=True)
    except Exception as e:
        print(f"typing autosave error: {e}", flush=True)
    _typing_auto_closing = True
    try:
        _typing_win.destroy()  # destroy, NOT close (delete-event is blocked)
    except Exception:
        pass


def show_typing_test(parent=None):
    """Fullscreen black typing practice inside lockout. Suspension continues."""
    global _typing_win, _typing_view, _typing_parent, _typing_auto_closing
    _typing_auto_closing = False
    if parent is not None:
        _typing_parent = parent
        try:
            parent.hide()  # lockout steps aside so typing is visible + focused
        except Exception:
            pass
    win = _new_fullscreen("Typing Test")
    _typing_win = win
    win.set_modal(True)
    _swallow_shell_keys(win)
    _tguard = _arm_focus_guard(win)
    css = Gtk.CssProvider()
    css.load_from_data(b"""
    .typewin { background: #000000; }
    .typehead { font-family: Inter, sans-serif; font-size: 13px; color: #9ca3af;
                letter-spacing: 2px; font-weight: bold; }
    textview text { background: #000000; color: #e5e7eb;
                    font: 20px Monospace; padding: 24px; }
    """)
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    win.get_style_context().add_class("typewin")
    win.connect("delete-event", lambda *_: True)  # Alt+F4 blocked; use Back/Esc
    outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
    outer.set_margin_top(30); outer.set_margin_bottom(30)
    outer.set_margin_start(40); outer.set_margin_end(40)
    head = Gtk.Label(label="TYPING TEST \u2014 LOCKED MODE (SUSPENSION CONTINUES)")
    head.get_style_context().add_class("typehead")
    head.set_halign(Gtk.Align.CENTER)
    scroll = Gtk.ScrolledWindow()
    scroll.set_hexpand(True); scroll.set_vexpand(True)
    view = Gtk.TextView()
    view.set_wrap_mode(Gtk.WrapMode.WORD)
    view.set_accepts_tab(True)
    scroll.add(view)
    _typing_view = view
    _tbuf = view.get_buffer()
    _block_note = Gtk.Label()
    _block_note.set_markup('<span foreground="#fca5a5">\u26d4 Focus Input Filter: '
                           'explicit content blocked</span>')
    _block_note.get_style_context().add_class("typehead")
    _block_note.set_halign(Gtk.Align.CENTER)
    _block_note.set_no_show_all(True)

    _good_text = {"v": ""}

    def _typing_filter(buf, _loc, text, _length):
        try:
            inserted = text or ""
            existing = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), True)
            if not _explicit_hit(existing + inserted):
                _good_text["v"] = existing + inserted
                return False
            try:
                buf.stop_emission_by_name("insert-text")  # do not let it land
            except Exception:
                pass
            if len(inserted) == 1:
                def _trim():
                    cur = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), True)
                    cut = len(cur)
                    while cut > 0 and not cur[cut - 1].isspace():
                        cut -= 1
                    if cut < len(cur):
                        buf.set_text(cur[:cut])
                        buf.place_cursor(buf.get_end_iter())
                    return False
                GLib.idle_add(_trim)
            else:
                good = _good_text["v"]
                def _revert():
                    buf.set_text(good)
                    buf.place_cursor(buf.get_end_iter())
                    return False
                GLib.idle_add(_revert)
            _block_note.show()
            Gdk.beep()
            GLib.timeout_add_seconds(3, lambda: (_block_note.hide(), False)[1])
        except Exception:
            pass
        return False

    _tbuf.connect("insert-text", _typing_filter)
    def _sync_good_text(buf):
        try:
            current = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), True)
            if not _explicit_hit(current):
                _good_text["v"] = current
        except Exception:
            pass

    _tbuf.connect("changed", _sync_good_text)
    status_lbl = Gtk.Label(label="Type above. Save keeps a .txt copy.")
    status_lbl.get_style_context().add_class("typehead")
    status_lbl.set_halign(Gtk.Align.CENTER)
    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
    row.set_halign(Gtk.Align.CENTER)
    save_btn = Gtk.Button(label="Save")
    save_btn.get_style_context().add_class("btn-primary")
    save_btn.set_size_request(140, 46)
    back_btn = Gtk.Button(label="Back to Lockout")
    back_btn.get_style_context().add_class("btn-ghost")
    back_btn.set_size_request(180, 46)

    def _save(*_):
        buf = view.get_buffer()
        text = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), True)
        path = _save_typing_text(text)
        if path:
            try:
                status_lbl.set_text(f"Saved {os.path.basename(path)} ✓  ({time.strftime('%H:%M:%S')})")
            except Exception:
                pass
        else:
            try:
                status_lbl.set_text("Nothing saved — type something first.")
            except Exception:
                pass
    def _back_to_lockout():
        if _typing_parent is not None:
            try:
                _typing_parent.show()
                _typing_parent.present()
                while Gtk.events_pending():
                    Gtk.main_iteration_do(False)
            except Exception:
                pass
        win.destroy()

    save_btn.connect("clicked", _save)
    back_btn.connect("clicked", lambda *_: _back_to_lockout())

    def _on_key(_w, ev):
        try:
            if ev is not None and ev.keyval == Gdk.KEY_Escape:
                _back_to_lockout()
                return True
        except Exception:
            pass
        return False
    win.connect("key-press-event", _on_key)
    row.pack_start(save_btn, False, False, 0)
    row.pack_start(back_btn, False, False, 0)
    outer.pack_start(head, False, False, 0)
    outer.pack_start(_block_note, False, False, 0)
    outer.pack_start(scroll, True, True, 0)
    outer.pack_start(status_lbl, False, False, 0)
    outer.pack_start(row, False, False, 0)
    win.add(outer)

    _tsigs = _lockout_exe_signatures()
    _lockout_proc_sweep(_tsigs)
    _tsweep = GLib.timeout_add_seconds(
        1, lambda: (_lockout_proc_sweep(_tsigs), True)[1])

    def _on_typing_destroy(*_):
        global _typing_win, _typing_view, _typing_parent
        try:
            GLib.source_remove(_tguard)
        except Exception:
            pass
        try:
            GLib.source_remove(_tsweep)
        except Exception:
            pass
        auto = _typing_auto_closing
        _typing_win = None
        _typing_view = None
        if not auto and _typing_parent is not None:
            try:
                _typing_parent.show()
                _typing_parent.present()
            except Exception:
                pass
        _typing_parent = None
        Gtk.main_quit()
    win.connect("destroy", _on_typing_destroy)
    win.show_all()
    win.present()
    view.grab_focus()
    Gtk.main()


def _suspend_value_dialog(title, label, minimum, maximum, step=1, is_combo=False):
    """Small dialog returning chosen int, or None on cancel."""
    dlg = Gtk.Dialog(title=title, modal=True)
    dlg.set_keep_above(True)
    dlg.set_skip_taskbar_hint(True)
    try:
        dlg.get_content_area().set_spacing(12)
        dlg.get_content_area().set_margin_top(20)
        dlg.get_content_area().set_margin_bottom(12)
        dlg.get_content_area().set_margin_start(24)
        dlg.get_content_area().set_margin_end(24)
    except Exception:
        pass
    lab = Gtk.Label(label=label)
    lab.get_style_context().add_class("body")
    lab.set_halign(Gtk.Align.START)
    dlg.get_content_area().pack_start(lab, False, False, 0)
    if is_combo:
        widget = Gtk.ComboBoxText()
        for i in range(minimum, maximum + 1):
            widget.append_text(f"{i} day{'s' if i > 1 else ''}")
        widget.set_active(0)
        get_val = lambda: widget.get_active() + minimum
    else:
        widget = Gtk.SpinButton.new_with_range(minimum, maximum, step)
        widget.set_value(minimum)
        get_val = lambda: int(widget.get_value())
    dlg.get_content_area().pack_start(widget, False, False, 0)
    dlg.add_button("Cancel", Gtk.ResponseType.CANCEL)
    dlg.add_button("Suspend", Gtk.ResponseType.OK)
    dlg.set_default_response(Gtk.ResponseType.OK)
    dlg.show_all()
    resp = dlg.run()
    val = get_val() if resp == Gtk.ResponseType.OK else None
    dlg.destroy()
    return val


_chosen_suspend_minutes = None


def _take_chosen_minutes():
    global _chosen_suspend_minutes
    m = _chosen_suspend_minutes or SUSPEND_MINUTES
    _chosen_suspend_minutes = None
    return m


def _choice_dialog(parent):
    """Emergency length choice. Returns 'minutes'|'hours'|'days'|None."""
    dlg = Gtk.Dialog(title="Emergency Lockout", transient_for=parent, modal=True)
    dlg.set_keep_above(True)
    dlg.set_skip_taskbar_hint(True)
    try:
        dlg.get_content_area().set_spacing(12)
        dlg.get_content_area().set_margin_top(20)
        dlg.get_content_area().set_margin_bottom(12)
        dlg.get_content_area().set_margin_start(24)
        dlg.get_content_area().set_margin_end(24)
    except Exception:
        pass
    lab = Gtk.Label(label="Choose suspension length:")
    lab.get_style_context().add_class("body")
    lab.set_halign(Gtk.Align.START)
    dlg.get_content_area().pack_start(lab, False, False, 0)
    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
    row.set_halign(Gtk.Align.CENTER)
    dlg.get_content_area().pack_start(row, False, False, 0)
    b_min = Gtk.Button(label="Minutes")
    b_min.get_style_context().add_class("btn-secondary")
    b_hr = Gtk.Button(label="Hours")
    b_hr.get_style_context().add_class("btn-secondary")
    b_day = Gtk.Button(label="Days")
    b_day.get_style_context().add_class("btn-secondary")
    for b in (b_min, b_hr, b_day):
        b.set_size_request(110, 44)
        row.pack_start(b, False, False, 0)
    b_min.connect("clicked", lambda *_: dlg.response(1))
    b_hr.connect("clicked", lambda *_: dlg.response(2))
    b_day.connect("clicked", lambda *_: dlg.response(3))
    dlg.add_button("Cancel", Gtk.ResponseType.CANCEL)
    dlg.show_all()
    resp = dlg.run()
    dlg.destroy()
    return {1: "minutes", 2: "hours", 3: "days"}.get(resp)


def pick_suspend_duration(parent):
    """Same flow as tray Emergency Lockout. Returns minutes or None. Pure (no execution)."""
    choice = _choice_dialog(parent)
    if choice == "minutes":
        v = _suspend_value_dialog("Suspend Minutes", "Suspend for how many minutes? (max 60)", 1, 60)
        if v and confirm_suspend(parent, f"for {v} minute{'s' if v > 1 else ''}"):
            return v
    elif choice == "hours":
        v = _suspend_value_dialog("Suspend Hours", "Suspend for how many hours? (max 24)", 1, 24)
        if v and confirm_suspend(parent, f"for {v} hour{'s' if v > 1 else ''}"):
            return v * 60
    elif choice == "days":
        v = _suspend_value_dialog("Suspend Days", "Suspend for how many days? (max 7)", 1, 7, is_combo=True)
        if not v:
            return None
        label = f"for {v} day{'s' if v > 1 else ''}"
        if not confirm_suspend(parent, label + " — confirm (1/2)"):
            return None
        if not confirm_suspend(parent, label + " — FINAL confirm (2/2)"):
            return None
        return v * 24 * 60
    return None


def tray_suspend_minutes():
    v = _suspend_value_dialog("Suspend Minutes", "Suspend for how many minutes? (max 60)", 1, 60)
    if v and confirm_suspend(None, f"for {v} minute{'s' if v > 1 else ''}"):
        do_suspend(v)


def tray_suspend_hours():
    v = _suspend_value_dialog("Suspend Hours", "Suspend for how many hours? (max 24)", 1, 24)
    if v and confirm_suspend(None, f"for {v} hour{'s' if v > 1 else ''}"):
        do_suspend(v * 60)


def tray_suspend_days(parent=None):
    v = _suspend_value_dialog("Suspend Days", "Suspend for how many days? (max 7)", 1, 7, is_combo=True)
    if not v:
        return
    label = f"for {v} day{'s' if v > 1 else ''}"
    if not confirm_suspend(parent, label + " — confirm (1/2)"):
        return
    if not confirm_suspend(parent, label + " — FINAL confirm (2/2)"):
        return
    do_suspend(v * 24 * 60)


def _tray_show_reminder():
    try:
        action = show_alert()
    except Exception as e:
        print(f"tray reminder error: {e}", flush=True)
        return
    print(f"tray reminder action={action}", flush=True)
    if action == "suspend":
        do_suspend(_take_chosen_minutes())
    elif action == "study":
        show_study_window()
    elif action == "poweroff":
        power_off()
    elif action == "goal":
        try:
            show_goal_manager()
        except Exception as e:
            print(f"goal manager error: {e}", flush=True)


def build_tray_menu():
    menu = Gtk.Menu()

    def _item(label, cb, sensitive=True):
        it = Gtk.MenuItem(label=label)
        it.set_sensitive(sensitive)
        it.connect("activate", lambda *_: cb())
        menu.append(it)
        return it

    sub = Gtk.Menu()
    for label, cb in (("Minutes\u2026 (max 60)", tray_suspend_minutes),
                      ("Hours\u2026 (max 24)", tray_suspend_hours),
                      ("Days\u2026 (max 7, double confirm)", lambda: tray_suspend_days())):
        mi = Gtk.MenuItem(label=label)
        mi.connect("activate", lambda *_w, f=cb: f())
        sub.append(mi)
    root = Gtk.MenuItem(label="\u23f8  Emergency Lockout (screen stays on)")
    root.set_submenu(sub)
    menu.append(root)
    lock_item = Gtk.MenuItem(label="\U0001F512  Focus Lockout 30 min (no sleep)")
    lock_item.connect("activate", lambda *_: do_pseudo_lockout(SUSPEND_MINUTES))
    menu.append(lock_item)
    menu.append(Gtk.SeparatorMenuItem())
    def _waste_text():
        try:
            with open(os.path.join(LEDGER_DIR, f"ledger-{time.strftime('%Y-%m-%d')}.json")) as f:
                d = json.load(f)
            return f"Waste today: {_fmt_short(d.get('waste', 0))}"
        except Exception:
            return "Waste today: \u2014"

    waste_item = _item(_waste_text(), lambda: None, sensitive=False)

    def _refresh_waste(*_):
        try:
            waste_item.set_label(_waste_text())
        except Exception:
            pass
        return True

    menu.connect("show", lambda *_: _refresh_waste())  # refresh on every open
    GLib.timeout_add_seconds(30, _refresh_waste)  # + live refresh every 30s
    _item("📚  Study Mode", show_study_window)
    _item("Show Reminder Now", _tray_show_reminder)
    # NOTE: no Quit item by design — the tray stays persistent (see xdg-desktop-focus-compliance-enforcer-8f2e1a9c-tray.service).
    menu.show_all()
    return menu


def tray_loop():
    """Top-bar tray ONLY (persistent, no quit, no separate button).
    Waits for the AppIndicator package instead of falling back."""
    while not _has_display() or not _gtk_display_ready():
        print("Tray waiting for a usable graphical display…", flush=True)
        time.sleep(3)

    def _tray_bye(*_):
        # Exit immediately instead of waiting for systemd's 10s stop timeout.
        os._exit(0)

    signal.signal(signal.SIGTERM, _tray_bye)
    signal.signal(signal.SIGINT, _tray_bye)
    try:
        # Keep a Python callback ticking so the handler runs inside Gtk.main().
        GLib.timeout_add(200, lambda: True)
    except Exception:
        pass
    _AI = None
    while True:
        if _AI is None:
            try:
                import gi
                gi.require_version("AyatanaAppIndicator3", "0.1")
                from gi.repository import AyatanaAppIndicator3 as _AI
            except Exception as e:
                print("Tray waiting for AppIndicator package "
                      "(run: sudo apt install gir1.2-ayatanaappindicator3-0.1). "
                      f"({e})", flush=True)
                time.sleep(60)
                continue
        try:
            ind = _AI.Indicator.new("focus-reminder", "focus-reminder",
                                    _AI.IndicatorCategory.APPLICATION_STATUS)
            ind.set_status(_AI.IndicatorStatus.ACTIVE)
            ind.set_menu(build_tray_menu())
            print("Tray: top-bar indicator active.", flush=True)
            Gtk.main()  # returns only if our own dialog quit it wrongly; rebuild guard below
        except Exception as e:
            print(f"tray error: {e}", flush=True)
        time.sleep(10)


# ---------- main reminder ----------

def _goal_rows_box(interactive=False, on_change=None, limit=None):
    """Modern goals preview rows. Interactive (manager) or read-only (alert/lockout)."""
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=SPACE)
    goals = _load_goals()
    if not goals:
        e = Gtk.Label(label="No goals yet \u2014 open Goal Manager to add.")
        e.get_style_context().add_class("caption")
        e.set_halign(Gtk.Align.CENTER)
        box.pack_start(e, False, False, 0)
        return box
    shown = goals if not limit else goals[:limit]
    for g in shown:
        done = bool(g.get("done"))
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=int(1.5 * SPACE))
        row.get_style_context().add_class("goalrow")
        if done:
            row.get_style_context().add_class("goaldonerow")
        if interactive:
            tgl = Gtk.Button(label="\u25cf" if done else "\u25cb")
            tgl.get_style_context().add_class("tgl")
            tgl.get_style_context().add_class("tgldone" if done else "tglplain")
            tgl.set_tooltip_text("Mark done / undone")
            tgl.connect("clicked", lambda *_w, i=g.get("id"): (_toggle_goal(i), on_change()))
            row.pack_start(tgl, False, False, 0)
        else:
            st = Gtk.Label()
            st.set_markup(f"<span color='#16a34a'>\u25cf</span>" if done
                          else f"<span color='#2563eb'>\u25cb</span>")
            row.pack_start(st, False, False, 0)
        txt = Gtk.Label()
        txt.set_halign(Gtk.Align.START)
        txt.set_hexpand(True)
        txt.set_line_wrap(True)
        esc = GLib.markup_escape_text(g.get("text", ""))
        txt.set_markup(f"<s>{esc}</s>" if done else esc)
        txt.get_style_context().add_class("goaldone" if done else "goaltext")
        row.pack_start(txt, True, True, 0)
        for chip_txt, chip_cls in ((g.get("date", ""), "chipdate"),
                                   (g.get("time", ""), "chiptime")):
            if chip_txt:
                ch = Gtk.Label(label=chip_txt)
                ch.get_style_context().add_class("chip")
                ch.get_style_context().add_class(chip_cls)
                row.pack_start(ch, False, False, 0)
        if interactive:
            dele = Gtk.Button(label="\u2715")
            dele.get_style_context().add_class("delbtn")
            dele.set_tooltip_text("Delete goal")
            dele.connect("clicked", lambda *_w, i=g.get("id"): (_delete_goal(i), on_change()))
            row.pack_start(dele, False, False, 0)
        box.pack_start(row, False, False, 0)
    if limit and len(goals) > limit:
        more = Gtk.Label(label=f"+{len(goals) - limit} more in Goal Manager")
        more.get_style_context().add_class("caption")
        more.set_halign(Gtk.Align.CENTER)
        box.pack_start(more, False, False, 0)
    return box


def show_goal_manager():
    """Fullscreen goal manager: Goal | Date | Time inputs + live modern preview."""
    win = _new_fullscreen("Goal Manager")
    _apply_css(win)
    outer, card = _new_card(720)

    badge = _eyebrow("GOAL MANAGER")
    title = Gtk.Label(label="Set Your Goals")
    title.get_style_context().add_class("headline")
    title.set_halign(Gtk.Align.CENTER)
    sub = Gtk.Label(label="Plan with date and time. The preview below updates live.")
    sub.get_style_context().add_class("body")
    sub.set_halign(Gtk.Align.CENTER)

    form = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=SPACE)
    form.set_halign(Gtk.Align.FILL)
    goal_entry = Gtk.Entry()
    goal_entry.set_placeholder_text("Goal — e.g. Finish physics chapter 5")
    goal_entry.set_hexpand(True)
    goal_entry.set_halign(Gtk.Align.FILL)
    date_entry = Gtk.Entry()
    date_entry.set_placeholder_text("YYYY-MM-DD")
    date_entry.set_width_chars(12)
    date_entry.set_max_length(10)
    time_entry = Gtk.Entry()
    time_entry.set_placeholder_text("HH:MM")
    time_entry.set_width_chars(7)
    time_entry.set_max_length(5)
    form.pack_start(goal_entry, True, True, 0)
    form.pack_start(date_entry, False, False, 0)
    form.pack_start(time_entry, False, False, 0)

    quick = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=SPACE)
    quick.set_halign(Gtk.Align.CENTER)
    today_btn = Gtk.Button(label="Today")
    today_btn.get_style_context().add_class("mini")
    today_btn.connect("clicked", lambda *_: date_entry.set_text(time.strftime("%Y-%m-%d")))
    now_btn = Gtk.Button(label="Now")
    now_btn.get_style_context().add_class("mini")
    now_btn.connect("clicked", lambda *_: time_entry.set_text(time.strftime("%H:%M")))
    add_btn = Gtk.Button(label="+  Add Goal")
    add_btn.get_style_context().add_class("btn-primary")
    add_btn.set_size_request(150, 44)
    quick.pack_start(today_btn, False, False, 0)
    quick.pack_start(now_btn, False, False, 0)
    quick.pack_start(add_btn, False, False, 0)

    err = Gtk.Label(label="")
    err.get_style_context().add_class("caption")
    err.set_halign(Gtk.Align.CENTER)

    scroll = Gtk.ScrolledWindow()
    scroll.set_min_content_height(220)
    scroll.set_vexpand(True)
    scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    glist = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=SPACE)
    scroll.add(glist)

    def refresh():
        for c in list(glist.get_children()):
            glist.remove(c)
        glist.pack_start(_goal_rows_box(interactive=True, on_change=refresh), False, False, 0)
        glist.show_all()

    def _add(*_):
        if not goal_entry.get_text().strip():
            err.set_text("Write a goal first.")
            goal_entry.grab_focus()
            return
        err.set_text("")
        _add_goal(goal_entry.get_text(), date_entry.get_text(), time_entry.get_text())
        goal_entry.set_text("")
        date_entry.set_text("")
        time_entry.set_text("")
        goal_entry.grab_focus()
        refresh()
    add_btn.connect("clicked", _add)
    goal_entry.connect("activate", _add)

    close_btn = Gtk.Button(label="Close")
    close_btn.get_style_context().add_class("btn-ghost")
    close_btn.set_size_request(140, 46)
    close_btn.set_halign(Gtk.Align.CENTER)
    close_btn.connect("clicked", lambda *_: win.close())  # destroy quits once

    for w in (_accent(), badge, title, sub, form, quick, err, scroll, close_btn):
        card.pack_start(w, False, False, 0)
    win.add(outer)
    win.connect("destroy", lambda *_: Gtk.main_quit())
    win.show_all()
    win.present()
    refresh()
    goal_entry.grab_focus()
    Gtk.main()


def show_alert():
    """Fullscreen alert. Returns: close | goal | suspend | study | poweroff."""
    result = {"action": "close", "done": False, "tick": None}

    def _stop_tick():
        if result.get("tick"):
            try:
                GLib.source_remove(result["tick"])
            except Exception:
                pass
            result["tick"] = None

    buttons = []

    def choose(action):
        def _cb(*_):
            if result["done"]:  # prevent double activation
                return
            result["done"] = True
            for b in buttons:
                b.set_sensitive(False)
            if action == "poweroff":
                for b in buttons:
                    b.set_sensitive(True)
                result["done"] = False
                if confirm_power_off(win):
                    result["action"] = "poweroff"
                    win.close()  # destroy handler performs the single main_quit
                return
            if action == "emergency":
                global _chosen_suspend_minutes
                for b in buttons:
                    b.set_sensitive(True)
                result["done"] = False
                m = pick_suspend_duration(win)
                if m:
                    _chosen_suspend_minutes = m
                    result["action"] = "suspend"
                    win.close()  # destroy handler performs the single main_quit
                return
            result["action"] = action
            win.close()  # destroy handler performs the single main_quit
        return _cb

    global _quote_index
    qtext, qref = QUOTES[_quote_index % len(QUOTES)]
    _quote_index += 1

    win = _new_fullscreen("Focus Reminder")
    _apply_css(win)
    outer, card = _new_card()

    badge = _eyebrow("PROFESSIONAL REMINDER")

    prio = Gtk.Label(label="\u25cf PRIORITY")
    prio.get_style_context().add_class("prio")
    prio.set_halign(Gtk.Align.CENTER)
    prio.set_tooltip_text("Your priority work comes first.")
    topbadges = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=SPACE)
    topbadges.set_halign(Gtk.Align.CENTER)
    topbadges.pack_start(badge, False, False, 0)
    topbadges.pack_start(prio, False, False, 0)

    title = Gtk.Label(label="Stop. Refocus on Your Priority Work.")
    title.get_style_context().add_class("headline")
    title.set_halign(Gtk.Align.CENTER)
    title.set_line_wrap(True)
    title.set_justify(Gtk.Justification.CENTER)

    # single bottom action row: all 4 buttons in one line (frees vertical space)
    row_all = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=SPACE)
    row_all.set_halign(Gtk.Align.CENTER)
    close_btn = Gtk.Button(label="\u2713  Back to Work")
    close_btn.get_style_context().add_class("btn-primary")
    close_btn.set_size_request(185, 48)
    close_btn.set_tooltip_text("Dismiss this reminder and restart the 10-minute focus cycle. (Enter)")
    close_btn.set_can_default(True)
    close_btn.connect("clicked", choose("close"))
    goal_btn = Gtk.Button(label="\u25ce  Goal")
    goal_btn.get_style_context().add_class("btn-secondary")
    goal_btn.set_size_request(115, 48)
    goal_btn.set_tooltip_text("Open the Goal Manager to plan tasks with dates.")
    goal_btn.connect("clicked", choose("goal"))
    suspend_btn = Gtk.Button(label="\u23f8  Emergency Lockout")
    suspend_btn.get_style_context().add_class("btn-secondary")
    suspend_btn.set_size_request(135, 48)
    suspend_btn.set_tooltip_text(
        "Start an emergency lockout for minutes, hours or days. Screen stays on; password required.")
    suspend_btn.connect("clicked", choose("emergency"))
    study_btn = Gtk.Button(label="\U0001F4DA  Study")
    study_btn.get_style_context().add_class("btn-secondary")
    study_btn.set_size_request(135, 48)
    study_btn.set_tooltip_text("Open Study mode without starting a device lockout.")
    study_btn.connect("clicked", choose("study"))
    if _is_study_suspended():
        until = _get_study_suspended_until()
        rem_m = max(1, int(math.ceil((until - time.time()) / 60.0)))
        study_btn.set_sensitive(False)
        study_btn.set_label(f"📚 Study Suspended ({rem_m}m)")
        study_btn.set_tooltip_text(f"Study Mode is suspended due to blocked keywords. Available in {rem_m}m.")
    power_btn = Gtk.Button(label="\u23fb  Power Off")
    power_btn.get_style_context().add_class("btn-danger")
    power_btn.set_size_request(125, 48)
    power_btn.set_tooltip_text("Shut down this machine. Requires confirmation.")
    power_btn.connect("clicked", choose("poweroff"))
    for b in (close_btn, goal_btn, suspend_btn, study_btn, power_btn):
        row_all.pack_start(b, False, False, 0)

    hint = Gtk.Label(label="Study opens whitelisted links and your own PDFs without locking this device. "
                           "Emergency Lockout keeps this device on and countdown-locked.")
    hint.get_style_context().add_class("caption")
    hint.set_halign(Gtk.Align.CENTER)
    hint.set_line_wrap(True)

    buttons.extend([close_btn, goal_btn, suspend_btn, study_btn, power_btn])

    for w in (_accent(), topbadges, title):
        card.pack_start(w, False, False, 0)

    goals_head = Gtk.Label(label="MY GOALS \u2014 edit in Goal Manager")
    goals_head.get_style_context().add_class("caption")
    goals_head.set_halign(Gtk.Align.CENTER)
    goalsbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=int(0.5 * SPACE))
    goalsbox.set_halign(Gtk.Align.FILL)
    goalsbox.set_hexpand(True)
    goalsbox.pack_start(goals_head, False, False, 0)
    goals_scroll = Gtk.ScrolledWindow()
    goals_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    goals_scroll.set_min_content_height(120)
    goals_scroll.set_max_content_height(240 if is_compact_screen() else 420)
    goals_scroll.set_halign(Gtk.Align.FILL)
    goals_scroll.set_hexpand(True)
    goals_scroll.set_vexpand(True)
    goals_scroll.add(_goal_rows_box(interactive=False, limit=30))
    goalsbox.pack_start(goals_scroll, True, True, 0)
    card.pack_start(goalsbox, True, True, 0)

    card.pack_start(row_all, False, False, int(0.75 * SPACE))
    card.pack_start(hint, False, False, 0)

    if is_compact_screen():
        # narrow/short viewport: stack all actions vertically, full width
        for _c in list(row_all.get_children()):
            row_all.remove(_c)
        card.remove(row_all)
        stack = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=SPACE)
        stack.set_halign(Gtk.Align.FILL)
        for b in buttons:
            b.set_size_request(0, 48)
            b.set_hexpand(True)
            b.set_halign(Gtk.Align.FILL)
            stack.pack_start(b, False, False, 0)
        card.pack_start(stack, False, False, 0)
        card.reorder_child(stack, 4)
        card.reorder_child(hint, 5)

    def _on_destroy(*_):
        _stop_tick()
        Gtk.main_quit()

    win.add(outer)
    win.connect("destroy", _on_destroy)
    win.show_all()
    win.present()  # force to front
    win.set_default(close_btn)   # Enter triggers primary
    close_btn.grab_focus()       # keyboard focus starts on primary
    try:
        print("\a", flush=True)
    except Exception:
        pass
    Gtk.main()
    return result["action"]


def _build_network_panel(parent_win=None, toast_fn=None):
    toast = toast_fn or (lambda msg: notify(msg))
    network_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=9)
    network_panel.set_size_request(340, 360)
    network_panel.get_style_context().add_class("netpanel")
    net_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
    net_title = Gtk.Label(label="WI-FI NETWORKS")
    net_title.get_style_context().add_class("nettitle")
    net_title.set_halign(Gtk.Align.START)
    net_title.set_hexpand(True)
    net_refresh = Gtk.Button(label="↻  Scan")
    net_refresh.get_style_context().add_class("webnavbtn")
    net_header.pack_start(net_title, True, True, 0)
    net_header.pack_end(net_refresh, False, False, 0)
    network_panel.pack_start(net_header, False, False, 0)

    net_status = Gtk.Label(label="Ready to scan")
    net_status.get_style_context().add_class("netstatus")
    net_status.set_halign(Gtk.Align.START)
    net_status.set_line_wrap(True)
    network_panel.pack_start(net_status, False, False, 0)
    net_wifi_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
    net_wifi_text = Gtk.Label(label="Wi-Fi")
    net_wifi_text.get_style_context().add_class("netrowname")
    net_wifi_text.set_halign(Gtk.Align.START)
    net_wifi_text.set_hexpand(True)
    net_wifi_switch = Gtk.Switch()
    net_wifi_row.pack_start(net_wifi_text, True, True, 0)
    net_wifi_row.pack_end(net_wifi_switch, False, False, 0)
    network_panel.pack_start(net_wifi_row, False, False, 0)
    net_disconnect = Gtk.Button(label="Disconnect")
    net_disconnect.get_style_context().add_class("webnavbtn")
    net_disconnect.set_halign(Gtk.Align.START)
    net_disconnect.set_sensitive(False)
    network_panel.pack_start(net_disconnect, False, False, 0)
    network_panel.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL),
                             False, False, 0)
    net_scroll = Gtk.ScrolledWindow()
    net_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    net_scroll.set_min_content_height(180)
    net_scroll.set_vexpand(True)
    net_list = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
    net_scroll.add(net_list)
    network_panel.pack_start(net_scroll, True, True, 0)

    net_state = {"updating": False, "active": None, "device": None}

    def _net_fields(line):
        fields, value, escaped = [], [], False
        for char in line:
            if escaped:
                value.append({"n": "\n", "r": "\r", "t": "\t"}.get(char, char))
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == ":":
                fields.append("".join(value))
                value = []
            else:
                value.append(char)
        fields.append("".join(value))
        return fields

    def _net_clear():
        for child in net_list.get_children():
            net_list.remove(child)

    def _net_message(message):
        label = Gtk.Label(label=message)
        label.get_style_context().add_class("netstatus")
        label.set_halign(Gtk.Align.START)
        label.set_line_wrap(True)
        net_list.pack_start(label, False, False, 5)

    def _net_scan_done(enabled, active, device, entries, error):
        net_refresh.set_sensitive(True)
        net_wifi_switch.set_sensitive(True)
        if enabled is not None:
            net_state["updating"] = True
            net_wifi_switch.set_active(enabled)
            net_state["updating"] = False
        net_state["active"], net_state["device"] = active, device
        net_disconnect.set_sensitive(bool(active and device))
        net_status.set_text(error or (f"Connected to {active}" if active else
                                      ("Choose a network to connect" if enabled else "Wi-Fi is off")))
        _net_clear()
        if error:
            _net_message(error)
        elif enabled and not entries:
            _net_message("No networks found yet. Keep this panel open and tap Scan again.")
        elif not enabled:
            _net_message("Turn on Wi-Fi to scan for networks.")
        else:
            for ssid, security, signal, connected, saved_profile in entries:
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                row.get_style_context().add_class("netrow")
                info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
                title = Gtk.Label(label=ssid)
                title.set_xalign(0)
                title.set_ellipsize(Pango.EllipsizeMode.END)
                title.get_style_context().add_class("netrowname")
                kind = "Secured" if security and security not in ("--", "") else "Open"
                detail_text = ("Saved Wi-Fi profile" if saved_profile else
                               f"{kind} · Signal {signal}%")
                detail = Gtk.Label(label=detail_text)
                detail.set_xalign(0)
                detail.get_style_context().add_class("netmeta")
                info.pack_start(title, False, False, 0)
                info.pack_start(detail, False, False, 0)
                info.set_hexpand(True)
                row.pack_start(info, True, True, 0)
                action = Gtk.Button(label="Connected" if connected else "Connect")
                action.get_style_context().add_class("webnavbtn")
                action.set_sensitive(not connected)
                action.connect("clicked", lambda _b, s=ssid, sec=security, saved=saved_profile:
                               _net_connect(s, sec, saved_profile=saved))
                row.pack_end(action, False, False, 0)
                net_list.pack_start(row, False, False, 0)
        net_list.show_all()
        return False

    def _net_scan(*_):
        net_refresh.set_sensitive(False)
        net_status.set_text("Scanning nearby networks…")
        _net_clear()
        _net_message("Scanning…")
        net_list.show_all()

        def _work():
            try:
                scan_error_message = None
                radio = _run(["nmcli", "-t", "radio", "wifi"],
                             capture_output=True, text=True, timeout=8)
                if radio.returncode:
                    raise RuntimeError((radio.stderr or "NetworkManager is unavailable").strip())
                enabled = (radio.stdout or "").strip().lower() == "enabled"
                device, active = None, None
                devs = _run(["nmcli", "-t", "-f", "DEVICE,TYPE", "device", "status"],
                            capture_output=True, text=True, timeout=8)
                if devs.returncode == 0:
                    for line in (devs.stdout or "").splitlines():
                        fields = _net_fields(line)
                        if len(fields) > 1 and fields[1] in ("wifi", "802-11-wireless"):
                            device = fields[0]
                            break
                conns = _run(["nmcli", "-t", "-f", "NAME,TYPE,DEVICE",
                              "connection", "show", "--active"],
                             capture_output=True, text=True, timeout=8)
                if conns.returncode == 0:
                    for line in (conns.stdout or "").splitlines():
                        fields = _net_fields(line)
                        if len(fields) >= 3 and fields[1] in ("wifi", "802-11-wireless"):
                            active, device = fields[0], fields[2]
                            break
                entries = []
                if enabled:
                    fields = "IN-USE,SSID,SECURITY,SIGNAL"

                    def _read_wifi_list(command):
                        result = _run(command, capture_output=True, text=True, timeout=20)
                        if result.returncode:
                            return [], (result.stderr or result.stdout or
                                        "Could not list Wi-Fi networks").strip()
                        best = {}
                        for line in (result.stdout or "").splitlines():
                            row = _net_fields(line)
                            if len(row) < 4 or not row[1].strip():
                                continue
                            in_use, ssid, security, strength_text = row[:4]
                            try:
                                strength = int(strength_text)
                            except ValueError:
                                strength = 0
                            key = (ssid, security)
                            used = in_use.strip() == "*"
                            if key not in best or strength > best[key][2] or used:
                                best[key] = (ssid, security, strength, used, False)
                        found = sorted(best.values(), key=lambda item: (
                            not item[3], -item[2], item[0].casefold()))
                        return found, None

                    base = ["nmcli", "-t", "--escape", "yes", "-f", fields,
                            "device", "wifi", "list", "--rescan", "yes"]
                    listing_command = base + (["ifname", device] if device else [])
                    entries, scan_error = _read_wifi_list(listing_command)
                    if not entries:
                        fallback_commands = [base]
                        if device:
                            fallback_commands.append(base + ["ifname", device])
                        fallback_commands.append([
                            "nmcli", "-t", "--escape", "yes", "-f", fields,
                            "device", "wifi", "list", "--rescan", "no"])
                        last_error = scan_error
                        for command in fallback_commands:
                            entries, fallback_error = _read_wifi_list(command)
                            if entries:
                                break
                            last_error = fallback_error or last_error
                    saved_result = _run(
                        ["nmcli", "-t", "--escape", "yes", "-f", "NAME,TYPE",
                         "connection", "show"], capture_output=True, text=True,
                        timeout=10)
                    if saved_result.returncode == 0:
                        present = {item[0] for item in entries}
                        for line in (saved_result.stdout or "").splitlines():
                            fields = _net_fields(line)
                            if (len(fields) >= 2
                                    and fields[1] in ("802-11-wireless", "wifi")
                                    and fields[0] not in present):
                                entries.append((fields[0], "saved", None,
                                                fields[0] == active, True))
                                present.add(fields[0])
                    if not entries and scan_error and last_error:
                        print(f"Wi-Fi scan detail: {last_error}", flush=True)
                        scan_error_message = last_error
                GLib.idle_add(_net_scan_done, enabled, active, device, entries,
                              scan_error_message)
            except Exception as exc:
                print(f"Wi-Fi scan failed: {exc}", flush=True)
                GLib.idle_add(_net_scan_done, None, None, None, [], str(exc))
        threading.Thread(target=_work, daemon=True).start()

    def _net_operation(args, input_text=None, message="Network updated"):
        net_refresh.set_sensitive(False)
        net_wifi_switch.set_sensitive(False)
        net_status.set_text("Updating network…")

        def _work():
            try:
                result = _run(["nmcli", *args], input=input_text,
                              capture_output=True, text=True, timeout=35)
                error = None if result.returncode == 0 else (
                    result.stderr or result.stdout or "Network operation failed").strip()
            except Exception as exc:
                error = str(exc)
            def _finish():
                if error:
                    net_status.set_text(error)
                    toast(f"Network: {error}")
                else:
                    toast(message)
                _net_scan()
                return False
            GLib.idle_add(_finish)
        threading.Thread(target=_work, daemon=True).start()

    def _net_connect(ssid, security, saved_profile=False):
        if saved_profile:
            _net_operation(["--wait", "25", "connection", "up", "id", ssid],
                           message=f"Connected to {ssid}")
            return
        secured = bool(security and security not in ("--", ""))
        password = None
        if secured:
            dialog = Gtk.Dialog(title=f"Connect to {ssid}", transient_for=parent_win, modal=True)
            dialog.set_default_size(340, -1)
            area = dialog.get_content_area()
            area.set_spacing(10)
            area.set_margin_top(16); area.set_margin_bottom(12)
            area.set_margin_start(18); area.set_margin_end(18)
            prompt = Gtk.Label(label=f"Enter the Wi-Fi password for {ssid}")
            prompt.set_halign(Gtk.Align.START)
            entry = Gtk.Entry()
            entry.set_visibility(False)
            entry.set_activates_default(True)
            entry.set_placeholder_text("Wi-Fi password")
            area.pack_start(prompt, False, False, 0)
            area.pack_start(entry, False, False, 0)
            dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
            dialog.add_button("Connect", Gtk.ResponseType.OK)
            dialog.set_default_response(Gtk.ResponseType.OK)
            dialog.show_all()
            if dialog.run() == Gtk.ResponseType.OK:
                password = entry.get_text()
            entry.set_text("")
            dialog.destroy()
            if not password:
                return
        args = ["--wait", "25"]
        if password is not None:
            args += ["--ask", "device", "wifi", "connect", ssid]
            _net_operation(args, password + "\n", f"Connected to {ssid}")
        else:
            args += ["device", "wifi", "connect", ssid]
            _net_operation(args, message=f"Connected to {ssid}")

    def _net_toggle(_switch, enabled):
        if not net_state["updating"]:
            _net_operation(["radio", "wifi", "on" if enabled else "off"],
                           message="Wi-Fi turned on" if enabled else "Wi-Fi turned off")
        return True

    def _net_disconnect(*_):
        active = net_state.get("active")
        if active:
            _net_operation(["connection", "down", "id", active],
                           message=f"Disconnected from {active}")

    net_refresh.connect("clicked", _net_scan)
    net_wifi_switch.connect("state-set", _net_toggle)
    net_disconnect.connect("clicked", _net_disconnect)

    return network_panel, _net_scan


def show_wifi_dialog(parent=None):
    """Show modal dialog for Wi-Fi scanning and connection."""
    try:
        import gi.overrides.Gtk as ogtk
        ogtk.initialized = True
    except Exception:
        pass
    dialog = Gtk.Dialog(title="Wi-Fi Networks", parent=parent, modal=True)
    dialog.set_default_size(360, 480)
    dialog.set_position(Gtk.WindowPosition.CENTER_ON_PARENT if parent else Gtk.WindowPosition.CENTER)
    dialog.set_keep_above(True)
    dialog.set_skip_taskbar_hint(True)
    _apply_css(dialog)
    box = dialog.get_content_area()
    box.set_spacing(10)
    box.set_margin_start(16)
    box.set_margin_end(16)
    box.set_margin_top(16)
    box.set_margin_bottom(16)
    panel, scan_fn = _build_network_panel(parent_win=dialog, toast_fn=lambda msg: notify(msg))
    box.pack_start(panel, True, True, 0)
    close_btn = dialog.add_button("✕ Close", Gtk.ResponseType.CLOSE)
    close_btn.get_style_context().add_class("btn-primary")
    dialog.show_all()
    scan_fn()
    dialog.run()
    dialog.destroy()


def show_lockout_window(minutes, pseudo=False):
    """Unclosable fullscreen countdown — device unusable until timer ends."""
    global _guard_id, _sweep_id
    schedule = _load_lockout_schedule(_load_suspend_state())
    if schedule is None:
        schedule = {"segments": [int(minutes * 60)], "stage": 0,
                    "stage_start": time.time(), "origin_start": time.time()}
    end = _schedule_end(schedule)

    win = _new_fullscreen("Focus Lockout" if pseudo else "Device Suspended")
    _apply_css(win)
    win.connect("delete-event", lambda *_: True)  # block Alt+F4 / close
    _compact = is_compact_screen()
    outer, card = _new_card(620 if _compact else 900)

    badge = _eyebrow("FOCUS LOCKOUT" if pseudo else "DEVICE SUSPENDED")

    time_label = Gtk.Label(label="")
    time_label.get_style_context().add_class("lock-time")
    time_label.set_halign(Gtk.Align.CENTER)

    sub = Gtk.Label(label=("This device is focus-locked but still on.\n"
                           "It will unlock automatically when the timer ends.")
                          if pseudo else
                          ("This device is locked. Please take a break.\n"
                           "It will unlock automatically when the timer ends."))
    sub.get_style_context().add_class("body")
    sub.set_halign(Gtk.Align.CENTER)
    sub.set_justify(Gtk.Justification.CENTER)

    total = max(1, sum(int(x) for x in schedule["segments"]))
    prog = Gtk.ProgressBar()
    prog.get_style_context().add_class("lockbar")
    prog.set_show_text(True)
    prog.set_halign(Gtk.Align.FILL)
    prog.set_hexpand(True)
    unlock_lbl = Gtk.Label(label=f"Unlocks at {time.strftime('%Y-%m-%d %H:%M', time.localtime(end))}")
    unlock_lbl.get_style_context().add_class("unlockat")
    unlock_lbl.set_halign(Gtk.Align.CENTER)

    goals_lbl = Gtk.Label(label="MY GOALS")
    goals_lbl.get_style_context().add_class("caption")
    goals_lbl.set_halign(Gtk.Align.CENTER)
    goals_box = _goal_rows_box(interactive=False, limit=20)
    goals_box.set_halign(Gtk.Align.FILL)
    goals_box.set_hexpand(True)
    goals_scroll = Gtk.ScrolledWindow()
    goals_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    goals_scroll.set_min_content_height(120)
    goals_scroll.set_max_content_height(300 if _compact else 460)
    goals_scroll.set_halign(Gtk.Align.FILL)
    goals_scroll.set_hexpand(True)
    goals_scroll.set_vexpand(True)
    goals_scroll.add(goals_box)

    lockrow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
    lockrow.set_halign(Gtk.Align.CENTER)
    study_btn = Gtk.Button(label="\U0001F4DA  Study")
    study_btn.get_style_context().add_class("btn-primary")
    study_btn.set_size_request(160, 48)

    def _sync_study_button():
        until = _get_study_suspended_until()
        now_ts = time.time()
        ctx = study_btn.get_style_context()
        if until > now_ts:
            rem_m = max(1, int(math.ceil((until - now_ts) / 60.0)))
            study_btn.set_sensitive(False)
            study_btn.set_label(f"📚 Study Suspended ({rem_m}m)")
            study_btn.set_tooltip_text(
                f"Study Mode is temporarily suspended due to blocked keywords. Available in {rem_m}m.")
            ctx.remove_class("btn-primary")
            ctx.add_class("btn-secondary")
        else:
            study_btn.set_sensitive(True)
            study_btn.set_label("📚  Study")
            study_btn.set_tooltip_text("Study links and PDF reader (suspension continues).")
            ctx.remove_class("btn-secondary")
            ctx.add_class("btn-primary")

    _sync_study_button()

    def _on_study_clicked(*_):
        if _is_study_suspended():
            _sync_study_button()
            return
        show_study_window(parent=win, end_ts=end)

    study_btn.connect("clicked", _on_study_clicked)
    wifi_btn = Gtk.Button(label="\U0001F4F6  Wi-Fi")
    wifi_btn.get_style_context().add_class("btn-ghost")
    wifi_btn.set_size_request(122, 34)
    wifi_btn.set_tooltip_text("Scan and connect to Wi-Fi networks.")
    wifi_btn.connect("clicked", lambda *_: show_wifi_dialog(parent=win))
    type_btn = Gtk.Button(label="Typing Test")
    type_btn.get_style_context().add_class("btn-ghost")
    type_btn.set_size_request(160, 48)
    type_btn.set_tooltip_text("Practice typing (black fullscreen). Suspension continues.")
    type_btn.connect("clicked", lambda *_: show_typing_test(parent=win))
    power_btn = Gtk.Button(label="\u23fb  Power Off")
    power_btn.get_style_context().add_class("btn-danger")
    power_btn.set_size_request(160, 48)
    power_btn.set_halign(Gtk.Align.CENTER)
    power_btn.set_tooltip_text("Shut down this machine. Requires confirmation.")
    lockrow.pack_start(study_btn, False, False, 0)
    lockrow.pack_start(type_btn, False, False, 0)
    lockrow.pack_start(power_btn, False, False, 0)

    extend_btn = Gtk.Button()
    extend_btn.get_style_context().add_class("btn-primary")
    extend_btn.set_halign(Gtk.Align.CENTER)
    def _off(*_):
        power_btn.set_sensitive(False)
        if confirm_power_off(win):
            power_off()
        else:
            power_btn.set_sensitive(True)
    power_btn.connect("clicked", _off)

    def _set_extend_button():
        stage_seconds = int(schedule["segments"][int(schedule["stage"])])
        if stage_seconds in (3 * 86400, 7 * 86400):
            extra_days = 3 if stage_seconds == 7 * 86400 else 7
            extend_btn.set_label(f"Extend by {extra_days} days")
            extend_btn.set_sensitive(len(schedule["segments"]) <= int(schedule["stage"]) + 1)
            extend_btn.show()
        else:
            extend_btn.hide()

    def _extend_lockout(*_):
        nonlocal end, total
        stage_seconds = int(schedule["segments"][int(schedule["stage"])])
        if (stage_seconds not in (3 * 86400, 7 * 86400)
                or len(schedule["segments"]) > int(schedule["stage"]) + 1):
            return
        extra_seconds = 3 * 86400 if stage_seconds == 7 * 86400 else 7 * 86400
        schedule["segments"].append(extra_seconds)
        _save_lockout_schedule(schedule)
        end = _schedule_end(schedule)
        total = max(1, sum(int(x) for x in schedule["segments"]))
        global suspend_until
        suspend_until = end
        _save_suspend_state(end)
        unlock_lbl.set_text(f"Unlocks at {time.strftime('%Y-%m-%d %H:%M', time.localtime(end))}")
        _set_extend_button()
        notify(f"Lockout extended by {extra_seconds // 86400} days.")

    extend_btn.connect("clicked", _extend_lockout)
    _set_extend_button()

    def _stage_end():
        return float(schedule["stage_start"]) + int(
            schedule["segments"][int(schedule["stage"])])

    def fmt_left():
        # Show the FULL remaining lockout (all stages), so an extension adds to
        # the visible timer immediately instead of waiting for the next stage.
        left = max(0, int(end - time.time()))
        d, rem = divmod(left, 86400)
        h, rem = divmod(rem, 3600)
        m, s = divmod(rem, 60)
        if d:
            return f"{d}d {h:02d}:{m:02d}:{s:02d}"
        return f"{h:02d}:{m:02d}:{s:02d}"

    time_label.set_text(fmt_left())
    prog.set_fraction(0.0)
    prog.set_text("0% served")

    ending = {"phase": 0}
    checkpoint_tick = {"last": 0.0}

    def _touch_gtk_ready():
        try:
            with open(GTK_LOCKOUT_READY, "w") as f:
                f.write(str(time.time()))
        except Exception:
            pass

    def _sync_schedule_from_disk():
        """Pick up extensions made from the Study top bar or another window."""
        nonlocal end, total
        try:
            saved_end = _load_suspend_state()
            disk = _load_lockout_schedule(saved_end)
            if disk is None:
                return
            disk_end = _schedule_end(disk)
            if disk_end > end + 0.5:
                schedule.clear()
                schedule.update(disk)
                end = max(disk_end, saved_end)
                total = max(1, sum(int(x) for x in schedule["segments"]))
                unlock_lbl.set_text(
                    f"Unlocks at {time.strftime('%Y-%m-%d %H:%M', time.localtime(end))}")
                _set_extend_button()
            elif saved_end > end + 0.5:
                end = saved_end
                unlock_lbl.set_text(
                    f"Unlocks at {time.strftime('%Y-%m-%d %H:%M', time.localtime(end))}")
        except Exception as e:
            print(f"lockout schedule sync error: {e}", flush=True)

    def tick():
        nonlocal end, total
        _sync_schedule_from_disk()
        if time.time() >= _stage_end() and int(schedule["stage"]) + 1 < len(schedule["segments"]):
            stage_boundary = _stage_end()
            schedule["stage"] = int(schedule["stage"]) + 1
            schedule["stage_start"] = stage_boundary
            _save_lockout_schedule(schedule)
            end = _schedule_end(schedule)
            total = max(1, sum(int(x) for x in schedule["segments"]))
            global suspend_until
            suspend_until = end
            _save_suspend_state(end)
            unlock_lbl.set_text(f"Unlocks at {time.strftime('%Y-%m-%d %H:%M', time.localtime(end))}")
            _set_extend_button()
        now = time.time()
        _touch_gtk_ready()
        _sync_study_button()
        if now - checkpoint_tick["last"] >= 5:
            _save_suspend_state(end, mode="active")
            checkpoint_tick["last"] = now
        time_label.set_text(fmt_left())
        left = max(0, end - time.time())
        done_frac = min(1.0, max(0.0,
                                 (time.time() - float(schedule.get("origin_start", schedule["stage_start"])))
                                 / total))
        prog.set_fraction(done_frac)
        prog.set_text(f"{int(done_frac * 100)}% served")
        if (time.time() >= _stage_end() and time.time() >= end
                and int(schedule["stage"]) + 1 >= len(schedule["segments"])):
            if _typing_win is not None and ending["phase"] == 0:
                # typing open: close it first (quits ITS nested loop),
                # then finish lockout on the next tick in our own loop
                ending["phase"] = 1
                _close_typing_autosave()
                return True
            if _study_win is not None and ending["phase"] == 0:
                # study open: close it (its own nested loop), then lockout
                ending["phase"] = 1
                global _study_auto_closing
                _study_auto_closing = True
                _study_win.destroy()
                return True
            win.destroy()  # destroy, NOT close (delete-event is blocked)
            return False
        return True

    time_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=SPACE)
    time_row.set_halign(Gtk.Align.CENTER)
    time_row.set_valign(Gtk.Align.CENTER)
    time_row.pack_start(time_label, False, False, 0)
    time_row.pack_start(wifi_btn, False, False, 0)

    if _compact:
        for w in (_accent(), badge, time_row, prog, unlock_lbl, sub,
                  extend_btn,
                  goals_lbl, goals_scroll, lockrow):
            card.pack_start(w, False, False, 0)
    else:
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2 * SPACE)
        left.set_hexpand(True)
        left.set_halign(Gtk.Align.FILL)
        for w in (badge, time_row, prog, unlock_lbl, sub,
                  extend_btn, lockrow):
            left.pack_start(w, False, False, 0)
        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=SPACE)
        right.set_hexpand(True)
        right.set_halign(Gtk.Align.FILL)
        right.pack_start(goals_lbl, False, False, 0)
        right.pack_start(goals_scroll, True, True, 0)
        panes = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2 * SPACE)
        panes.set_halign(Gtk.Align.FILL)
        panes.set_hexpand(True)
        panes.pack_start(left, True, True, 0)
        panes.pack_start(right, True, True, 0)
        card.pack_start(_accent(), False, False, 0)
        card.pack_start(panes, True, True, 0)
    win.add(outer)
    _shell_saved = _gnome_lockdown()
    win.set_modal(True)
    _swallow_shell_keys(win)
    _guard_id = _arm_focus_guard(win, is_lockout=True)
    _lockout_sigs = _lockout_exe_signatures()
    _lockout_proc_sweep(_lockout_sigs)  # immediate: nothing usable survives
    _sweep_id = GLib.timeout_add_seconds(
        1, lambda: (_lockout_proc_sweep(_lockout_sigs), True)[1])

    def _on_lock_destroy(*_):
        for _sid in (_guard_id, _sweep_id):
            try:
                GLib.source_remove(_sid)
            except Exception:
                pass
        try:
            os.remove(GTK_LOCKOUT_READY)
        except OSError:
            pass
        _gnome_restore(_shell_saved)
        Gtk.main_quit()
    win.connect("destroy", _on_lock_destroy)
    _touch_gtk_ready()
    win.show_all()
    win.present()
    if os.environ.get("FOCUS_STARTUP_BARRIER") == "1":
        while Gtk.events_pending():
            Gtk.main_iteration_do(False)
        _systemd_startup_ready()
    type_btn.grab_focus()
    GLib.timeout_add_seconds(1, tick)
    Gtk.main()

# ---------- study container ----------

STUDY_INBOX = os.path.expanduser("~/Documents/study-inbox")
DOWNLOAD_DIR = os.path.expanduser("~/Downloads")
STUDY_READING_STATE = os.path.join(LEDGER_DIR, "study-reading-state.json")
STUDY_RECENTS_STATE = os.path.join(LEDGER_DIR, "study-recents.json")
STUDY_DOWNLOADS_STATE = os.path.join(LEDGER_DIR, "study-downloads.json")
STUDY_READ_HISTORY_STATE = os.path.join(LEDGER_DIR, "study-read-history.json")
STUDY_WEB_DATA_DIR = os.path.join(LEDGER_DIR, "study-web-data")
STUDY_WEB_CACHE_DIR = os.path.join(LEDGER_DIR, "study-web-cache")
_study_web_context = None

# ---------- Input Filtering Service ----------
# Blocks explicit adult text from ever being typed/sent in the study browser and
# the typing test. Normalisation defeats leetspeak, spacing and zero-width tricks.
INPUT_FILTER_NAME = "Focus Input Filter"
STUDY_WEB_COOKIE_DB = os.path.join(STUDY_WEB_DATA_DIR, "cookies.sqlite")

BLOCKED_INPUT_WORDS = [
    # English / international & slang (including requested: xxx, xnxx, cuda, chudacudi, fuck, nude)
    "porn", "porno", "pornography", "xxx", "xnxx", "xvideo", "xvideos", "xhamster", "pornhub",
    "sex", "sexy", "sexting", "sexual", "nude", "nudes", "nudity", "naked", "nsfw",
    "fuck", "fucking", "fucker", "fucked",
    "cuda", "cudi", "cudar", "cudan", "cudacudi",
    "chuda", "choda", "chudi", "chudir", "chudar", "chodar", "chodon",
    "chudacudi", "chudachudi", "chodachudi", "chudai",
    "horny", "aroused", "orgasm", "erotic", "erotica", "hentai", "milf", "incest",
    "boobs", "boob", "pussy", "dick", "cock", "penis", "cum", "semen",
    "blowjob", "handjob", "anal", "anus", "masturbate", "masturbation",
    "slut", "whore", "prostitute", "onlyfans", "camgirl", "rapist", "condom",
    "viagra", "rowja", "viral",
    "boudi", "bhabi",
    "choti", "panu", "jouno", "jounota", "sexstory", "sexstories", "sexvideo",
    "sexchat", "sex golpo", "choti golpo", "panu golpo", "jouno golpo",
    "chudacudir golpo", "chudir golpo", "chodar golpo", "choda chudi golpo",
    "bangla choti", "bangla panu", "desi sex", "desi porn", "desi choti",
    "kamasutra", "kamsutra", "smut", "tits", "titties", "cumshot",
    "gangbang", "orgy", "threesome", "dildo", "vibrator", "fetish", "bondage",
    "stripper", "stripclub", "brothel", "magi", "khanki", "randi", "mms",
    "mms video", "blue film", "adult video", "adult story", "sex story",
    # Bangla script transliterations & equivalents of English words
    "পর্ন", "পর্ণ", "পর্নো", "পর্ণো", "পর্নোগ্রাফি", "পর্ণোগ্রাফি",
    "এক্সএক্সএক্স", "এক্সএনএক্সএক্স", "এক্সভিডিও", "এক্সহ্যামস্টার", "পর্নহাব", "পর্ণহাব",
    "সেক্স", "সেক্সি", "সেক্সটিং", "সেক্সুয়াল", "সেক্সস্টোরি", "সেক্সভিডিও", "সেক্সচ্যাট", "সেক্স গল্প",
    "ন্যুড", "ন্যূড", "ন্যুডস", "ন্যূডস", "নেকেড", "নগ্ন", "উলঙ্গ",
    "ফাক", "ফাকিং", "ফাকার",
    "কুদা", "কুদি", "কুদাচুদি",
    "চুদা", "চুদি", "চোদন", "চুদাচুদি", "চোদা", "চোদাচুদি", "চুদাই",
    "হর্নি", "কামুক", "উত্তেজিত",
    "অর্গাজম", "বীর্যপাত",
    "ইরোটিক", "ইরোটিকা",
    "হেনতাই", "মিল্ফ", "মিলফ", "ইনসেস্ট",
    "বুবস", "বুব", "স্তন", "দুধ",
    "পুসি", "যোনি", "গুদ", "ভোদা",
    "ডিক", "কক", "পেনিস", "লিঙ্গ", "বাড়া", "লেড়া",
    "কাম", "সিমেন", "বীর্য",
    "ব্লোজব", "হ্যান্ডজব",
    "অ্যানাল", "এনাল", "মলদ্বার",
    "মাস্টারবেশন", "হস্তমৈথুন",
    "স্লাট", "বেশ্যা", "পতিতা", "মাগি", "খানকি", "রান্ডি",
    "অনলিফ্যানস", "অনলিফ্যান্স", "ক্যামগার্ল",
    "ডিলডো", "ভাইব্রেটর",
    "গ্যাংব্যাং", "অর্জি", "থ্রিসাম",
    "স্ট্রিপার", "স্ট্রিপক্লাব",
    "ব্লু ফিল্ম", "ব্লুফিল্ম",
    "এডাল্ট ভিডিও", "এডাল্ট স্টোরি",
    "বৌদি", "ভাবি",
    "চটি", "পানু", "যৌন", "যৌনতা", "যৌনগল্প", "চটি গল্প", "পানু গল্প", "যৌন গল্প",
    "অশ্লীল", "কামসূত্র"
]

CUSTOM_BLOCKED_KEYWORDS_FILE = os.path.join(LEDGER_DIR, "blocked-keywords.json")


def _load_custom_blocked_keywords():
    try:
        if os.path.isfile(CUSTOM_BLOCKED_KEYWORDS_FILE):
            with open(CUSTOM_BLOCKED_KEYWORDS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return [str(k).strip() for k in data if str(k).strip()]
    except Exception as e:
        print(f"Error loading custom blocked keywords: {e}", flush=True)
    return []


def _save_custom_blocked_keywords(keywords_list):
    try:
        os.makedirs(LEDGER_DIR, exist_ok=True)
        tmp = CUSTOM_BLOCKED_KEYWORDS_FILE + f".tmp-{os.getpid()}"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(keywords_list, f, indent=2, ensure_ascii=False)
        os.replace(tmp, CUSTOM_BLOCKED_KEYWORDS_FILE)
        try:
            os.chmod(CUSTOM_BLOCKED_KEYWORDS_FILE, 0o600)
        except OSError:
            pass
        return True
    except Exception as e:
        print(f"Error saving custom blocked keywords: {e}", flush=True)
        return False


# Load saved custom keywords
for _ckw in _load_custom_blocked_keywords():
    if _ckw.lower() not in [x.lower() for x in BLOCKED_INPUT_WORDS]:
        BLOCKED_INPUT_WORDS.append(_ckw.lower())

# Tokens too risky for compact (substring) matching -> whole-word match only.
_BLOCK_WORD_ONLY = {"sex", "anal", "cum", "dick", "cock", "nude", "xxx",
                    "magi", "randi", "bhabi", "mms", "fuck", "cuda"}
_BLOCK_LEET = str.maketrans({"0": "o", "1": "i", "3": "e", "4": "a", "5": "s",
                             "6": "g", "7": "t", "8": "b", "9": "g", "@": "a",
                             "$": "s", "!": "i", "|": "i"})
_ZERO_WIDTH = "\u200b\u200c\u200d\u200e\u200f\u202a\u202b\u202c\u202d\u202e\u2060\ufeff"


def _input_norm(text):
    s = str(text or "").lower()
    s = "".join(ch for ch in s if ch not in _ZERO_WIDTH)
    s = unicodedata.normalize("NFKD", s)
    # strip Latin accents only (keep Bangla/Indic vowel signs)
    s = "".join(ch for ch in s if not (unicodedata.combining(ch) and ord(ch) < 0x0900))
    return s.translate(_BLOCK_LEET)


_LETTER_RE = re.compile(r"[a-z0-9\u0980-\u09FF]")


def _compact_map(text, collapse=False):
    """Compact form + gap flags (True = char starts a new chunk in the input)."""
    out, gaps = [], []
    pending_gap = True
    for ch in _input_norm(text):
        if _LETTER_RE.match(ch):
            out.append(ch)
            gaps.append(pending_gap)
            pending_gap = False
        else:
            pending_gap = True
    if collapse:
        cc, cg = [], []
        for ch, gap in zip(out, gaps):
            if cc and ch == cc[-1] and not gap:
                continue
            cc.append(ch)
            cg.append(gap)
        out, gaps = cc, cg
    return "".join(out), gaps


def _compact_variants(text):
    raw = _compact_map(text)
    col = _compact_map(text, collapse=True)
    return [raw] if raw[0] == col[0] else [raw, col]


def _compact(text):
    return _compact_map(text, collapse=True)[0]


def _is_bangla(word):
    return any("\u0980" <= ch <= "\u09ff" for ch in word)


def _rebuild_blocked_structures():
    global _BLOCK_NORM, _BLOCK_COMPACT
    _BLOCK_NORM = [(w, re.sub(r"[^a-z0-9\u0980-\u09FF]+", " ",
                              _input_norm(w)).strip()) for w in BLOCKED_INPUT_WORDS]
    _BLOCK_COMPACT = []
    for _w in BLOCKED_INPUT_WORDS:
        for _form in {_compact_map(_w)[0], _compact_map(_w, collapse=True)[0]}:
            _BLOCK_COMPACT.append((_w, _form))


_BLOCK_NORM = []
_BLOCK_COMPACT = []
_rebuild_blocked_structures()


def _explicit_hit(text):
    """Return the matched explicit word, or None.

    Every blocked word goes through the same normaliser: lowercase, accent
    folding, zero-width removal, leetspeak, punctuation/spacing and repeated
    letters.  Short risky words additionally require word boundaries so normal
    text (imagine, branding, bhabishyat) still passes.
    """
    if not text:
        return None
    spaced = " " + re.sub(r"[^a-z0-9\u0980-\u09FF]+", " ",
                          _input_norm(text)).strip() + " "
    for word, norm in _BLOCK_NORM:
        if norm and (" " + norm + " ") in spaced:
            return word

    variants = _compact_variants(text)
    for word, comp_word in _BLOCK_COMPACT:
        if not comp_word:
            continue
        if _is_bangla(comp_word):
            min_len = 2
        elif word in _BLOCK_WORD_ONLY:
            min_len = 3
        else:
            min_len = 4
        if len(comp_word) < min_len:
            continue
        for comp, gaps in variants:
            start = 0
            while True:
                at = comp.find(comp_word, start)
                if at < 0:
                    break
                end = at + len(comp_word)
                if word not in _BLOCK_WORD_ONLY:
                    return word
                if gaps[at]:
                    internal = any(gaps[k] for k in range(at + 1, end))
                    after_gap = (end >= len(comp)) or gaps[end]
                    if internal or after_gap:
                        return word
                start = at + 1
    return None


def _is_keyword_blocked(raw):
    raw_lower = (raw or "").strip().lower()
    if not raw_lower:
        return False
    if raw_lower in [x.lower() for x in BLOCKED_INPUT_WORDS]:
        return True
    if _explicit_hit(raw_lower):
        return True
    return False


def _add_blocked_keyword(raw):
    raw_lower = (raw or "").strip().lower()
    if not raw_lower:
        return False
    saved = _load_custom_blocked_keywords()
    if raw_lower in [x.lower() for x in BLOCKED_INPUT_WORDS]:
        return True
    if raw_lower not in [x.lower() for x in saved]:
        saved.append(raw_lower)
        if not _save_custom_blocked_keywords(saved):
            return False
    BLOCKED_INPUT_WORDS.append(raw_lower)
    _rebuild_blocked_structures()
    return True


def _build_input_filter_js():
    import json as _json
    words = _json.dumps(BLOCKED_INPUT_WORDS)
    return r"""
(function () {
  if (window.__focusInputFilter) { return; }
  window.__focusInputFilter = true;
  var RAW = __WORDS__;
  var ZERO = /[\u200b-\u200f\u202a-\u202e\u2060\ufeff]/g;
  var LEET = {'0':'o','1':'i','3':'e','4':'a','5':'s','6':'g','7':'t','8':'b','9':'g',
              '@':'a','$':'s','!':'i','|':'i'};
  function norm(s) {
    s = String(s || '').toLowerCase().replace(ZERO, '');
    try { s = s.normalize('NFKD').replace(/[\u0300-\u036f]/g, ''); } catch (e) {}
    return s.replace(/[013456789@$!|]/g, function (c) { return LEET[c] || c; });
  }
  function spaced(s) {
    return ' ' + norm(s).replace(/[^a-z0-9\u0980-\u09FF]+/g, ' ').trim() + ' ';
  }
  function sqMap(s, collapse) {
    var n = norm(s), chars = [], gaps = [], pending = true, i;
    for (i = 0; i < n.length; i++) {
      var ch = n[i];
      if (/[a-z0-9\u0980-\u09FF]/.test(ch)) { chars.push(ch); gaps.push(pending); pending = false; }
      else { pending = true; }
    }
    if (collapse) {
      var cc = [], cg = [];
      for (i = 0; i < chars.length; i++) {
        if (cc.length && chars[i] === cc[cc.length - 1] && !gaps[i]) { continue; }
        cc.push(chars[i]); cg.push(gaps[i]);
      }
      chars = cc; gaps = cg;
    }
    return { c: chars.join(''), g: gaps };
  }
  function sqVariants(s) {
    var raw = sqMap(s, false), col = sqMap(s, true);
    return raw.c === col.c ? [raw] : [raw, col];
  }
  var BAN = RAW.map(norm);
  var BANC = [];
  RAW.forEach(function (w) {
    var seen = {};
    [sqMap(w, false).c, sqMap(w, true).c].forEach(function (c) {
      if (c && !seen[c]) { seen[c] = 1; BANC.push({ w: w, c: c }); }
    });
  });
  window.__focusAddWord = function (w) {
    if (!w) { return; }
    w = String(w).toLowerCase();
    if (RAW.indexOf(w) === -1) {
      RAW.push(w);
      BAN.push(norm(w));
      var seen = {};
      [sqMap(w, false).c, sqMap(w, true).c].forEach(function (c) {
        if (c && !seen[c]) { seen[c] = 1; BANC.push({ w: w, c: c }); }
      });
    }
  };
  var WORD_ONLY = {'sex':1,'anal':1,'cum':1,'dick':1,'cock':1,'nude':1,'xxx':1,
                   'magi':1,'randi':1,'bhabi':1,'mms':1,'fuck':1,'cuda':1};
  function hit(text) {
    if (!text) { return null; }
    var t = spaced(text);
    var i;
    for (i = 0; i < BAN.length; i++) {
      var w = BAN[i].replace(/[^a-z0-9\u0980-\u09FF]+/g, ' ').trim();
      if (w && t.indexOf(' ' + w + ' ') !== -1) { return RAW[i]; }
    }
    var variants = sqVariants(text);
    for (i = 0; i < BANC.length; i++) {
      var word = BANC[i].w, cw = BANC[i].c;
      var minL = /[\u0980-\u09FF]/.test(cw) ? 2 : (WORD_ONLY[word] ? 3 : 4);
      if (cw.length < minL) { continue; }
      for (var v = 0; v < variants.length; v++) {
        var cm = variants[v], pos = 0;
        while (true) {
          var at = cm.c.indexOf(cw, pos);
          if (at < 0) { break; }
          var end = at + cw.length;
          if (!WORD_ONLY[word]) { return word; }
          if (cm.g[at]) {
            var internal = false, k;
            for (k = at + 1; k < end; k++) { if (cm.g[k]) { internal = true; break; } }
            var afterGap = (end >= cm.c.length) ? true : cm.g[end];
            if (internal || afterGap) { return word; }
          }
          pos = at + 1;
        }
      }
    }
    return null;
  }
  window.__focusFilterHit = hit;

  var warned = 0;
  function toast(msg) {
    var now = Date.now();
    if (now - warned < 1000) { return; }
    warned = now;
    var d = document.getElementById('__focus_filter_toast');
    if (!d) {
      d = document.createElement('div');
      d.id = '__focus_filter_toast';
      d.style.cssText = 'position:fixed;top:14px;left:50%;transform:translateX(-50%);' +
        'z-index:2147483647;background:#7f1d1d;color:#fff;font:bold 14px sans-serif;' +
        'padding:10px 18px;border-radius:10px;box-shadow:0 6px 20px rgba(0,0,0,.55);' +
        'pointer-events:none;max-width:80vw;';
      (document.body || document.documentElement).appendChild(d);
    }
    d.textContent = '\u26d4 Focus Input Filter: ' + msg;
    d.style.display = 'block';
    clearTimeout(d.__t);
    d.__t = setTimeout(function () { d.style.display = 'none'; }, 2600);
    try {
      if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.focusInputBlocked) {
        window.webkit.messageHandlers.focusInputBlocked.postMessage(msg || 'blocked');
      }
    } catch (_) {}
  }
  function editable(el) {
    return !!el && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT' || el.isContentEditable);
  }
  function val(el) { return el.isContentEditable ? el.innerText : el.value; }
  var lastGood = new WeakMap();

  document.addEventListener('focusin', function (e) {
    var el = e.target;
    if (editable(el)) { lastGood.set(el, el.isContentEditable ? el.innerHTML : el.value); }
  }, true);

  document.addEventListener('input', function (e) {
    var el = e.target;
    if (!editable(el)) { return; }
    var bad = hit(val(el));
    if (bad) {
      var good = lastGood.get(el);
      if (good !== undefined) {
        if (el.isContentEditable) { el.innerHTML = good; } else { el.value = good; }
      }
      toast('explicit content blocked (' + bad + ')');
      return;
    }
    lastGood.set(el, el.isContentEditable ? el.innerHTML : el.value);
  }, true);

  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' || !editable(e.target)) { return; }
    if (hit(val(e.target))) {
      e.preventDefault();
      e.stopImmediatePropagation();
      toast('message not allowed');
    }
  }, true);

  document.addEventListener('paste', function (e) {
    var el = e.target;
    if (!editable(el)) { return; }
    var cd = e.clipboardData || window.clipboardData;
    var txt = cd ? (cd.getData('text') || '') : '';
    if (hit(txt)) {
      e.preventDefault();
      e.stopImmediatePropagation();
      toast('paste blocked');
    }
  }, true);

  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (!f || !f.querySelectorAll) { return; }
    var bad = null;
    f.querySelectorAll('input,textarea').forEach(function (el) {
      if (!bad) { bad = hit(el.value); }
    });
    if (bad) {
      e.preventDefault();
      e.stopImmediatePropagation();
      toast('send blocked');
    }
  }, true);

  document.addEventListener('click', function (e) {
    var el = e.target;
    var box = editable(el) ? el : (editable(document.activeElement) ? document.activeElement : null);
    if (!box && el && el.closest) {
      var root = el.closest('form,[role="dialog"]');
      if (root) { box = root.querySelector('input,textarea,[contenteditable="true"]'); }
    }
    if (box && hit(val(box))) {
      e.preventDefault();
      e.stopImmediatePropagation();
      toast('send blocked');
    }
  }, true);
})();
""".replace("__WORDS__", words)


INPUT_FILTER_JS = _build_input_filter_js()
TELEGRAM_KIOSK_JS = r"""
(function () {
  'use strict';
  if (location.hostname.toLowerCase() !== 'web.telegram.org' ||
      !/^\/(?:k|a)\/?$/.test(location.pathname)) return;

  var targetPeer = '-1004415493319';
  var targetAlt = '4415493319';
  var targetName = 'pdf258upload';

  // We keep the left column in the layout for Telegram's JS to render the chat items,
  // but position it far off-screen so the user NEVER sees the left chat list or search bar!
  // The center chat column expands to take 100% of the visible viewport!
  var style = document.createElement('style');
  style.textContent = [
    '#column-left, #LeftColumn, .LeftColumn, .sidebar-left, div[class*="LeftColumn"], .chatlist-container {',
    '    position: fixed !important;',
    '    left: -9999px !important;',
    '    top: 0 !important;',
    '    width: 360px !important;',
    '    height: 100vh !important;',
    '    opacity: 0 !important;',
    '    pointer-events: none !important;',
    '    z-index: -999 !important;',
    '}',
    '#column-center, #MiddleColumn, .MiddleColumn {',
    '    display: flex !important;',
    '    width: 100vw !important;',
    '    max-width: 100vw !important;',
    '    height: 100vh !important;',
    '    position: absolute !important;',
    '    top: 0 !important;',
    '    left: 0 !important;',
    '    margin: 0 !important;',
    '    flex: 1 1 100% !important;',
    '    z-index: 1 !important;',
    '}',
    '#column-right, #RightColumn, .RightColumn,',
    '.btn-menu-toggle, button.back-button, button[aria-label="Back"], button[title="Back"],',
    'button.sidebar-close-button, .sidebar-header__btn-back, .Header-left .btn-icon,',
    '#stories-viewer, .stories-list {',
    '    display: none !important;',
    '}',
    'body, html, #page-chats, #root, #main-columns, .Main {',
    '    width: 100vw !important;',
    '    max-width: 100vw !important;',
    '    overflow: hidden !important;',
    '}'
  ].join('\n');
  (document.head || document.documentElement).appendChild(style);

  function isTargetElement(el) {
    if (!el) return false;
    var href = (el.getAttribute('href') || '').toLowerCase();
    var peer = (el.getAttribute('data-peer-id') || '').toLowerCase();
    var text = (el.textContent || '').toLowerCase();
    var hash = (location.hash || '').toLowerCase();

    // Check if currently targeting Biprova
    if (hash.indexOf('biprov') !== -1 || hash.indexOf('biprova') !== -1) {
      return (text.indexOf('biprov') !== -1 ||
              text.indexOf('biprova') !== -1 ||
              href.indexOf('biprov') !== -1 ||
              href.indexOf('biprova') !== -1 ||
              peer.indexOf('biprov') !== -1);
    }

    // Default targeting PDF Materials
    return (href.indexOf('4415493319') !== -1 ||
            href.indexOf('pdf258upload') !== -1 ||
            peer.indexOf('4415493319') !== -1 ||
            text.indexOf('pdf materials') !== -1 ||
            text.indexOf('pdf258upload') !== -1);
  }

  function autoOpenGroup() {
    var center = document.querySelector('#column-center, #MiddleColumn');
    var isChatActive = center && (
      center.querySelector('.bubbles, .bubble, .messages-container, .MessageList, .chat-info, .input-message-container') ||
      center.classList.contains('active')
    );

    // If chat is not yet loaded into center column, find and click the chat item:
    var chats = document.querySelectorAll('a.chatlist-chat, .chat-item-clickable, .ListItem');
    for (var i = 0; i < chats.length; i++) {
      if (isTargetElement(chats[i])) {
        if (!isChatActive || !chats[i].classList.contains('active')) {
          chats[i].click();
          try {
            chats[i].dispatchEvent(new MouseEvent('mousedown', {bubbles: true, cancelable: true}));
            chats[i].dispatchEvent(new MouseEvent('mouseup', {bubbles: true, cancelable: true}));
          } catch (_) {}
        }
        break;
      }
    }

    // Ensure the hash stays targeted
    var h = (location.hash || '').replace(/^#/, '').toLowerCase();
    if (!h || h === '' || h === 'undefined') {
      try {
        history.replaceState(history.state, '', location.pathname + location.search + '#' + targetPeer);
      } catch (_) {}
    }
  }

  setInterval(autoOpenGroup, 400);
  window.addEventListener('load', autoOpenGroup);
  setTimeout(autoOpenGroup, 300);
  setTimeout(autoOpenGroup, 1000);
  setTimeout(autoOpenGroup, 2500);

  // Disable keyboard navigation away from chat
  document.addEventListener('keydown', function (event) {
    if ((event.altKey && (event.key === 'ArrowLeft' || event.key === 'ArrowRight')) ||
        (event.ctrlKey && ['k', 'f'].indexOf(event.key.toLowerCase()) !== -1)) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }, true);

  // Guard links
  document.addEventListener('click', function (event) {
    var link = event.target && event.target.closest ? event.target.closest('a[href]') : null;
    if (!link) return;
    try {
      var url = new URL(link.href, location.href);
      var host = url.hostname.toLowerCase();
      if ((host === 'web.telegram.org' || host === 'telegram.org' || host.endsWith('.telegram.org')) &&
          /\/file\//i.test(url.pathname)) return;
      if (url.protocol === 'blob:') return;
      if (host === 'web.telegram.org') {
        var hash = url.hash.replace(/^#/, '').toLowerCase();
        if (hash.indexOf('4415493319') !== -1 ||
            hash.indexOf('pdf258upload') !== -1 ||
            hash.indexOf('biprov') !== -1 ||
            hash.indexOf('biprova') !== -1) return;
      }
      event.preventDefault();
      event.stopImmediatePropagation();
    } catch (_) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }, true);
  window.open = function () { return null; };
})();
"""
_study_ucm = None

UPLOAD_PASSWORD_PATH = os.path.join(LEDGER_DIR, "phone-upload-password")
UPLOAD_PUBLIC_URL = "https://upload21.medisparkbd.com/"
# Public Telegram group: anyone can send PDFs here; Study mode only opens this group.
PHONE_PDF_UPLOAD_URL = "https://t.me/pdf258upload"
UPLOAD_SERVER_HOST = "127.0.0.1"
UPLOAD_SERVER_PORT = 8765
UPLOAD_MAX_BYTES = 90 * 1024 * 1024
_phone_upload_server = None
STUDY_CONFIG_PATH = os.path.join(LEDGER_DIR, "study-config.json")
MEDIA_EXTS = {".pdf", ".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"}
_SCAN_SKIP = {
    "node_modules", ".git", ".cache", "__pycache__", "snap", "venv", ".venv",
    "site-packages", "proc", "sys", "dev", "Trash", ".Trash-1000", "flatpak",
    "Steam", "steamapps", ".npm", ".cargo", ".rustup", ".local/share/Trash",
}

_STUDY_DEFAULTS = {
    "version": 17,
    "links": [
        {"title": "PDF Materials (Cloud)", "url": "tg-materials"},
        {"title": "Biprova 20 (Cloud)", "url": "tg-biprova"},
        {"title": "NotebookLM", "url": "https://notebooklm.google.com"},
        {"title": "Boimate", "url": "https://boimate.com"},
        {"title": "Medical Contents", "url": "https://medical-contents.abdursakib.workers.dev/0:/"},
        {"title": "MuslimBangla", "url": "https://muslimbangla.com"},
        {"title": "iHadis", "url": "https://ihadis.com/en"},
        {"title": "LiveMCQ", "url": "https://web.livemcq.com/"},
    ],
    "allow_hosts": [
        "boimate.com", "www.boimate.com", "*.boimate.com",
        "medical-contents.abdursakib.workers.dev",
        "notebooklm.google.com", "notebook.google.com", "notebook.google",
        "*.notebook.google.com", "*.notebooklm.google.com", "*.notebook.google",
        "notebooklm-pa.googleapis.com",
        "content-push.googleapis.com", "csp.withgoogle.com",
        "accounts.google.com", "clients6.google.com",
        "apis.google.com", "content.googleapis.com",
        "alkali-coba-pa.googleapis.com", "alkali-pa.googleapis.com",
        "alkalicoba-pa.googleapis.com",
        "www.gstatic.com", "ssl.gstatic.com", "fonts.gstatic.com", "gstatic.com",
        "fonts.googleapis.com", "font.gstatic.com", "googleusercontent.com",
        "*.googleusercontent.com", "usercontent.google.com",
        "*.usercontent.google.com", "*.gstatic.com", "*.googleapis.com",
        "*.usercontent.goog", "usercontent.goog", "*.scf.usercontent.goog",
        "*.goog", "*.ggpht.com", "*.withgoogle.com", "withgoogle.com",
        "*.appspot.com",
        "muslimbangla.com", "www.muslimbangla.com",
        "ihadis.com", "www.ihadis.com",
        "livemcq.com", "www.livemcq.com", "web.livemcq.com", "*.livemcq.com",
        "127.0.0.1", "localhost", "upload21.medisparkbd.com",
        "web.telegram.org",
        "cdn.jsdelivr.net", "cdnjs.cloudflare.com", "unpkg.com",
        "*.cloudfront.net", "*.amazonaws.com", "*.b-cdn.net",
        "*.digitaloceanspaces.com", "*.supabase.co", "*.firebaseapp.com",
    ],
    "scan_roots": ["~", "/media", "/mnt", "/run/media"],
    "download_exts": sorted(MEDIA_EXTS),
}


def _study_config():
    """Load study config, writing defaults on first run."""
    try:
        with open(STUDY_CONFIG_PATH) as f:
            cfg = json.load(f)
        if (isinstance(cfg, dict) and cfg.get("links") and cfg.get("allow_hosts")
                and int(cfg.get("version", 1)) >= 4):
            # Add newly shipped study resources to existing user configurations.
            changed = False
            kept_links = []
            seen_urls = set()
            for item in cfg.get("links", []):
                if not isinstance(item, dict):
                    continue
                uri = str(item.get("url", "")).strip()
                host = (urlparse(uri).hostname or "").lower()
                title = str(item.get("title", "")).strip()
                title_lower = title.lower()
                uri_lower = uri.lower()

                if (title_lower.replace(" ", "").replace("-", "") == "phonepdfupload"
                        or uri == PHONE_PDF_UPLOAD_URL):
                    changed = True
                    continue
                if host.endswith("whatsapp.com") or host.endswith("whatsapp.net"):
                    changed = True
                    continue
                if host.endswith("trycloudflare.com"):
                    changed = True
                    continue

                # Study Cloud Drives: PDF Materials and Biprova 20
                if title_lower in ("pdf materials upload", "pdf materials (cloud)", "pdf materials cloud", "pdf materials") \
                        or uri_lower in ("tg-materials", "pdf-materials"):
                    item["title"] = "PDF Materials (Cloud)"
                    item["url"] = "tg-materials"
                    uri = "tg-materials"
                    uri_lower = "tg-materials"

                if "biprov" in title_lower or "biprova" in title_lower or uri_lower == "tg-biprova":
                    item["title"] = "Biprova 20 (Cloud)"
                    item["url"] = "tg-biprova"
                    uri = "tg-biprova"
                    uri_lower = "tg-biprova"

                # User requirement: remove external telegram group links from sidebar
                if uri_lower not in ("tg-materials", "tg-biprova") and (
                        "telegram" in host or host.endswith("t.me") or host == "t.me"
                        or "web.telegram.org" in uri_lower
                        or "-1004415493319" in uri_lower
                        or "group" in title_lower
                        or "upload" in title_lower):
                    changed = True
                    continue

                # NotebookLM stays reachable; it is the only Google service
                # exposed in Study Mode.
                if (title_lower in ("gemini notebook", "notebooklm")
                        or host.endswith("notebook.google.com")
                        or host == "notebook.google"
                        or host.endswith("notebooklm.google.com")):
                    if title != "NotebookLM":
                        item["title"] = "NotebookLM"
                        changed = True
                    if uri != "https://notebooklm.google.com":
                        item["url"] = "https://notebooklm.google.com"
                        uri = "https://notebooklm.google.com"
                        changed = True

                # General Google services and full YouTube are off.
                if _host_blocked(host) or _is_youtube_host(host):
                    changed = True
                    continue

                norm_key = uri.lower()
                if norm_key in seen_urls:
                    changed = True
                    continue
                seen_urls.add(norm_key)
                kept_links.append(item)

            # Ensure PDF Materials (Cloud) and Biprova 20 (Cloud) are placed cleanly at top, with no duplicates
            tg_item = None
            biprov_item = None
            other_items = []
            for item in kept_links:
                if item.get("url") == "tg-materials":
                    tg_item = item
                elif item.get("url") == "tg-biprova":
                    biprov_item = item
                else:
                    other_items.append(item)
            if tg_item is None:
                tg_item = {"title": "PDF Materials (Cloud)", "url": "tg-materials"}
                changed = True
            if biprov_item is None:
                biprov_item = {"title": "Biprova 20 (Cloud)", "url": "tg-biprova"}
                changed = True
            kept_links = [tg_item, biprov_item] + other_items

            if len(kept_links) != len(cfg.get("links", [])):
                cfg["links"] = kept_links
                changed = True
            else:
                cfg["links"] = kept_links
            old_hosts = list(cfg["allow_hosts"])
            cfg["allow_hosts"] = [
                host for host in old_hosts
                if "whatsapp.com" not in str(host).lower()
                and "whatsapp.net" not in str(host).lower()
                and "trycloudflare.com" not in str(host).lower()
                and "telegram" not in str(host).lower()
                and "t.me" not in str(host).lower()
                and str(host).lower().strip() not in _STUDY_LEGACY_BLOCKED_PATTERNS]
            if cfg["allow_hosts"] != old_hosts:
                changed = True
            for link in _STUDY_DEFAULTS["links"]:
                if not any(item.get("url") == link["url"] for item in cfg["links"]
                           if isinstance(item, dict)):
                    cfg["links"].append(link)
                    changed = True
            for host in _STUDY_DEFAULTS["allow_hosts"]:
                if host not in cfg["allow_hosts"]:
                    cfg["allow_hosts"].append(host)
                    changed = True
            if int(cfg.get("version", 1)) < _STUDY_DEFAULTS["version"]:
                cfg["version"] = _STUDY_DEFAULTS["version"]
                changed = True
            if changed:
                try:
                    with open(STUDY_CONFIG_PATH, "w") as f:
                        json.dump(cfg, f, indent=2)
                except Exception as e:
                    print(f"study config update error: {e}", flush=True)
            return cfg
    except Exception:
        pass
    try:
        os.makedirs(LEDGER_DIR, exist_ok=True)
        with open(STUDY_CONFIG_PATH, "w") as f:
            json.dump(_STUDY_DEFAULTS, f, indent=2)
    except Exception as e:
        print(f"study config write error: {e}", flush=True)
    return dict(_STUDY_DEFAULTS)


def _ensure_phone_upload_password():
    os.makedirs(LEDGER_DIR, exist_ok=True)
    try:
        with open(UPLOAD_PASSWORD_PATH) as f:
            return f.read().strip()
    except OSError:
        pass
    generated = secrets.token_urlsafe(24)
    try:
        fd = os.open(UPLOAD_PASSWORD_PATH, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(generated + "\n")
        return generated
    except FileExistsError:
        with open(UPLOAD_PASSWORD_PATH) as f:
            return f.read().strip()


def start_phone_upload_server():
    """Disabled legacy phone upload portal."""
    return None


def _legacy_disabled_start_phone_upload_server():
    """Loopback-only authenticated PDF inbox, intended for an HTTPS tunnel."""
    global _phone_upload_server
    if _phone_upload_server is not None:
        return _phone_upload_server
    password = _ensure_phone_upload_password()

    class UploadHandler(BaseHTTPRequestHandler):
        server_version = "FocusPhoneUpload/1.0"

        def log_message(self, fmt, *args):
            print("phone upload: " + (fmt % args), flush=True)

        def _headers(self, content_type, length=None):
            self.send_header("Content-Type", content_type)
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy",
                             "default-src 'self'; style-src 'unsafe-inline'; "
                             "form-action 'self'; frame-ancestors 'none'; base-uri 'none'")
            if length is not None:
                self.send_header("Content-Length", str(length))

        def _authorized(self):
            expected = "Basic " + base64.b64encode(
                ("study:" + password).encode("utf-8")).decode("ascii")
            supplied = self.headers.get("Authorization", "")
            if hmac.compare_digest(supplied, expected):
                return True
            self.send_response(401)
            self.send_header("WWW-Authenticate", 'Basic realm="Study PDF Upload"')
            body = b"Password required\n"
            self._headers("text/plain; charset=utf-8", len(body))
            self.end_headers()
            self.wfile.write(body)
            return False

        def _html(self, body, status=200):
            page = ("<!doctype html><html lang='en'><meta charset='utf-8'>"
                    "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                    "<title>Study PDF Inbox</title><style>"
                    "*{box-sizing:border-box}body{margin:0;background:#edf2f8;color:#17243a;"
                    "font:16px system-ui,sans-serif}.wrap{max-width:680px;margin:24px auto;padding:16px}"
                    ".card{background:white;border:1px solid #dce5f1;border-radius:16px;"
                    "padding:22px;margin-bottom:16px;box-shadow:0 8px 28px #142b4612}"
                    "h1{font-size:22px;margin:0 0 6px}p{color:#64748b}.upload{width:100%;"
                    "padding:14px;border:1px dashed #94a3b8;border-radius:10px;background:#f8fafc}"
                    "button{margin-top:12px;width:100%;border:0;border-radius:10px;padding:14px;"
                    "background:#1d4ed8;color:white;font-weight:700;font-size:16px}li{margin:12px 0}"
                    "a{color:#1d4ed8;word-break:break-word}</style><body><main class='wrap'>"
                    + body + "</main></body></html>").encode("utf-8")
            self.send_response(status)
            self._headers("text/html; charset=utf-8", len(page))
            self.end_headers()
            self.wfile.write(page)

        def do_GET(self):
            if not self._authorized():
                return
            parsed = urllib.parse.urlsplit(self.path)
            if parsed.path.startswith("/download/"):
                name = os.path.basename(urllib.parse.unquote(parsed.path[len("/download/"):]))
                target = os.path.join(STUDY_INBOX, name)
                if not name.lower().endswith(".pdf") or not os.path.isfile(target):
                    self.send_error(404)
                    return
                length = os.path.getsize(target)
                self.send_response(200)
                self._headers("application/pdf", length)
                self.send_header("Content-Disposition",
                                 "attachment; filename*=UTF-8''" +
                                 urllib.parse.quote(name, safe=""))
                self.end_headers()
                with open(target, "rb") as f:
                    shutil.copyfileobj(f, self.wfile)
                return
            if parsed.path != "/":
                self.send_error(404)
                return
            os.makedirs(STUDY_INBOX, exist_ok=True)
            files = []
            for name in os.listdir(STUDY_INBOX):
                path = os.path.join(STUDY_INBOX, name)
                try:
                    if name.lower().endswith(".pdf") and os.path.isfile(path):
                        files.append((os.path.getmtime(path), name, os.path.getsize(path)))
                except OSError:
                    continue
            files.sort(reverse=True)
            rows = "".join(
                "<li><a href='/download/" + urllib.parse.quote(name, safe="") + "'>"
                + html.escape(name) + "</a> · " + f"{size / (1024 * 1024):.1f} MB</li>"
                for _mtime, name, size in files[:100])
            if not rows:
                rows = "<li>No PDFs uploaded yet.</li>"
            body = ("<section class='card'><h1>Study PDF Inbox</h1>"
                    "<p>Upload PDFs from your phone. They are saved to Study downloads.</p>"
                    "<form action='/upload' method='post' enctype='multipart/form-data'>"
                    "<input class='upload' type='file' name='files' accept='application/pdf,.pdf' "
                    "multiple required><button type='submit'>Upload PDF files</button></form></section>"
                    "<section class='card'><h1>Recent uploads</h1><ul>" + rows + "</ul></section>")
            self._html(body)

        def do_POST(self):
            if not self._authorized():
                return
            if urllib.parse.urlsplit(self.path).path != "/upload":
                self.send_error(404)
                return
            origin = self.headers.get("Origin", "")
            host = self.headers.get("Host", "")
            if origin and urllib.parse.urlsplit(origin).netloc != host:
                self.send_error(403)
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                self.send_error(400, "Invalid content length")
                return
            if length <= 0 or length > UPLOAD_MAX_BYTES:
                self.send_error(413, "Upload must be under 90 MB")
                return
            content_type = self.headers.get("Content-Type", "")
            if not content_type.lower().startswith("multipart/form-data;"):
                self.send_error(400, "Choose a PDF file")
                return
            body = self.rfile.read(length)
            safe_content_type = content_type.replace("\r", "").replace("\n", "")
            raw = ("MIME-Version: 1.0\r\nContent-Type: " + safe_content_type
                   + "\r\n\r\n").encode("ascii", "replace") + body
            message = BytesParser(policy=email.policy.default).parsebytes(raw)
            if not message.is_multipart():
                self.send_error(400, "Invalid upload form")
                return
            uploads = []
            total = 0
            for part in message.iter_parts():
                filename = part.get_filename()
                if not filename or part.get_param("name", header="content-disposition") != "files":
                    continue
                data = part.get_payload(decode=True) or b""
                total += len(data)
                name = os.path.basename(filename.replace("\\", "/"))
                name = re.sub(r"[^\w .()\-]", "_", name, flags=re.UNICODE).strip(" .")
                if not name.lower().endswith(".pdf") or not data:
                    self.send_error(415, "Only non-empty PDF files are accepted")
                    return
                if b"%PDF-" not in data[:1024]:
                    self.send_error(415, "The selected file is not a valid PDF")
                    return
                uploads.append((name, data))
            if not uploads or total > UPLOAD_MAX_BYTES:
                self.send_error(400, "Choose at least one PDF under 90 MB")
                return
            os.makedirs(STUDY_INBOX, exist_ok=True)
            saved = []
            with self.server.upload_lock:
                for name, data in uploads:
                    stem, suffix = os.path.splitext(name)
                    target = os.path.join(STUDY_INBOX, name)
                    index = 1
                    while os.path.exists(target):
                        index += 1
                        target = os.path.join(STUDY_INBOX, f"{stem} ({index}){suffix}")
                    temporary = target + ".upload-" + secrets.token_hex(5)
                    try:
                        with open(temporary, "xb") as f:
                            f.write(data)
                        os.replace(temporary, target)
                        saved.append(os.path.basename(target))
                    finally:
                        try:
                            if os.path.exists(temporary):
                                os.remove(temporary)
                        except OSError:
                            pass
            print(f"Phone upload received {len(saved)} PDF(s).", flush=True)
            self._html("<section class='card'><h1>Upload complete</h1><ul>" +
                       "".join("<li>" + html.escape(name) + "</li>" for name in saved) +
                       "</ul><p><a href='/'>Return to the inbox</a></p></section>", 201)

    class LoopbackUploadServer(ThreadingHTTPServer):
        daemon_threads = True
        allow_reuse_address = True
        upload_lock = threading.Lock()

    try:
        os.makedirs(STUDY_INBOX, exist_ok=True)
        _phone_upload_server = LoopbackUploadServer(
            (UPLOAD_SERVER_HOST, UPLOAD_SERVER_PORT), UploadHandler)
        threading.Thread(target=_phone_upload_server.serve_forever,
                         name="focus-phone-upload", daemon=True).start()
        print(f"Phone PDF upload portal listening on {UPLOAD_SERVER_HOST}:{UPLOAD_SERVER_PORT}.",
              flush=True)
    except OSError as e:
        print(f"Phone PDF upload portal could not start: {e}", flush=True)
    return _phone_upload_server


def _host_allowed(host, patterns):
    host = (host or "").lower().split(":")[0]
    if not host:
        return False
    for p in patterns:
        p = str(p).lower().strip()
        if not p:
            continue
        if p.startswith("*."):
            base = p[1:]  # /.example.com
            if host.endswith(base) or host == p[2:]:
                return True
        elif host == p:
            return True
    return False


# General Google services and the full YouTube interface are turned off in
# Study Mode. NotebookLM (notebooklm.google.com) and the static/auth endpoints
# it needs stay reachable; those are listed explicitly in the allowlist.
_STUDY_BLOCKED_HOSTS = {
    "google.com", "www.google.com", "docs.google.com", "drive.google.com",
    "sheets.google.com", "slides.google.com", "gemini.google.com",
    "translate.google.com", "translate.googleapis.com", "myaccount.google.com",
    "accounts.youtube.com", "youtube.com", "www.youtube.com", "m.youtube.com",
    "music.youtube.com", "youtu.be", "youtubei.googleapis.com", "i.ytimg.com",
    "youtube-nocookie.com", "www.youtube-nocookie.com",
    # Search engines and their common regional / lightweight front doors.
    "bing.com", "www.bing.com", "cn.bing.com", "duckduckgo.com",
    "www.duckduckgo.com", "html.duckduckgo.com", "search.yahoo.com",
    "yahoo.com", "www.yahoo.com", "yandex.com", "www.yandex.com",
    "yandex.ru", "search.brave.com", "ecosia.org", "www.ecosia.org",
    "qwant.com", "www.qwant.com", "startpage.com", "www.startpage.com",
    "search.naver.com", "search.daum.net", "baidu.com", "www.baidu.com",
    "ask.com", "www.ask.com", "aol.com", "search.aol.com",
    # Additional international and AI-assisted search providers.
    "sogou.com", "www.sogou.com", "sogou.net", "seznam.cz", "www.seznam.cz",
    "search.seznam.cz", "kagi.com", "www.kagi.com", "mojeek.com", "www.mojeek.com",
    "swisscows.com", "www.swisscows.com", "metager.de", "www.metager.de",
    "yep.com", "www.yep.com", "you.com", "www.you.com", "phind.com",
    "www.phind.com", "perplexity.ai", "www.perplexity.ai", "komo.ai",
    "www.komo.ai", "andisearch.com", "www.andisearch.com", "360.cn",
    "www.360.cn", "so.com", "www.so.com", "search.nifty.com",
    # Social networks, messaging feeds, forums and short-video platforms.
    "facebook.com", "www.facebook.com", "m.facebook.com", "fb.com",
    "instagram.com", "www.instagram.com", "threads.net", "www.threads.net",
    "twitter.com", "www.twitter.com", "x.com", "www.x.com", "t.co",
    "tiktok.com", "www.tiktok.com", "vm.tiktok.com", "reddit.com",
    "www.reddit.com", "old.reddit.com", "redd.it", "snapchat.com",
    "www.snapchat.com", "pinterest.com", "www.pinterest.com", "pin.it",
    "linkedin.com", "www.linkedin.com", "discord.com", "www.discord.com",
    "discord.gg", "web.whatsapp.com", "whatsapp.com", "www.whatsapp.com",
    "whatsapp.net", "web.telegram.org", "telegram.org", "t.me", "twitch.tv",
    "www.twitch.tv", "tumblr.com", "www.tumblr.com", "mastodon.social",
    "bsky.app", "www.bsky.app", "vk.com", "www.vk.com", "ok.ru",
    "wechat.com", "weibo.com", "www.weibo.com", "quora.com", "www.quora.com",
    "medium.com", "www.medium.com", "threads.com", "kooapp.com",
    # Common adult-content domains. The study host allowlist remains the main
    # safeguard; this list is an extra deny layer, not a complete classifier.
    "pornhub.com", "www.pornhub.com", "xvideos.com", "www.xvideos.com",
    "xnxx.com", "www.xnxx.com", "xhamster.com", "www.xhamster.com",
    "redtube.com", "www.redtube.com", "youporn.com", "www.youporn.com",
    "youjizz.com", "www.youjizz.com", "eporner.com", "www.eporner.com",
    "spankbang.com", "www.spankbang.com", "tube8.com", "www.tube8.com",
    "chaturbate.com", "www.chaturbate.com", "onlyfans.com", "www.onlyfans.com",
    "xvideos2.com", "xhamsterlive.com", "brazzers.com", "www.brazzers.com",
    "rule34.xxx", "nhentai.net", "www.nhentai.net",
    "tipsnetbd.com", "www.tipsnetbd.com", "viralbd.com", "www.viralbd.com",
    "sabitabhabi.com", "www.sabitabhabi.com",
}
_STUDY_BLOCKED_WILDCARDS = (
    "*.youtube.com", "*.youtu.be", "*.googlevideo.com", "*.youtube-nocookie.com",
    "*.bing.com", "*.duckduckgo.com", "*.yahoo.com", "*.yandex.com",
    "*.yandex.ru", "*.ecosia.org", "*.qwant.com", "*.startpage.com",
    "*.naver.com", "*.daum.net", "*.baidu.com", "*.brave.com",
    "*.sogou.com", "*.sogou.net", "*.seznam.cz", "*.kagi.com",
    "*.mojeek.com", "*.swisscows.com", "*.metager.de", "*.yep.com",
    "*.you.com", "*.phind.com", "*.perplexity.ai", "*.komo.ai",
    "*.andisearch.com", "*.360.cn", "*.so.com", "*.nifty.com",
    "*.facebook.com", "*.instagram.com", "*.threads.net", "*.twitter.com",
    "*.x.com", "*.tiktok.com", "*.reddit.com", "*.snapchat.com",
    "*.pinterest.com", "*.linkedin.com", "*.discord.com", "*.whatsapp.com",
    "*.whatsapp.net", "*.telegram.org", "*.t.me", "*.twitch.tv",
    "*.tumblr.com", "*.mastodon.social", "*.bsky.app", "*.vk.com", "*.ok.ru",
    "*.wechat.com", "*.weibo.com", "*.quora.com", "*.medium.com",
    "*.kooapp.com", "*.pornhub.com", "*.xvideos.com", "*.xnxx.com",
    "*.xhamster.com", "*.redtube.com", "*.youporn.com", "*.youjizz.com",
    "*.eporner.com", "*.spankbang.com", "*.tube8.com", "*.chaturbate.com",
    "*.onlyfans.com", "*.brazzers.com", "*.nhentai.net",
    "*.tipsnetbd.com", "*.viralbd.com", "*.sabitabhabi.com",
)
# Exact config entries removed from existing user configs during migration.
# ("*.google.com" is stripped here but not globally blocked, because
# notebooklm.google.com must keep working.)
_STUDY_LEGACY_BLOCKED_PATTERNS = (
    set(_STUDY_BLOCKED_HOSTS) | set(_STUDY_BLOCKED_WILDCARDS)
    | {"*.google.com", "*.google"})


def _host_blocked(host):
    host = (host or "").lower().split(":")[0]
    if not host:
        return False
    if host in _STUDY_BLOCKED_HOSTS:
        return True
    # Google Search is also served from country-specific Google domains.
    # Keep the explicitly needed NotebookLM and sign-in endpoints available.
    google_service_exceptions = {
        "notebooklm.google.com", "accounts.google.com", "clients6.google.com",
        "apis.google.com",
    }
    if (host not in google_service_exceptions
            and re.search(r"(?:^|\.)google\.[a-z]{2,}(?:\.[a-z]{2,})?$", host)):
        return True
    # A search host remains denied even if someone adds it to their allowlist.
    if "search" in host.split(".") or "websearch" in host.split("."):
        return True
    # Catch obvious adult-category labels even when a specific host is not
    # listed. Unknown hosts are still denied by the study allowlist.
    if re.search(r"(?:^|[.-])(adult|porn|porno|xxx|sex|hentai|nsfw|nude)(?:[.-]|$)", host):
        return True
    for pattern in _STUDY_BLOCKED_WILDCARDS:
        base = pattern[1:]  # .example.com
        if host.endswith(base) and host != pattern[2:]:
            return True
    return False


def _is_youtube_host(host):
    host = (host or "").lower()
    return (host == "youtu.be" or host.endswith(".youtu.be")
            or host == "youtube.com" or host.endswith(".youtube.com")
            or host == "youtube-nocookie.com"
            or host.endswith(".youtube-nocookie.com"))


def _youtube_video_id(uri):
    """Extract a video id from a watch/short/live/embed/youtu.be URL."""
    try:
        raw = str(uri or "").strip()
        if not raw:
            return None
        if "://" not in raw:
            raw = "https://" + raw
        parsed = urlparse(raw)
        host = (parsed.hostname or "").lower()
        if host in ("youtu.be", "www.youtu.be"):
            vid = (parsed.path or "").strip("/").split("/")[0]
        elif _is_youtube_host(host):
            path = (parsed.path or "").strip("/")
            if path == "watch":
                vid = urllib.parse.parse_qs(parsed.query).get("v", [""])[0]
            elif path.startswith("watch/"):
                vid = path.split("/", 1)[1]
            else:
                vid = ""
                for prefix in ("embed/", "shorts/", "live/", "v/"):
                    if path.startswith(prefix):
                        vid = path[len(prefix):].split("/")[0]
                        break
        else:
            return None
        vid = str(vid or "").strip()
        return vid if re.fullmatch(r"[A-Za-z0-9_-]{6,}", vid) else None
    except Exception:
        return None


def _edge_launch_url(uri):
    """URL to load in Edge app mode."""
    raw = str(uri or "").strip()
    if not raw:
        return None
    if "://" not in raw:
        raw = "https://" + raw
    try:
        parsed = urlparse(raw)
        if parsed.scheme not in ("http", "https"):
            return None
        return raw
    except Exception:
        return None


EDGE_PROFILE_DIR = os.path.join(LEDGER_DIR, "study-edge-profile")
# Only the embedded player (not the YouTube watch UI) is allowed in Edge.
_EDGE_EXTRA_ALLOW_REGEXES = ()


def _edge_allow_regexes():
    patterns = list(_STUDY_DEFAULTS["allow_hosts"])
    try:
        cfg = _study_config()
        patterns = cfg.get("allow_hosts") or patterns
    except Exception:
        pass
    regexes = list(_EDGE_EXTRA_ALLOW_REGEXES)
    seen = set(regexes)
    for pattern in patterns:
        pattern = str(pattern or "").strip().lower()
        if not pattern or pattern in seen:
            continue
        seen.add(pattern)
        if pattern.startswith("*."):
            if _host_blocked(pattern[2:]):
                continue
            host = re.escape(pattern[2:])
            regexes.append(rf"^https?://([^/]+\.)?{host}(:\d+)?(/|$)")
        else:
            if _host_blocked(pattern):
                continue
            host = re.escape(pattern)
            regexes.append(rf"^https?://{host}(:\d+)?(/|$)")
    return regexes


def _ensure_edge_extension():
    """Write a small Edge navigation guard: block every top-level page except
    the study allowlist and the YouTube embed player."""
    try:
        ext_dir = os.path.join(EDGE_PROFILE_DIR, "focus-study-guard")
        os.makedirs(ext_dir, exist_ok=True)
        manifest = {
            "manifest_version": 3,
            "name": "Focus Study Guard",
            "version": "1.1",
            "description": "Blocks non-study pages and filters explicit input in Study Mode",
            "permissions": ["declarativeNetRequest"],
            "host_permissions": ["<all_urls>"],
            "content_scripts": [{
                "matches": ["http://*/*", "https://*/*"],
                "js": ["focus-input-filter.js"],
                "run_at": "document_start",
                "all_frames": True,
            }],
            "declarative_net_request": {
                "rule_resources": [{
                    "id": "study_rules",
                    "enabled": True,
                    "path": "rules.json",
                }]
            },
        }
        rules = []
        rule_id = 1
        # Block search engines, social media, adult domains, full YouTube
        for host in sorted(_STUDY_BLOCKED_HOSTS):
            rules.append({
                "id": rule_id,
                "priority": 1,
                "action": {"type": "block"},
                "condition": {
                    "urlFilter": f"||{host}^",
                    "resourceTypes": ["main_frame", "sub_frame"],
                },
            })
            rule_id += 1
        for wildcard in sorted(_STUDY_BLOCKED_WILDCARDS):
            base = wildcard.lstrip("*.")
            rules.append({
                "id": rule_id,
                "priority": 1,
                "action": {"type": "block"},
                "condition": {
                    "urlFilter": f"||{base}^",
                    "resourceTypes": ["main_frame", "sub_frame"],
                },
            })
            rule_id += 1
        # Block adult label regexes
        rules.append({
            "id": rule_id,
            "priority": 1,
            "action": {"type": "block"},
            "condition": {
                "regexFilter": r"^https?://([^/]+\.)?(adult|porn|porno|xxx|sex|hentai|nsfw|nude)[.-]",
                "resourceTypes": ["main_frame", "sub_frame"],
            },
        })
        rule_id += 1
        # Block regional Google search frontends
        rules.append({
            "id": rule_id,
            "priority": 1,
            "action": {"type": "block"},
            "condition": {
                "regexFilter": r"^https?://([^/]+\.)?google\.[a-z]{2,}(/|$)",
                "resourceTypes": ["main_frame", "sub_frame"],
            },
        })
        rule_id += 1
        # Whitelist permitted exceptions: NotebookLM and Google sign-in
        for exc in ("notebooklm.google.com", "notebook.google.com", "notebook.google",
                    "accounts.google.com", "clients6.google.com", "apis.google.com"):
            rules.append({
                "id": rule_id,
                "priority": 2,
                "action": {"type": "allow"},
                "condition": {
                    "urlFilter": f"||{exc}^",
                    "resourceTypes": ["main_frame", "sub_frame"],
                },
            })
            rule_id += 1
        for filename, payload in (("manifest.json", manifest),
                                  ("rules.json", rules),
                                  ("focus-input-filter.js", INPUT_FILTER_JS)):
            path = os.path.join(ext_dir, filename)
            text = payload if isinstance(payload, str) else json.dumps(payload, indent=2)
            try:
                with open(path) as f:
                    if f.read() == text:
                        continue
            except OSError:
                pass
            with open(path, "w") as f:
                f.write(text)
        return ext_dir
    except Exception as e:
        print(f"edge extension setup error: {e}", flush=True)
        return None


def _find_edge():
    for candidate in ("microsoft-edge", "microsoft-edge-stable", "msedge"):
        path = shutil.which(candidate)
        if path:
            return path
    for path in ("/usr/bin/microsoft-edge", "/usr/bin/microsoft-edge-stable",
                 "/opt/microsoft/msedge/msedge"):
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path
    return None


def _open_in_edge(uri):
    """Open an allowed page in a dedicated Edge app window (no address bar)."""
    edge = _find_edge()
    target = _edge_launch_url(uri)
    if edge is None or not target:
        return False
    try:
        os.makedirs(EDGE_PROFILE_DIR, exist_ok=True)
        command = [edge, f"--app={target}",
                   f"--user-data-dir={EDGE_PROFILE_DIR}",
                   "--start-fullscreen", "--no-first-run",
                   "--no-default-browser-check", "--disable-background-mode",
                   "--disable-translate",
                   "--disable-features=Translate,msEdgeSidebar"]
        ext_dir = _ensure_edge_extension()
        if ext_dir:
            command.extend([f"--disable-extensions-except={ext_dir}",
                            f"--load-extension={ext_dir}"])
        subprocess.Popen(
            command,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            start_new_session=True)
        return True
    except Exception as e:
        print(f"edge launch error: {e}", flush=True)
        return False


# Only the PDF Materials Upload conversation is exposed in Telegram Web.
TELEGRAM_WEB_HOST = "web.telegram.org"
TELEGRAM_WEB_PATH = "/k"
TELEGRAM_WEB_PATHS = {"/k", "/a"}
TELEGRAM_GROUP_HASH = "-1004415493319"
TELEGRAM_GROUP_URL = (
    f"https://{TELEGRAM_WEB_HOST}{TELEGRAM_WEB_PATH}/#{TELEGRAM_GROUP_HASH}")
TELEGRAM_TARGET_PEER_PATH = os.path.join(LEDGER_DIR, "telegram-target-peer")
TELEGRAM_BIPROVA_PEER_PATH = os.path.join(LEDGER_DIR, "telegram-biprova-peer")


def _load_telegram_target_peer():
    try:
        with open(TELEGRAM_TARGET_PEER_PATH) as f:
            peer = f.read().strip()
        return peer if re.fullmatch(r"-?\d{5,}", peer) else ""
    except Exception:
        return ""


def _load_telegram_biprova_peer():
    try:
        with open(TELEGRAM_BIPROVA_PEER_PATH) as f:
            peer = f.read().strip()
        return peer if re.fullmatch(r"-?\d{5,}", peer) else ""
    except Exception:
        return ""


def _remember_telegram_target_peer(peer):
    peer = str(peer or "").strip()
    if not re.fullmatch(r"-?\d{5,}", peer):
        return False
    try:
        os.makedirs(LEDGER_DIR, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix=".telegram-peer-", dir=LEDGER_DIR)
        with os.fdopen(fd, "w") as f:
            f.write(peer)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(temporary, 0o600)
        os.replace(temporary, TELEGRAM_TARGET_PEER_PATH)
        return True
    except Exception as e:
        print(f"Telegram group pin save error: {e}", flush=True)
        try:
            if "temporary" in locals() and os.path.exists(temporary):
                os.remove(temporary)
        except OSError:
            pass
        return False


def _telegram_peer_message(_manager, result):
    try:
        peer = result.get_js_value().to_string()
        _remember_telegram_target_peer(peer)
    except Exception as e:
        print(f"Telegram group pin message error: {e}", flush=True)


def _focus_input_blocked_message(_manager, result):
    try:
        try:
            val = result.get_js_value().to_string()
        except Exception:
            val = "blocked"
        count, suspended = _record_input_violation()
        print(f"[FocusInputFilter] Keyword block recorded ('{val}'): {count}/10 in 5m (suspended={suspended})", flush=True)
        if _study_block_count_updater:
            GLib.idle_add(_study_block_count_updater, count)
        if suspended:
            GLib.idle_add(_trigger_study_suspension)
    except Exception as e:
        print(f"focusInputBlocked handler error: {e}", flush=True)


def _page_allowed(uri, patterns):
    """Host allowlist plus a Telegram Web entry point pinned to one group."""
    try:
        if not uri:
            return False
        uri_lower = uri.strip().lower()
        if uri_lower == "about:blank":
            return True
        if uri_lower in ("tg-materials", "pdf-materials", "telegram-materials"):
            return True
        if uri_lower.startswith("blob:"):
            inner = uri[5:]
            inner_host = (urlparse(inner).hostname or "").lower()
            if inner_host:
                return _host_allowed(inner_host, patterns)
            return False
        parsed = urlparse(uri)
        if parsed.scheme not in ("http", "https"):
            return False
        host = (parsed.hostname or "").lower()
        if _host_blocked(host):
            return False
        if host == TELEGRAM_WEB_HOST:
            peer = _load_telegram_target_peer()
            biprova_peer = _load_telegram_biprova_peer()
            fragment = parsed.fragment.lower()
            allowed_fragments = {
                TELEGRAM_GROUP_HASH.lower(),
                "-1004415493319", "4415493319", "pdf258upload",
                "biprova", "biprov", "biprova20", "biprova_20"
            }
            if peer:
                allowed_fragments.add(peer.lower())
                allowed_fragments.add(peer.replace("-100", "").lower())
            if biprova_peer:
                allowed_fragments.add(biprova_peer.lower())
                allowed_fragments.add(biprova_peer.replace("-100", "").lower())
            return ((parsed.path or "/").rstrip("/").lower() in TELEGRAM_WEB_PATHS
                    and (fragment in allowed_fragments or not fragment)
                    and _host_allowed(host, patterns))
        telegram_domains = ("telegram.org", "telegram.me", "telegram.dog",
                            "cdn-telegram.org", "telesco.pe", "t.me")
        if any(host == domain or host.endswith("." + domain)
               for domain in telegram_domains):
            return False
        if not _host_allowed(host, patterns):
            return False
        return True
    except Exception:
        return False


def _scan_media(roots, limit=6000):
    """All PDFs/images under roots (whole laptop). Newest first."""
    found = []
    exts = MEDIA_EXTS
    for root in roots:
        root = os.path.expanduser(root)
        if not os.path.isdir(root):
            continue
        for dirpath, dirnames, filenames in os.walk(root, onerror=lambda e: None):
            dirnames[:] = [d for d in dirnames
                           if not d.startswith(".") and d not in _SCAN_SKIP]
            for fn in filenames:
                if os.path.splitext(fn)[1].lower() in exts:
                    p = os.path.join(dirpath, fn)
                    try:
                        found.append((os.path.getmtime(p), p))
                    except Exception:
                        found.append((0, p))
                    if len(found) >= limit:
                        found.sort(reverse=True)
                        return found
    found.sort(reverse=True)
    return found


def _copy_into_inbox(paths, exts):
    """Copy allowed media files into the study inbox. Returns copied count."""
    copied = 0
    try:
        os.makedirs(STUDY_INBOX, exist_ok=True)
    except Exception as e:
        print(f"inbox create error: {e}", flush=True)
        return 0
    for src in paths:
        try:
            if not os.path.isfile(src):
                continue
            ext = os.path.splitext(src)[1].lower()
            if ext not in exts:
                continue
            dst = os.path.join(STUDY_INBOX, os.path.basename(src))
            if os.path.abspath(src) != os.path.abspath(dst):
                if os.path.exists(dst):
                    stem, e = os.path.splitext(dst)
                    dst = f"{stem}-{int(time.time())}{e}"
                shutil.copy2(src, dst)
            copied += 1
        except Exception as e:
            print(f"inbox copy error: {e}", flush=True)
    return copied


def _import_usb_pdf_uri(uri):
    """Copy one PDF or image from storage, USB drive or phone into the Study inbox."""
    scheme = urllib.parse.urlsplit(uri or "").scheme.lower()
    if scheme not in ("file", "mtp", "gphoto2"):
        return None, "Choose a file from storage, USB drive or a connected phone"
    try:
        source = Gio.File.new_for_uri(uri)
        raw_name = source.get_basename() or ""
        lower_name = raw_name.lower()
        if not lower_name.endswith(tuple(MEDIA_EXTS)):
            return None, "Only PDF and image files can be imported"
        name = re.sub(r"[^\w .()\-]", "_", raw_name, flags=re.UNICODE).strip(" .")
        if not name or not name.lower().endswith(tuple(MEDIA_EXTS)):
            return None, "Invalid filename"
        os.makedirs(STUDY_INBOX, exist_ok=True)
        _, ext = os.path.splitext(name)
        ext = ext.lower()
        temporary = os.path.join(STUDY_INBOX, ".usb-import-" + secrets.token_hex(8) + ext)
        source.copy(Gio.File.new_for_path(temporary), Gio.FileCopyFlags.NONE,
                    None, None, None)
        try:
            if ext == ".pdf":
                with open(temporary, "rb") as f:
                    signature = f.read(1024)
                if b"%PDF-" not in signature:
                    return None, "The selected file is not a valid PDF"
            else:
                try:
                    info = GdkPixbuf.Pixbuf.get_file_info(temporary)
                    if not info or info[1] <= 0 or info[2] <= 0:
                        return None, "The selected file is not a valid image"
                except Exception:
                    pass
            stem, suffix = os.path.splitext(name)
            target = os.path.join(STUDY_INBOX, name)
            index = 1
            while os.path.exists(target):
                index += 1
                target = os.path.join(STUDY_INBOX, f"{stem} ({index}){suffix}")
            os.replace(temporary, target)
            temporary = ""
            return target, None
        finally:
            if temporary:
                try:
                    os.remove(temporary)
                except OSError:
                    pass
    except Exception as e:
        print(f"File import error: {e}", flush=True)
        return None, "Could not read that file from the connected device"


def _pdf_metadata(path):
    pages, page_pts = 1, (595.0, 842.0)
    try:
        r = _run(["pdfinfo", path], capture_output=True, text=True, timeout=20)
        for line in (r.stdout or "").splitlines():
            if line.lower().startswith("pages:"):
                pages = max(1, int(line.split(":", 1)[1].strip()))
            elif line.lower().startswith("page size:"):
                try:
                    dims = line.split(":", 1)[1].split("pts", 1)[0]
                    width, height = dims.split("x", 1)
                    page_pts = (float(width.strip()), float(height.strip()))
                except Exception:
                    pass
    except Exception:
        pass
    return pages, page_pts


def _pdf_pages(path):
    return _pdf_metadata(path)[0]


def _render_pdf_page(path, page, zoom=1.0, cancel=None):
    """Render one PDF page to a PNG (poppler) and return a pixbuf."""
    out = None
    try:
        fd, out = tempfile.mkstemp(prefix=f"focus-pdf-{os.getpid()}-{page}-")
        os.close(fd)
        os.remove(out)
        dpi = max(12, min(168, int(96 * min(float(zoom), 1.75))))
        cmd = ["pdftoppm", "-png", "-r", str(dpi), "-f", str(page),
               "-l", str(page), "-singlefile", path, out]
        proc = subprocess.Popen(_HOST + cmd, stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL)
        deadline = time.monotonic() + 45
        while proc.poll() is None:
            if (cancel is not None and cancel()) or time.monotonic() >= deadline:
                proc.terminate()
                try:
                    proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=2)
                proc.communicate()
                return None
            time.sleep(0.1)
        proc.communicate()
        png = out + ".png"
        if proc.returncode == 0 and os.path.exists(png):
            info = GdkPixbuf.Pixbuf.get_file_info(png)
            if info and (info[1] > 2200 or info[2] > 3000):
                return GdkPixbuf.Pixbuf.new_from_file_at_scale(png, 2200, 3000, True)
            return GdkPixbuf.Pixbuf.new_from_file(png)
        if proc.returncode != 0:
            print(f"pdftoppm failed with exit code {proc.returncode}", flush=True)
    except Exception as e:
        print(f"pdf render error: {e}", flush=True)
    finally:
        if out:
            for suffix in ("", ".png"):
                try:
                    os.remove(out + suffix)
                except OSError:
                    pass
    return None


def _configure_study_settings(st):
    if st is None:
        return
    try:
        st.set_enable_developer_extras(False)
        st.set_enable_html5_local_storage(True)
        st.set_enable_html5_database(True)
        st.set_enable_javascript(True)
        st.set_enable_page_cache(False)
        st.set_enable_webgl(True)
        st.set_javascript_can_open_windows_automatically(True)
    except Exception:
        pass
    for method, val in [
        ("set_enable_2d_canvas_acceleration", True),
        ("set_enable_accelerated_2d_canvas", True),
        ("set_enable_webaudio", True),
        ("set_enable_mediasource", True),
        ("set_enable_media_stream", True),
        ("set_enable_media_capabilities", True),
        ("set_enable_encrypted_media", True),
        ("set_enable_site_specific_quirks", True),
        ("set_enable_fullscreen", True),
        ("set_allow_modal_dialogs", True),
        ("set_allow_top_navigation_to_data_urls", True),
        ("set_media_playback_allows_inline", True),
        ("set_media_playback_requires_user_gesture", False),
        ("set_enable_smooth_scrolling", True),
    ]:
        try:
            getattr(st, method)(val)
        except Exception:
            pass


def show_study_window(parent=None, end_ts=None):
    """Study container with whitelisted links, a PDF/image reader and a page dock.
    When opened from lockout, the lockout countdown keeps running."""
    global _study_win, _study_parent, _study_web_context, _study_ucm

    if _is_study_suspended():
        until = _get_study_suspended_until()
        rem_m = max(1, int(math.ceil((until - time.time()) / 60.0)))
        notify(f"Study Mode is temporarily suspended ({rem_m}m remaining).")
        return

    if WebKit2 is None:
        print("WebKit2 unavailable — study view disabled", flush=True)
        return

    # Lock the desktop down before the (sometimes slow) GTK/WebKit window is
    # built. Otherwise the desktop is briefly visible and right-click ->
    # Settings -> Extensions can disable the Shell lockout overlay.
    _touch_study_starting()
    _ensure_shell_extension_enabled(force=True)

    if end_ts is None:
        _saved = _load_suspend_state()
        if _saved > time.time():
            end_ts = _saved

    cfg = _study_config()
    allow = cfg.get("allow_hosts") or _STUDY_DEFAULTS["allow_hosts"]
    dl_exts = set(x.lower() for x in (cfg.get("download_exts") or MEDIA_EXTS))

    if parent is not None:
        _study_parent = parent
        try:
            parent.hide()
        except Exception:
            pass

    win = _new_fullscreen("Study")
    _study_win = win
    win.set_modal(True)
    _swallow_shell_keys(win)
    guard_id = _arm_focus_guard(win)

    css = Gtk.CssProvider()
    css.load_from_data(b"""
    .studywin { background: #0b1220; }
    .studybar { background: #0d1527; border-bottom: 1px solid rgba(148, 163, 184, 0.16);
                padding: 2px 10px; min-height: 32px; }
    .studybar entry { background: rgba(15, 23, 42, 0.85); color: #f1f5f9;
                      border: 1px solid rgba(148, 163, 184, 0.25);
                      border-radius: 5px; padding: 2px 8px; font-family: Inter, sans-serif;
                      font-size: 11.5px; min-height: 25px; }
    .studybar entry:focus { border-color: #3b82f6; background: rgba(15, 23, 42, 0.95); }
    .topbar-brand { font-family: Inter, sans-serif; font-size: 11.5px; font-weight: 700;
                    letter-spacing: 0.8px; color: #93c5fd; background: rgba(30, 58, 138, 0.4);
                    border: 1px solid rgba(96, 165, 250, 0.3); padding: 2px 8px; border-radius: 5px; }
    .topbar-clock { font-family: monospace; font-size: 11.5px;
                    font-weight: 700; color: #60a5fa; background: rgba(15, 23, 42, 0.85);
                    border: 1px solid rgba(96, 165, 250, 0.35); padding: 2px 7px; border-radius: 5px; }
    .topbar-timer { font-family: monospace; font-size: 11.5px;
                    font-weight: 700; color: #93c5fd; background: rgba(30, 58, 138, 0.4);
                    border: 1px solid rgba(96, 165, 250, 0.35); padding: 2px 7px; border-radius: 5px; }
    .topbar-timer-normal { color: #93c5fd; background: rgba(30, 58, 138, 0.4); border-color: rgba(96, 165, 250, 0.35); }
    .topbar-timer-lockout { color: #fca5a5; background: rgba(153, 27, 27, 0.45); border-color: rgba(248, 113, 113, 0.45); }
    .topbar-btn { background: rgba(30, 41, 59, 0.7); border: 1px solid rgba(148, 163, 184, 0.2);
                  border-radius: 5px; color: #e2e8f0; font-family: Inter, sans-serif;
                  font-size: 11.5px; font-weight: 600; padding: 2px 8px; min-height: 25px;
                  box-shadow: none; }
    .topbar-btn:hover { background: rgba(59, 130, 246, 0.25); border-color: rgba(96, 165, 250, 0.45);
                        color: #ffffff; }
    .topbar-btn:active { background: rgba(37, 99, 235, 0.4); }
    .topbar-stat { font-family: Inter, sans-serif; font-size: 11px; font-weight: 600;
                   color: #94a3b8; background: rgba(15, 23, 42, 0.7);
                   border: 1px solid rgba(148, 163, 184, 0.2); border-radius: 5px;
                   padding: 2px 7px; min-height: 25px; }
    .sidebar { background: #101b2c; border-right: 1px solid rgba(148, 163, 184, 0.16);
               padding: 5px 6px; min-width: 230px; }
    .player-page { background: #000000; }
    .player-header { background: #0d1527; border-bottom: 1px solid rgba(148, 163, 184, 0.2);
                     padding: 4px 10px; min-height: 32px; }
    .player-title { font-family: Inter, sans-serif; font-size: 11.5px; font-weight: 700;
                    letter-spacing: 0.5px; color: #93c5fd; }
    .player-sub { font-family: Inter, sans-serif; font-size: 10.5px; color: #94a3b8; }
    .studyhead { font-family: Inter, sans-serif; font-size: 13px; color: #dbeafe;
                 letter-spacing: 1.5px; font-weight: bold; }
    .studytime { font-family: Inter, sans-serif; font-size: 12.5px; color: #9ca3af; }
    .sidehead { font-family: Inter, sans-serif; font-size: 10px; color: #8fa2bd;
                letter-spacing: 1px; font-weight: 700; padding: 3px 4px 2px 4px; }
    .sidebar separator { background: rgba(148, 163, 184, 0.16); margin: 2px 1px; }
    .side-paned separator { background: rgba(148, 163, 184, 0.18); min-height: 2px; margin: 2px 0; }
    .side-paned separator:hover { background: #3b82f6; }
    .sidebtn { background: rgba(255,255,255,0.035); border: 1px solid rgba(148,163,184,0.10);
               box-shadow: none; padding: 3px 6px; border-radius: 5px; margin: 0; min-height: 26px; }
    .sidebtn:hover { background: rgba(59, 130, 246, 0.16);
                     border-color: rgba(96,165,250,0.32); }
    .sidebtn label { font-family: Inter, sans-serif; font-size: 12px; color: #e2e8f0; }
    .sidebtn:active { background: rgba(37, 99, 235, 0.30); }
    .dockpane { background: #101b2c; padding: 2px 1px; }
    .dockrow { background: rgba(255,255,255,0.035); border: 1px solid rgba(148,163,184,0.10);
               border-radius: 6px; padding: 2px 3px; margin: 1px 0; }
    .dockrow:hover { background: rgba(59, 130, 246, 0.16);
                     border-color: rgba(96,165,250,0.32); }
    .dockrow-active { background: rgba(37, 99, 235, 0.30);
                      border-color: rgba(96,165,250,0.55); }
    .dock-title-btn { background: transparent; border: none; box-shadow: none;
                      padding: 1px 2px; border-radius: 4px; }
    .dock-title-btn:hover { background: rgba(59, 130, 246, 0.18); }
    .dock-title-btn label { font-family: Inter, sans-serif; font-size: 11.5px;
                            color: #e2e8f0; }
    .dockbtn { background: transparent; border: none; box-shadow: none;
               padding: 0; min-width: 20px; min-height: 20px; border-radius: 4px; }
    .dockbtn label { font-size: 12px; color: #94a3b8; }
    .dockbtn:hover { background: rgba(59, 130, 246, 0.30); }
    .dockbtn:hover label { color: #dbeafe; }
    .dockclose:hover { background: rgba(239, 68, 68, 0.32); }
    .dockclose:hover label { color: #fca5a5; }
    .dockempty { font-family: Inter, sans-serif; font-size: 10px; color: #64748b;
                 padding: 8px 6px; }
    .panel { background: #f8fafc; }
    .studytip { font-family: Inter, sans-serif; font-size: 10px; color: #9ca3af; padding: 1px 4px; }
    .homepage { background: #0b1220; padding: 40px; }
    .floatbar { background: rgba(12, 22, 40, 0.92); border-radius: 14px;
                padding: 7px; border: 1px solid rgba(96, 165, 250, 0.28); }
    .floatbtn { background: rgba(30, 58, 95, 0.55); border: none; box-shadow: none;
                border-radius: 9px; padding: 0; min-width: 38px; min-height: 38px; }
    .floatbtn:hover { background: rgba(37, 99, 235, 0.55); }
    .webnavbtn { min-width: 28px; min-height: 28px; padding: 0; }
    .webnavbtn label { font-size: 17px; }
    .blockcountbtn { padding: 3px 10px; border-radius: 5px; font-family: Inter, sans-serif;
                     font-size: 11.5px; font-weight: 700; min-height: 25px; box-shadow: none; }
    .blockcount-clean { background: rgba(16, 185, 129, 0.12); color: #34d399;
                        border: 1px solid rgba(52, 211, 153, 0.35); }
    .blockcount-clean:hover { background: rgba(16, 185, 129, 0.22); }
    .blockcount-warn { background: rgba(239, 68, 68, 0.22); color: #f87171;
                       border: 1px solid rgba(248, 113, 113, 0.55); }
    .blockcount-warn:hover { background: rgba(239, 68, 68, 0.32); }
    .floatbtn-on { background: rgba(59, 130, 246, 0.85); }
    .floatbtn label { font-size: 16px; color: #e5eefc; }
    .floatpage { font-family: Inter, sans-serif; font-size: 10px; color: #93a8c9;
                 padding: 2px 0; }
    .toastlbl { background: rgba(15, 30, 55, 0.95); border-radius: 10px;
                border: 1px solid rgba(96, 165, 250, 0.35);
                padding: 8px 16px; font-family: Inter, sans-serif;
                font-size: 12px; color: #e5eefc; }
    .backbtn { background: rgba(37, 99, 235, 0.22); border: 1px solid rgba(96, 165, 250, 0.35);
               box-shadow: none; border-radius: 10px; margin-top: 6px; }
    .backbtn:hover { background: rgba(37, 99, 235, 0.45); }
    .backbtn label { font-family: Inter, sans-serif; font-size: 13px; color: #dbeafe;
                     font-weight: bold; }
    .loadscreen { background: rgba(15, 28, 47, 0.94); border-radius: 10px;
                  border: 1px solid rgba(96,165,250,0.24); padding: 8px 12px; }
    .loadhead { font-family: Inter, sans-serif; font-size: 12px; font-weight: 600;
                color: #dbeafe; }
    .recentpanel { background: #101b2c; border: 1px solid rgba(96,165,250,0.34);
                   border-radius: 12px; padding: 12px; }
    .recentheading { font-family: Inter, sans-serif; font-size: 11px; font-weight: 700;
                     letter-spacing: 1px; color: #bfdbfe; padding: 4px 4px 10px; }
    .recentrow { background: rgba(255,255,255,0.04); border: 1px solid rgba(148,163,184,0.12);
                 box-shadow: none; border-radius: 8px; padding: 8px; }
    .recentrow:hover { background: rgba(37,99,235,0.25); }
    .recentrow label { color: #e2e8f0; font-family: Inter, sans-serif; font-size: 11px; }
    .netpanel { background: #101b2c; padding: 12px; }
    .nettitle { color: #e5eefc; font-family: Inter, sans-serif; font-weight: 700;
                font-size: 14px; }
    .netstatus { color: #9fb1c9; font-family: Inter, sans-serif; font-size: 11px; }
    .netrow { background: rgba(255,255,255,0.04); border: 1px solid rgba(148,163,184,0.12);
              border-radius: 9px; padding: 7px; }
    .netrow:hover { background: rgba(37,99,235,0.18); }
    .netrowname { color: #e2e8f0; font-family: Inter, sans-serif; font-size: 12px;
                  font-weight: 600; }
    .netmeta { color: #9fb1c9; font-family: Inter, sans-serif; font-size: 10px; }
    .tg-shell { background: #101b2c; border-bottom: 1px solid rgba(96,165,250,0.25);
                padding: 10px 16px; }
    .tg-title { color: #e5eefc; font-family: Inter, sans-serif; font-size: 13px;
                font-weight: 700; letter-spacing: 0.6px; }
    .tg-subtitle { color: #9fb1c9; font-family: Inter, sans-serif; font-size: 10px; }
    .tg-action { background: rgba(30,58,95,0.7); border: 1px solid rgba(96,165,250,0.28);
                 box-shadow: none; border-radius: 8px; padding: 5px 10px; }
    .tg-action label { color: #e5eefc; font-family: Inter, sans-serif; font-size: 11px;
                       font-weight: 600; }
    .dl-popover { background: #0f172a; border: 1px solid rgba(148, 163, 184, 0.25);
                  border-radius: 12px; padding: 12px; }
    .dl-head { font-family: Inter, sans-serif; font-size: 12px; font-weight: 700;
               color: #f1f5f9; letter-spacing: 0.5px; }
    .dl-row { background: rgba(255, 255, 255, 0.04); border: 1px solid rgba(148, 163, 184, 0.12);
              border-radius: 8px; padding: 7px 10px; margin: 2px 0; }
    .dl-row:hover { background: rgba(37, 99, 235, 0.16); }
    .dl-filename { font-family: Inter, sans-serif; font-size: 11px; font-weight: 600; color: #e2e8f0; }
    .dl-meta { font-family: 'JetBrains Mono', Inter, monospace; font-size: 10px; color: #94a3b8; }
    .dl-btn-action { background: rgba(30, 41, 59, 0.7); border: 1px solid rgba(148, 163, 184, 0.2);
                     border-radius: 5px; color: #cbd5e1; font-size: 10px; font-weight: 600; padding: 2px 8px; }
    .dl-btn-action:hover { background: rgba(59, 130, 246, 0.4); color: #ffffff; }
    .dl-progressbar trough { min-height: 4px; border-radius: 2px; background: rgba(148, 163, 184, 0.2); }
    .dl-progressbar progress { min-height: 4px; border-radius: 2px; background: #3b82f6; }
    .history-page { background: #0b1220; padding: 14px 18px; }
    .history-header { background: #101b2c; border: 1px solid rgba(148, 163, 184, 0.16);
                      border-radius: 9px; padding: 8px 14px; margin-bottom: 10px; }
    .history-title { font-family: Inter, sans-serif; font-size: 13px; font-weight: 700;
                     letter-spacing: 0.8px; color: #e2e8f0; }
    .history-badge { background: rgba(59, 130, 246, 0.2); color: #60a5fa;
                     border: 1px solid rgba(96, 165, 250, 0.35); font-size: 11px;
                     font-weight: 600; padding: 2px 8px; border-radius: 12px; }
    .history-search { background: rgba(15, 23, 42, 0.75); color: #f8fafc;
                      border: 1px solid rgba(148, 163, 184, 0.25); border-radius: 7px;
                      padding: 5px 12px; font-size: 12px; }
    .history-search:focus { border-color: #3b82f6; }
    .excel-scroll { background: #0b1220; border: 1px solid rgba(148, 163, 184, 0.18);
                    border-radius: 8px; }
    .excel-table { background-color: #0b1220; color: #e2e8f0; font-family: Inter, sans-serif;
                   font-size: 13px; }
    .excel-table:selected { background-color: #1e3a8a; color: #ffffff; }
    .excel-table header button { background: #111e33; color: #93c5fd; font-family: Inter, sans-serif;
                                 font-size: 12px; font-weight: 700; border: none;
                                 border-bottom: 2px solid #3b82f6;
                                 border-right: 1px solid rgba(148, 163, 184, 0.15); padding: 7px 10px; }
    .history-footer { font-family: Inter, sans-serif; font-size: 11px; color: #64748b; padding-top: 6px; }
    .sidebar-brand-card {
        background: linear-gradient(135deg, rgba(30, 58, 138, 0.42) 0%, rgba(15, 23, 42, 0.75) 100%);
        border: 1px solid rgba(96, 165, 250, 0.32);
        border-radius: 6px;
        padding: 4px 7px;
        margin: 0 0 3px 0;
    }
    .sidebar-brand-title {
        font-family: Inter, sans-serif;
        font-size: 12px;
        font-weight: 800;
        color: #93c5fd;
        letter-spacing: 0.8px;
    }
    .sidebar-brand-sub {
        font-family: Inter, sans-serif;
        font-size: 9.5px;
        color: #94a3b8;
        letter-spacing: 0.2px;
        margin-top: 1px;
    }
    .side-nav-box {
        margin-top: 0px;
    }
    .side-nav-btn {
        background: rgba(30, 41, 59, 0.6);
        border: 1px solid rgba(148, 163, 184, 0.22);
        box-shadow: none;
        border-radius: 4px;
        padding: 2px 6px;
        font-size: 10px;
        font-weight: 600;
        color: #cbd5e1;
    }
    .side-nav-btn:hover {
        background: rgba(59, 130, 246, 0.25);
        border-color: rgba(96, 165, 250, 0.45);
        color: #ffffff;
    }
    .side-nav-btn:disabled {
        opacity: 0.35;
    }
    .extend-btn {
        background: rgba(37, 99, 235, 0.22);
        border: 1px solid rgba(96, 165, 250, 0.4);
        color: #93c5fd;
        font-weight: 700;
    }
    .extend-btn:hover {
        background: rgba(37, 99, 235, 0.45);
        color: #ffffff;
        border-color: rgba(147, 197, 253, 0.7);
    }
    .extend-btn:disabled {
        opacity: 0.4;
    }
    .kw-popover { background: #0f172a; border: 1px solid rgba(96, 165, 250, 0.35); border-radius: 8px; padding: 6px; }
    .kw-feedback { font-size: 14px; font-weight: bold; min-width: 24px; color: #93c5fd; }
    """)
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    win.get_style_context().add_class("studywin")
    win.connect("delete-event", lambda *_: True)  # Alt+F4 blocked

    outer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
    bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
    bar.get_style_context().add_class("studybar")

    sidebar_toggle_btn = Gtk.Button(label="☰")
    sidebar_toggle_btn.get_style_context().add_class("topbar-btn")
    sidebar_toggle_btn.set_size_request(32, 26)
    sidebar_toggle_btn.set_tooltip_text("Toggle Sidebar (Ctrl+B)")
    bar.pack_start(sidebar_toggle_btn, False, False, 0)

    clock_lbl = Gtk.Label(label=time.strftime("🕒 %I:%M:%S %p"))
    clock_lbl.get_style_context().add_class("topbar-clock")
    clock_lbl.set_size_request(118, 26)
    clock_lbl.set_xalign(0.5)
    clock_lbl.set_yalign(0.5)
    clock_lbl.set_tooltip_text(time.strftime("%A, %d %B %Y"))
    bar.pack_start(clock_lbl, False, False, 0)

    time_lbl = Gtk.Label(label="")
    time_lbl.get_style_context().add_class("topbar-timer")
    time_lbl.set_size_request(118, 26)
    time_lbl.set_xalign(0.5)
    time_lbl.set_yalign(0.5)
    bar.pack_start(time_lbl, False, False, 0)

    extend_btn = Gtk.Button(label="➕ Extend")
    extend_btn.get_style_context().add_class("topbar-btn")
    extend_btn.get_style_context().add_class("extend-btn")
    extend_btn.set_size_request(74, 26)
    extend_btn.set_tooltip_text("Extend lockout duration (3 days / 7 days)")
    bar.pack_start(extend_btn, False, False, 0)

    address_entry = Gtk.Entry()
    address_entry.set_width_chars(16)
    address_entry.set_hexpand(True)
    address_entry.set_placeholder_text("🌐 Visit any website (opens in Edge) or YouTube link/ID…")
    address_entry.set_tooltip_text(
        "Enter any website to open in restricted Edge, or a YouTube video link to play natively. Search engines, social media and explicit keywords are blocked.")
    address_entry.set_activates_default(True)
    bar.pack_start(address_entry, True, True, 2)

    usb_import_btn = Gtk.Button(label="📂 Open")
    usb_import_btn.get_style_context().add_class("topbar-btn")
    usb_import_btn.set_size_request(66, 26)
    usb_import_btn.set_tooltip_text(
        "Open a PDF, image, or video directly")
    bar.pack_start(usb_import_btn, False, False, 0)

    add_kw_btn = Gtk.Button(label="🛡️ +Word")
    add_kw_btn.get_style_context().add_class("topbar-btn")
    add_kw_btn.set_size_request(76, 26)
    add_kw_btn.set_tooltip_text("Add blocked keyword")
    bar.pack_start(add_kw_btn, False, False, 0)

    history_btn = Gtk.Button(label="📋 History")
    history_btn.get_style_context().add_class("topbar-btn")
    history_btn.set_size_request(74, 26)
    history_btn.set_tooltip_text("Open reading history log")
    bar.pack_start(history_btn, False, False, 0)

    split_btn = Gtk.Button(label="◫ Split")
    split_btn.get_style_context().add_class("topbar-btn")
    split_btn.set_size_request(60, 26)
    split_btn.set_tooltip_text("Show two study pages side by side")
    bar.pack_start(split_btn, False, False, 0)

    # Downloads popover remains supported in background without occupying top bar space
    dl_btn = Gtk.Button(label="📥 Downloads")
    dl_btn.get_style_context().add_class("topbar-btn")
    dl_btn.set_tooltip_text("View active and recent downloads")

    recent_btn = Gtk.Button(label="🕒 Recent ▾")
    recent_btn.get_style_context().add_class("topbar-btn")
    recent_btn.set_size_request(78, 26)
    recent_btn.set_tooltip_text("Click to show recently visited sites and documents")
    bar.pack_start(recent_btn, False, False, 0)

    battery_lbl = Gtk.Label(label="🔋 —")
    battery_lbl.get_style_context().add_class("topbar-stat")
    battery_lbl.set_size_request(62, 26)
    battery_lbl.set_tooltip_text("Live battery charge")
    bar.pack_start(battery_lbl, False, False, 0)

    block_counter_btn = Gtk.Button(label="🛡️ 0/10")
    block_counter_btn.get_style_context().add_class("blockcountbtn")
    block_counter_btn.get_style_context().add_class("blockcount-clean")
    block_counter_btn.set_size_request(66, 26)
    block_counter_btn.set_tooltip_text(
        "Keyword blocks in last 5 minutes: 0/10. Reaching 10 blocks suspends Study Mode for 30 minutes.")
    bar.pack_start(block_counter_btn, False, False, 0)

    right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
    side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
    side.set_size_request(240, -1)
    side.set_hexpand(False)
    side.set_halign(Gtk.Align.START)
    side.get_style_context().add_class("sidebar")

    def _toggle_sidebar(*_):
        if side.get_visible():
            side.hide()
            sidebar_toggle_btn.set_label("☰")
            sidebar_toggle_btn.set_tooltip_text("Show Sidebar (Ctrl+B)")
        else:
            side.show_all()
            sidebar_toggle_btn.set_label("◧")
            sidebar_toggle_btn.set_tooltip_text("Hide Sidebar (Ctrl+B)")

    sidebar_toggle_btn.connect("clicked", _toggle_sidebar)

    # Study Mode brand header moved to top of sidebar
    brand_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
    brand_box.get_style_context().add_class("sidebar-brand-card")
    brand_title = Gtk.Label(label="📚 STUDY MODE")
    brand_title.get_style_context().add_class("sidebar-brand-title")
    brand_title.set_halign(Gtk.Align.START)
    brand_sub = Gtk.Label(label="Focused Learning Environment")
    brand_sub.get_style_context().add_class("sidebar-brand-sub")
    brand_sub.set_halign(Gtk.Align.START)
    brand_box.pack_start(brand_title, False, False, 0)
    brand_box.pack_start(brand_sub, False, False, 0)
    side.pack_start(brand_box, False, False, 0)

    # 55% Study links / 45% Open pages split container
    side_paned = Gtk.Paned(orientation=Gtk.Orientation.VERTICAL)
    side_paned.get_style_context().add_class("side-paned")

    # --- Upper pane: Study Links (55%) ---
    links_pane = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
    links_head = Gtk.Label(label="STUDY LINKS")
    links_head.get_style_context().add_class("sidehead")
    links_head.set_halign(Gtk.Align.START)
    links_pane.pack_start(links_head, False, False, 0)

    links_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
    links_scroll = Gtk.ScrolledWindow()
    links_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    links_scroll.set_vexpand(True)
    links_scroll.add(links_box)
    links_pane.pack_start(links_scroll, True, True, 0)

    # --- Lower pane: Open-page dock (replaces the old file library) ---
    lib_pane = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
    lib_pane.get_style_context().add_class("dockpane")

    dock_head = Gtk.Label(label="OPEN PAGES")
    dock_head.get_style_context().add_class("sidehead")
    dock_head.set_halign(Gtk.Align.START)

    dock_count = Gtk.Label(label="Nothing open yet")
    dock_count.get_style_context().add_class("studytip")
    dock_count.set_halign(Gtk.Align.START)
    dock_count.set_ellipsize(Pango.EllipsizeMode.END)
    dock_count.set_max_width_chars(24)

    dock_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
    dock_scroll = Gtk.ScrolledWindow()
    dock_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    dock_scroll.set_vexpand(True)
    dock_scroll.add(dock_box)

    lib_pane.pack_start(dock_head, False, False, 0)
    lib_pane.pack_start(dock_count, False, False, 0)
    lib_pane.pack_start(dock_scroll, True, True, 0)

    side_paned.pack1(links_pane, resize=True, shrink=False)
    side_paned.pack2(lib_pane, resize=True, shrink=False)
    side.pack_start(side_paned, True, True, 0)

    paned_split_done = [False]
    def _on_side_paned_allocate(_w, alloc):
        if not paned_split_done[0] and alloc.height > 100:
            paned_split_done[0] = True
            side_paned.set_position(int(alloc.height * 0.55))
    side_paned.connect("size-allocate", _on_side_paned_allocate)

    telegram_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
    telegram_header.get_style_context().add_class("tg-shell")
    tg_identity = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
    tg_title = Gtk.Label(label="PDF MATERIALS")
    tg_title.get_style_context().add_class("tg-title")
    tg_title.set_halign(Gtk.Align.START)
    tg_subtitle = Gtk.Label(label="Single-group view · Telegram Web K")
    tg_subtitle.get_style_context().add_class("tg-subtitle")
    tg_subtitle.set_halign(Gtk.Align.START)
    tg_identity.pack_start(tg_title, False, False, 0)
    tg_identity.pack_start(tg_subtitle, False, False, 0)
    telegram_header.pack_start(tg_identity, True, True, 0)
    tg_reload = Gtk.Button(label="↻  Group")
    tg_reload.get_style_context().add_class("tg-action")
    tg_reload.set_tooltip_text("Return to the PDF Materials group")
    tg_back = Gtk.Button(label="Back to Study")
    tg_back.get_style_context().add_class("tg-action")
    tg_block_counter_btn = Gtk.Button(label="🛡️ 0/10")
    tg_block_counter_btn.get_style_context().add_class("tg-action")
    tg_block_counter_btn.get_style_context().add_class("blockcountbtn")
    tg_block_counter_btn.get_style_context().add_class("blockcount-clean")
    tg_block_counter_btn.set_tooltip_text(
        "Keyword blocks in last 5 minutes: 0/10. Reaching 10 blocks suspends Study Mode for 30 minutes.")
    telegram_header.pack_end(tg_block_counter_btn, False, False, 2)
    telegram_header.pack_end(tg_back, False, False, 0)
    telegram_header.pack_end(tg_reload, False, False, 0)
    telegram_header.set_no_show_all(True)

    def _update_block_counter(explicit_count=None):
        count = _get_recent_violation_count() if explicit_count is None else explicit_count
        label_text = f"🛡️ {count}/10"
        for btn in (block_counter_btn, tg_block_counter_btn):
            try:
                btn.set_label(label_text)
                ctx = btn.get_style_context()
                if count > 0:
                    ctx.remove_class("blockcount-clean")
                    ctx.add_class("blockcount-warn")
                else:
                    ctx.remove_class("blockcount-warn")
                    ctx.add_class("blockcount-clean")
                btn.set_tooltip_text(
                    f"Keyword blocks in last 5 minutes: {count}/10. Reaching 10 blocks suspends Study Mode for 30 minutes.")
            except Exception:
                pass

    def _on_block_counter_click(*_):
        c = _get_recent_violation_count()
        _toast(f"Input filter: {c}/10 blocked keywords in last 5 minutes (10 blocks suspends Study Mode for 30m)")

    block_counter_btn.connect("clicked", _on_block_counter_click)
    tg_block_counter_btn.connect("clicked", _on_block_counter_click)

    global _study_block_count_updater
    _study_block_count_updater = _update_block_counter
    _update_block_counter()

    stack = Gtk.Stack()
    stack.set_hexpand(True)
    stack.set_vexpand(True)
    stack.set_transition_type(Gtk.StackTransitionType.NONE)
    stack_wrap = Gtk.Overlay()
    stack_wrap.add(stack)

    if _study_web_context is None:
        try:
            os.makedirs(STUDY_WEB_DATA_DIR, exist_ok=True)
            os.makedirs(STUDY_WEB_CACHE_DIR, exist_ok=True)
            data_manager = WebKit2.WebsiteDataManager(
                base_data_directory=STUDY_WEB_DATA_DIR,
                base_cache_directory=STUDY_WEB_CACHE_DIR)
            _study_web_context = WebKit2.WebContext.new_with_website_data_manager(
                data_manager)
            _cm = _study_web_context.get_cookie_manager()
            _cm.set_accept_policy(WebKit2.CookieAcceptPolicy.ALWAYS)
            try:
                _cm.set_persistent_storage(STUDY_WEB_COOKIE_DB,
                                           WebKit2.CookiePersistentStorage.SQLITE)
            except Exception as _e:
                print(f"cookie storage unavailable: {_e}", flush=True)
            try:
                data_manager.set_itp_enabled(False)  # keep Google/WhatsApp logins
            except Exception:
                pass
            try:
                _study_web_context.set_cache_model(WebKit2.CacheModel.WEB_BROWSER)
            except Exception:
                pass
        except Exception as e:
            print(f"persistent study browser profile unavailable: {e}", flush=True)
            try:
                _study_web_context = WebKit2.WebContext.get_default()
            except Exception:
                _study_web_context = None
    if _study_ucm is None:
        try:
            _study_ucm = WebKit2.UserContentManager()
            _study_ucm.add_script(WebKit2.UserScript.new(
                INPUT_FILTER_JS,
                WebKit2.UserContentInjectedFrames.ALL_FRAMES,
                WebKit2.UserScriptInjectionTime.START,
                None, None))
            _study_ucm.add_script(WebKit2.UserScript.new(
                TELEGRAM_KIOSK_JS,
                WebKit2.UserContentInjectedFrames.ALL_FRAMES,
                WebKit2.UserScriptInjectionTime.START,
                None, None))
            try:
                _study_ucm.register_script_message_handler("focusTelegramPeer")
                _study_ucm.connect(
                    "script-message-received::focusTelegramPeer",
                    _telegram_peer_message)
            except Exception as _bridge_error:
                print(f"Telegram peer pin bridge unavailable: {_bridge_error}",
                      flush=True)
            try:
                _study_ucm.register_script_message_handler("focusInputBlocked")
                _study_ucm.connect(
                    "script-message-received::focusInputBlocked",
                    _focus_input_blocked_message)
            except Exception as _bridge_error:
                print(f"Input blocked bridge unavailable: {_bridge_error}",
                      flush=True)
        except Exception as _e:
            print(f"input filter script unavailable: {_e}", flush=True)
            _study_ucm = None
    try:
        if _study_web_context is not None and _study_ucm is not None:
            web = WebKit2.WebView(web_context=_study_web_context,
                                  user_content_manager=_study_ucm)
        elif _study_web_context is not None:
            web = WebKit2.WebView.new_with_context(_study_web_context)
        else:
            web = WebKit2.WebView()
    except Exception:
        web = WebKit2.WebView()
    try:
        _configure_study_settings(web.get_settings())
    except Exception:
        pass

    def _on_web_authenticate(_view, request):
        try:
            if (request.get_host() or "").lower().split(":", 1)[0] not in (
                    "127.0.0.1", "localhost"):
                return False
            dialog = Gtk.Dialog(title="Phone Upload Sign-in", transient_for=win,
                                flags=Gtk.DialogFlags.MODAL)
            dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
            dialog.add_button("Sign in", Gtk.ResponseType.OK)
            dialog.set_default_response(Gtk.ResponseType.OK)
            box = dialog.get_content_area()
            box.set_spacing(10)
            box.set_margin_top(16); box.set_margin_bottom(16)
            box.set_margin_start(18); box.set_margin_end(18)
            user_entry = Gtk.Entry()
            user_entry.set_text("study")
            pass_entry = Gtk.Entry()
            pass_entry.set_visibility(False)
            pass_entry.set_placeholder_text("Upload password")
            box.pack_start(Gtk.Label(label="Username"), False, False, 0)
            box.pack_start(user_entry, False, False, 0)
            box.pack_start(Gtk.Label(label="Password"), False, False, 0)
            box.pack_start(pass_entry, False, False, 0)
            box.show_all()
            result = dialog.run()
            username, passphrase = user_entry.get_text(), pass_entry.get_text()
            dialog.destroy()
            if result != Gtk.ResponseType.OK:
                request.cancel()
                return True
            credential = WebKit2.Credential.new(
                username, passphrase, WebKit2.CredentialPersistence.FOR_SESSION)
            request.authenticate(credential)
            return True
        except Exception as e:
            print(f"upload portal sign-in error: {e}", flush=True)
            try:
                request.cancel()
            except Exception:
                pass
            return True

    web.connect("authenticate", _on_web_authenticate)
    web.set_hexpand(True)
    web.set_vexpand(True)
    web_scroll = Gtk.ScrolledWindow()
    web_scroll.add(web)
    web_wrap = Gtk.Overlay()
    web_wrap.add(web_scroll)
    web_nav = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
    web_nav.get_style_context().add_class("floatbar")
    web_nav.set_halign(Gtk.Align.END)
    web_nav.set_valign(Gtk.Align.START)
    web_nav.set_margin_top(10)
    web_nav.set_margin_end(12)
    web_back = Gtk.Button(label="‹")
    web_forward = Gtk.Button(label="›")
    for nav_btn in (web_back, web_forward):
        nav_btn.get_style_context().add_class("floatbtn")
        nav_btn.get_style_context().add_class("webnavbtn")
        nav_btn.set_size_request(30, 30)
        web_nav.pack_start(nav_btn, False, False, 0)
    web_back.set_tooltip_text("Back")
    web_forward.set_tooltip_text("Forward")
    web_wrap.add_overlay(web_nav)

    # Web pages live in their own internal stack so the sidebar dock can keep
    # several sites open at once and switch instantly without reloading.
    web_stack = Gtk.Stack()
    web_stack.set_hexpand(True)
    web_stack.set_vexpand(True)
    web_stack.set_transition_type(Gtk.StackTransitionType.NONE)
    web_stack.add_named(web_wrap, "web-main")
    web_host = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    web_host.set_hexpand(True)
    web_host.set_vexpand(True)
    web_host.pack_start(web_stack, True, True, 0)
    web_tabs = []
    doc_state = {"active": False, "title": "", "icon": "📄"}

    group_ui_state = {"active": False}

    def _set_group_ui(active):
        active = bool(active)
        if group_ui_state["active"] == active:
            return
        group_ui_state["active"] = active
        if active:
            side.hide()
            bar.hide()
            telegram_header.set_no_show_all(False)
            telegram_header.show_all()
        else:
            telegram_header.hide()
            telegram_header.set_no_show_all(True)
            side.show_all()
            bar.show_all()

    def _leave_group_view(*_):
        _set_group_ui(False)
        stack.set_visible_child_name("home")

    def _return_to_group(*_):
        _set_group_ui(False)
        _launch_study_edge(TELEGRAM_GROUP_URL, title="PDF Materials")

    tg_back.connect("clicked", _leave_group_view)
    tg_reload.connect("clicked", _return_to_group)

    def _update_web_nav(*_):
        current_host = (urlparse(web.get_uri() or "").hostname or "").lower()
        telegram_view = current_host == TELEGRAM_WEB_HOST
        _set_group_ui(telegram_view)
        web_back.set_sensitive(not telegram_view and web.can_go_back())
        web_forward.set_sensitive(not telegram_view and web.can_go_forward())

    web_back.connect("clicked", lambda *_: web.go_back())
    web_forward.connect("clicked", lambda *_: web.go_forward())
    web.connect("load-changed", _update_web_nav)
    web.connect("notify::estimated-load-progress", _update_web_nav)

    split_return_page = {"name": "home"}
    split_paned = Gtk.Paned.new(Gtk.Orientation.HORIZONTAL)
    split_paned.set_wide_handle(True)
    split_paned.set_hexpand(True)
    split_paned.set_vexpand(True)
    split_active_pane = {"current": "left"}

    paned_split_done = [False]
    def _on_paned_size(widget, alloc):
        if not paned_split_done[0] and alloc.width > 200:
            paned_split_done[0] = True
            widget.set_position(alloc.width // 2)
    split_paned.connect("size-allocate", _on_paned_size)

    def _split_load_uri(view, raw_uri):
        uri = (raw_uri or "").strip()
        if not uri:
            return
        if uri.startswith("file:"):
            parsed = urlparse(uri)
            fpath = urllib.parse.unquote(parsed.path)
            if not (os.path.isfile(fpath) and fpath.lower().endswith(".pdf")):
                _toast("Only a PDF file from this device can open here")
                return
            view.load_uri(uri)
            return
        if "://" not in uri:
            uri = "https://" + uri
        parsed = urlparse(uri)
        host = (parsed.hostname or "").lower()
        if host == TELEGRAM_WEB_HOST or host.endswith((".telegram.org", ".t.me")):
            _toast("Telegram is only available in the single-group view")
            return
        # Websites open in Edge app mode; WebKit here is only for local PDFs.
        _launch_study_edge(uri)

    def _build_split_pane(caption):
        pane = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        pane.set_can_focus(True)
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        caption_label = Gtk.Label(label=caption)
        caption_label.get_style_context().add_class("sidehead")
        chooser = Gtk.ComboBoxText()
        chooser.append("", "Select link…")
        for link in cfg.get("links", []):
            if isinstance(link, dict) and link.get("url"):
                chooser.append(str(link["url"]), str(link.get("title") or "Study link"))
        chooser.set_hexpand(True)
        pdf_button = Gtk.Button(label="Select PDF")
        fullscreen_btn = Gtk.Button(label="⛶")
        back_button = Gtk.Button(label="‹")
        forward_button = Gtk.Button(label="›")
        for button in (pdf_button, fullscreen_btn, back_button, forward_button):
            button.get_style_context().add_class("webnavbtn")
            button.get_style_context().add_class("floatbtn")
        pdf_button.set_tooltip_text("Choose a PDF from this device to view here")
        fullscreen_btn.set_tooltip_text("Open this PDF in fullscreen reader")
        back_button.set_tooltip_text("Back in this pane")
        forward_button.set_tooltip_text("Forward in this pane")
        toolbar.pack_start(caption_label, False, False, 2)
        toolbar.pack_start(chooser, True, True, 0)
        toolbar.pack_start(pdf_button, False, False, 0)
        toolbar.pack_start(fullscreen_btn, False, False, 0)
        toolbar.pack_start(back_button, False, False, 0)
        toolbar.pack_start(forward_button, False, False, 0)
        pane.pack_start(toolbar, False, False, 0)

        try:
            view = WebKit2.WebView.new_with_context(_study_web_context)
        except Exception:
            view = WebKit2.WebView()
        view.set_hexpand(True)
        view.set_vexpand(True)
        try:
            st = view.get_settings()
            _configure_study_settings(st)
            if hasattr(st, "set_allow_file_access_from_file_urls"):
                st.set_allow_file_access_from_file_urls(True)
            if hasattr(st, "set_allow_universal_access_from_file_urls"):
                st.set_allow_universal_access_from_file_urls(True)
        except Exception:
            pass
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scroll.add(view)
        pane.pack_start(scroll, True, True, 0)

        current_pdf_path = {"path": None}
        local_pdf_uri = {"uri": None}

        def _mark_active(*_):
            split_active_pane["current"] = "right" if caption.upper() == "RIGHT" else "left"

        view.connect("focus-in-event", _mark_active)
        pane.connect("button-press-event", _mark_active)

        def _choose(_chooser):
            selected = chooser.get_active_id()
            if selected:
                current_pdf_path["path"] = None
                local_pdf_uri["uri"] = None
                caption_label.set_text(caption)
                caption_label.set_tooltip_text(None)
                _split_load_uri(view, selected)

        def _load_pdf_into_pane(selected_path):
            if not selected_path or not os.path.isfile(selected_path):
                return
            abs_p = os.path.abspath(selected_path)
            current_pdf_path["path"] = abs_p
            local_pdf_uri["uri"] = Gio.File.new_for_path(abs_p).get_uri()
            chooser.set_active_id("")
            caption_label.set_text(os.path.basename(abs_p)[:18])
            caption_label.set_tooltip_text(abs_p)
            _split_load_uri(view, local_pdf_uri["uri"])
            _record_recent_document(abs_p, 1)

        def _select_pdf(*_):
            _mark_active()
            dialog = Gtk.FileChooserDialog(
                title="Select PDF for " + caption.lower() + " pane",
                parent=win, action=Gtk.FileChooserAction.OPEN)
            dialog.set_transient_for(win)
            dialog.set_modal(True)
            dialog.set_keep_above(True)
            dialog.set_position(Gtk.WindowPosition.CENTER_ON_PARENT)
            dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
            dialog.add_button("Open PDF", Gtk.ResponseType.ACCEPT)
            pdf_filter = Gtk.FileFilter()
            pdf_filter.set_name("PDF files")
            pdf_filter.add_mime_type("application/pdf")
            pdf_filter.add_pattern("*.pdf")
            pdf_filter.add_pattern("*.PDF")
            dialog.add_filter(pdf_filter)
            if os.path.isdir(STUDY_INBOX):
                try:
                    dialog.set_current_folder(STUDY_INBOX)
                except Exception:
                    pass
            response = dialog.run()
            selected_path = dialog.get_filename() if response == Gtk.ResponseType.ACCEPT else None
            dialog.destroy()
            if selected_path and selected_path.lower().endswith(".pdf"):
                _load_pdf_into_pane(selected_path)

        def _go_fullscreen(*_):
            if current_pdf_path.get("path") and os.path.isfile(current_pdf_path["path"]):
                _open_media(current_pdf_path["path"], force_fullscreen=True)
            else:
                _toast("Choose a PDF first to view in fullscreen")

        def _policy(_view, decision, decision_type):
            try:
                if decision_type == WebKit2.PolicyDecisionType.NAVIGATION_ACTION:
                    action = decision.get_navigation_action()
                    uri = action.get_request().get_uri() or ""
                    parsed = urlparse(uri)
                    if parsed.scheme in ("about", "blob", "data", "file"):
                        return False
                    if parsed.scheme in ("http", "https"):
                        decision.ignore()
                        GLib.idle_add(_launch_study_edge, uri)
                        return True
                    decision.ignore()
                    _toast(f"Blocked: {parsed.hostname or uri} — not in study list")
                    return True
                if decision_type == WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION:
                    action = decision.get_navigation_action()
                    uri = action.get_request().get_uri() or ""
                    parsed = urlparse(uri)
                    decision.ignore()
                    if (_page_allowed(uri, allow) or parsed.scheme in ("about", "blob", "data")):
                        GLib.idle_add(_split_load_uri, view, uri)
                    else:
                        _toast("Popup blocked: site is not in the study list")
                    return True
                if decision_type == WebKit2.PolicyDecisionType.RESPONSE:
                    response = decision.get_response()
                    mime = (response.get_mime_type() or "").lower().split(";", 1)[0]
                    uri = response.get_uri() or ""
                    parsed = urlparse(uri)
                    path = parsed.path.lower()
                    if parsed.scheme == "file":
                        return False
                    is_att = bool(response.get_suggested_filename())
                    unsupported = not decision.is_mime_type_supported()
                    is_file_ext = path.endswith((".zip", ".rar", ".7z", ".tar", ".gz",
                                                ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
                                                ".mp3", ".m4a", ".wav", ".mp4", ".mkv", ".webm",
                                                ".epub", ".txt", ".csv"))
                    if is_att or unsupported or is_file_ext:
                        if (_page_allowed(uri, allow) or _page_allowed(view.get_uri() or "", allow)
                                or parsed.scheme in ("blob", "data")):
                            decision.download()
                            return True
            except Exception as e:
                print(f"split view policy error: {e}", flush=True)
            return False

        def _loaded(_view, event):
            if event == WebKit2.LoadEvent.FINISHED:
                _record_recent_website(view.get_uri(), view.get_title())

        pdf_button.connect("clicked", _select_pdf)
        fullscreen_btn.connect("clicked", _go_fullscreen)
        chooser.connect("changed", _choose)
        back_button.connect("clicked", lambda *_: view.go_back()
                            if view.can_go_back() else None)
        forward_button.connect("clicked", lambda *_: view.go_forward()
                                if view.can_go_forward() else None)
        view.connect("authenticate", _on_web_authenticate)
        view.connect("permission-request", lambda _v, req: (req.allow(), True)[1])
        view.connect("decide-policy", _policy)
        view.connect("load-changed", _loaded)
        view.connect("context-menu", lambda *_: True)
        return (pane, view, _load_pdf_into_pane, current_pdf_path)

    split_left, split_left_view, split_left_load_pdf, split_left_info = _build_split_pane("LEFT")
    split_right, split_right_view, split_right_load_pdf, split_right_info = _build_split_pane("RIGHT")
    split_paned.pack1(split_left, True, False)
    split_paned.pack2(split_right, True, False)
    split_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
    split_title = Gtk.Label(label="TWO STUDY PAGES — SIDE BY SIDE")
    split_title.get_style_context().add_class("sidehead")
    split_title.set_halign(Gtk.Align.START)
    split_panel.pack_start(split_title, False, False, 4)
    split_panel.pack_start(split_paned, True, True, 0)

    def _toggle_split(*_):
        if stack.get_visible_child_name() == "split":
            stack.set_visible_child_name(split_return_page["name"])
        else:
            prev = stack.get_visible_child_name() or "home"
            split_return_page["name"] = prev
            stack.set_visible_child_name("split")
            if prev == "reader" and state.get("path") and os.path.isfile(state["path"]):
                split_left_load_pdf(state["path"])

    def _sync_split_button(_stack, _property):
        active = stack.get_visible_child_name() == "split"
        split_btn.set_label("Single view" if active else "Split view")
        split_btn.set_tooltip_text(
            "Return to the previous page" if active else "Show two study pages side by side")

    split_btn.connect("clicked", _toggle_split)
    stack.connect("notify::visible-child-name", _sync_split_button)

    toast_state = {"id": 0}

    def _hide_toast():
        toast_state["id"] = 0
        try:
            toast_lbl.hide()
        except Exception:
            pass
        return False

    def _toast(msg):
        try:
            toast_lbl.set_text(msg)
            toast_lbl.show()
            if toast_state["id"]:
                GLib.source_remove(toast_state["id"])
            toast_state["id"] = GLib.timeout_add(2600, _hide_toast)
        except Exception:
            print(msg, flush=True)

    def _load_state_file(path, fallback):
        try:
            with open(path) as f:
                value = json.load(f)
            return value if isinstance(value, type(fallback)) else fallback
        except Exception:
            return fallback

    raw_reading_pages = _load_state_file(STUDY_READING_STATE, {})
    reading_pages = {}
    for path, page in raw_reading_pages.items():
        try:
            reading_pages[str(path)] = max(1, int(page))
        except (TypeError, ValueError):
            continue
    raw_recent_items = _load_state_file(STUDY_RECENTS_STATE, [])
    recent_items = [item for item in raw_recent_items
                    if isinstance(item, dict)
                    and ((item.get("kind") == "doc" and item.get("path"))
                         or (item.get("kind") == "web" and item.get("url")))][:40]
    recent_rows = None
    recent_panel = None
    recent_hide_state = {"id": 0}

    def _write_state_file(path, data):
        try:
            os.makedirs(LEDGER_DIR, exist_ok=True)
            tmp = path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, path)
        except Exception as e:
            print(f"study state save error: {e}", flush=True)

    raw_recent_downloads = _load_state_file(STUDY_DOWNLOADS_STATE, [])
    recent_downloads = [item for item in raw_recent_downloads if isinstance(item, dict)][:30]
    active_downloads = {}

    def _format_size(num_bytes):
        if not num_bytes or num_bytes <= 0:
            return "0 B"
        size = float(num_bytes)
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}" if unit != 'B' else f"{int(size)} B"
            size /= 1024.0
        return f"{size:.1f} TB"

    dl_popover = Gtk.Popover.new(dl_btn)
    dl_popover.set_position(Gtk.PositionType.BOTTOM)
    dl_popover_scroll = Gtk.ScrolledWindow()
    dl_popover_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    dl_popover_scroll.set_max_content_height(380)
    dl_popover_scroll.set_propagate_natural_height(True)
    dl_popover_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
    dl_popover_box.set_size_request(320, -1)
    dl_popover_box.get_style_context().add_class("dl-popover")
    dl_popover_scroll.add(dl_popover_box)
    dl_popover.add(dl_popover_scroll)

    def _render_dl_popover():
        for ch in dl_popover_box.get_children():
            dl_popover_box.remove(ch)

        head_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        title = Gtk.Label(label="DOWNLOADS")
        title.get_style_context().add_class("dl-head")
        title.set_halign(Gtk.Align.START)
        head_box.pack_start(title, True, True, 0)

        open_folder_btn = Gtk.Button(label="📁 Folder")
        open_folder_btn.get_style_context().add_class("dl-btn-action")
        open_folder_btn.set_tooltip_text(f"Open: {DOWNLOAD_DIR}")
        def _open_folder(*_):
            try:
                os.makedirs(DOWNLOAD_DIR, exist_ok=True)
                subprocess.Popen(["xdg-open", DOWNLOAD_DIR])
            except Exception as e:
                _toast(f"Could not open folder: {e}")
        open_folder_btn.connect("clicked", _open_folder)
        head_box.pack_end(open_folder_btn, False, False, 0)
        dl_popover_box.pack_start(head_box, False, False, 2)

        if active_downloads:
            active_head = Gtk.Label(label="RUNNING")
            active_head.get_style_context().add_class("sidehead")
            active_head.set_halign(Gtk.Align.START)
            dl_popover_box.pack_start(active_head, False, False, 0)

            for dl, info in list(active_downloads.items()):
                row = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
                row.get_style_context().add_class("dl-row")

                top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
                name_lbl = Gtk.Label(label=info["name"])
                name_lbl.get_style_context().add_class("dl-filename")
                name_lbl.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
                name_lbl.set_halign(Gtk.Align.START)
                top.pack_start(name_lbl, True, True, 0)

                cancel_btn = Gtk.Button(label="✕")
                cancel_btn.get_style_context().add_class("dl-btn-action")
                cancel_btn.set_tooltip_text("Cancel download")
                cancel_btn.connect("clicked", lambda *_, d=dl: d.cancel())
                top.pack_end(cancel_btn, False, False, 0)
                row.pack_start(top, False, False, 0)

                pbar = Gtk.ProgressBar()
                pbar.get_style_context().add_class("dl-progressbar")
                pbar.set_fraction(max(0.0, min(1.0, info["progress"])))
                row.pack_start(pbar, False, False, 0)

                sub_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
                pct_str = f"{int(info['progress'] * 100)}%"
                size_str = f"{_format_size(info['received'])}"
                if info["total"] > 0:
                    size_str += f" / {_format_size(info['total'])}"
                meta_lbl = Gtk.Label(label=f"{pct_str} · {size_str}")
                meta_lbl.get_style_context().add_class("dl-meta")
                meta_lbl.set_halign(Gtk.Align.START)
                sub_box.pack_start(meta_lbl, True, True, 0)
                row.pack_start(sub_box, False, False, 0)

                dl_popover_box.pack_start(row, False, False, 0)

        if recent_downloads:
            dl_popover_box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 4)
            rec_head = Gtk.Label(label="RECENT")
            rec_head.get_style_context().add_class("sidehead")
            rec_head.set_halign(Gtk.Align.START)
            dl_popover_box.pack_start(rec_head, False, False, 0)

            for item in recent_downloads[:10]:
                rrow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
                rrow.get_style_context().add_class("dl-row")

                icon_lbl = Gtk.Label(label="📄" if item["status"] == "completed" else "⚠️")
                rrow.pack_start(icon_lbl, False, False, 0)

                details = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
                fn_lbl = Gtk.Label(label=item["name"])
                fn_lbl.get_style_context().add_class("dl-filename")
                fn_lbl.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
                fn_lbl.set_halign(Gtk.Align.START)
                details.pack_start(fn_lbl, False, False, 0)

                sub_text = _format_size(item.get("size", 0)) if item["status"] == "completed" else "Failed"
                sub_lbl = Gtk.Label(label=sub_text)
                sub_lbl.get_style_context().add_class("dl-meta")
                sub_lbl.set_halign(Gtk.Align.START)
                details.pack_start(sub_lbl, False, False, 0)
                rrow.pack_start(details, True, True, 0)

                if item["status"] == "completed" and os.path.isfile(item.get("path", "")):
                    open_btn = Gtk.Button(label="Open")
                    open_btn.get_style_context().add_class("dl-btn-action")
                    fpath = item["path"]
                    def _open_file(*_, p=fpath):
                        if p.lower().endswith((".pdf", ".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp")):
                            _open_media(p)
                        else:
                            try:
                                subprocess.Popen(["xdg-open", p])
                            except Exception as e:
                                _toast(f"Open failed: {e}")
                    open_btn.connect("clicked", _open_file)
                    rrow.pack_end(open_btn, False, False, 0)

                dl_popover_box.pack_start(rrow, False, False, 0)

        if not active_downloads and not recent_downloads:
            empty_lbl = Gtk.Label(label="No downloads yet")
            empty_lbl.get_style_context().add_class("dl-meta")
            empty_lbl.set_padding(12, 12)
            dl_popover_box.pack_start(empty_lbl, False, False, 8)

        dl_popover_box.show_all()

    def _update_download_ui():
        try:
            if not active_downloads:
                dl_btn.set_label("📥 Downloads")
                dl_btn.set_tooltip_text("View active and recent downloads")
            elif len(active_downloads) == 1:
                info = list(active_downloads.values())[0]
                pct = int(info["progress"] * 100)
                dl_btn.set_label(f"📥 {pct}%")
                dl_btn.set_tooltip_text(f"Downloading: {info['name']} ({pct}%)")
            else:
                avg_pct = int(sum(info["progress"] for info in active_downloads.values()) / len(active_downloads) * 100)
                dl_btn.set_label(f"📥 {len(active_downloads)} ({avg_pct}%)")
                dl_btn.set_tooltip_text(f"{len(active_downloads)} active downloads ({avg_pct}%)")
            if dl_popover.get_visible():
                _render_dl_popover()
        except Exception:
            pass

    def _toggle_dl_popover(*_):
        if dl_popover.get_visible():
            dl_popover.popdown()
        else:
            _render_dl_popover()
            dl_popover.show_all()
            dl_popover.popup()

    dl_btn.connect("clicked", _toggle_dl_popover)

    def _record_recent(kind, key, title, page=None):
        if not key:
            return
        now = time.time()
        identity = ("doc", os.path.realpath(key)) if kind == "doc" else ("web", key)
        recent_items[:] = [
            item for item in recent_items
            if not ((item.get("kind"),
                     os.path.realpath(item.get("path", "")) if item.get("kind") == "doc"
                     else item.get("url", "")) == identity)
        ]
        item = {"kind": kind, "title": title or key, "time": now}
        if kind == "doc":
            item.update(path=os.path.realpath(key), page=max(1, int(page or 1)))
        else:
            item["url"] = key
        recent_items.insert(0, item)
        del recent_items[40:]
        _write_state_file(STUDY_RECENTS_STATE, recent_items)
        if recent_rows is not None:
            _render_recent()

    def _record_recent_website(uri, title):
        try:
            parsed = urlparse(uri or "")
            if parsed.scheme not in ("http", "https") or not _page_allowed(uri, allow):
                return
            label = title or parsed.hostname
            _record_recent("web", uri, label)
        except Exception:
            pass

    def _record_recent_document(path, page=1):
        _record_recent("doc", path, os.path.basename(path), page)

    def _load_read_history():
        raw = _load_state_file(STUDY_READ_HISTORY_STATE, [])
        items = []
        if isinstance(raw, list):
            for entry in raw:
                if isinstance(entry, dict) and "book" in entry:
                    items.append({
                        "id": str(entry.get("id") or secrets.token_hex(4)),
                        "date": str(entry.get("date") or time.strftime("%Y-%m-%d %H:%M")),
                        "book": str(entry.get("book") or "").strip(),
                        "page": str(entry.get("page") or "1").strip(),
                        "path": str(entry.get("path") or "")
                    })
        return items

    def _save_read_history(items):
        try:
            _write_state_file(STUDY_READ_HISTORY_STATE, items)
        except Exception as e:
            print(f"save read history error: {e}", flush=True)

    def _record_read_history_entry(book_name, page_no, path=None):
        try:
            items = _load_read_history()
            now_str = time.strftime("%Y-%m-%d %H:%M")
            real_path = os.path.realpath(path) if path else ""
            found = False
            for it in items:
                if it["book"].strip().lower() == book_name.strip().lower():
                    it["page"] = str(page_no)
                    it["date"] = now_str
                    if real_path:
                        it["path"] = real_path
                    found = True
                    break
            if not found:
                items.insert(0, {
                    "id": secrets.token_hex(4),
                    "date": now_str,
                    "book": book_name,
                    "page": str(page_no),
                    "path": real_path
                })
            _save_read_history(items)
        except Exception as e:
            print(f"record read history error: {e}", flush=True)

    def _save_reading_page(path, page):
        if not path or not path.lower().endswith(".pdf"):
            return
        key = os.path.realpath(path)
        reading_pages[key] = max(1, int(page))
        _write_state_file(STUDY_READING_STATE, reading_pages)
        _record_recent_document(key, page)
        book_title = os.path.splitext(os.path.basename(path))[0]
        _record_read_history_entry(book_title, page, key)

    def _battery_text():
        for supply in glob.glob("/sys/class/power_supply/*"):
            name = os.path.basename(supply)
            try:
                with open(os.path.join(supply, "type")) as f:
                    kind = f.read().strip().lower()
                if kind != "battery" and not name.upper().startswith("BAT"):
                    continue
                with open(os.path.join(supply, "capacity")) as f:
                    percent = max(0, min(100, int(f.read().strip())))
                status = ""
                try:
                    with open(os.path.join(supply, "status")) as f:
                        status = f.read().strip().lower()
                except Exception:
                    pass
                icon = "⚡" if "charg" in status else "🔋"
                return f"{icon} {percent}%"
            except (OSError, ValueError):
                continue
        return "🔋 N/A"

    def _refresh_battery():
        try:
            battery_lbl.set_text(_battery_text())
        except Exception:
            pass
        return True

    _refresh_battery()
    battery_timer = GLib.timeout_add_seconds(30, _refresh_battery)

    def _telegram_group_file_uri(uri):
        try:
            page = urlparse(web.get_uri() or "")
            file = urlparse(uri or "")
            host = (file.hostname or "").lower()
            return (page.hostname == "web.telegram.org"
                    and (page.path or "").rstrip("/").lower() in TELEGRAM_WEB_PATHS
                    and _page_allowed(web.get_uri() or "", allow)
                    and (host == "web.telegram.org" or host == "telegram.org"
                         or host.endswith(".telegram.org"))
                    and ("/file/" in (file.path or "").lower()
                         or (file.path or "").lower().endswith(".pdf")))
        except Exception:
            return False

    def _on_decide_policy(_view, decision, dtype):
        try:
            if dtype == WebKit2.PolicyDecisionType.RESPONSE:
                response = decision.get_response()
                uri = response.get_uri() or ""
                mime = (response.get_mime_type() or "").lower().split(";", 1)[0].strip()
                path = urlparse(uri).path.lower()
                is_attachment = bool(response.get_suggested_filename())
                unsupported_mime = not decision.is_mime_type_supported()
                is_file_ext = path.endswith((".pdf", ".zip", ".rar", ".7z", ".tar", ".gz",
                                             ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
                                             ".mp3", ".m4a", ".wav", ".mp4", ".mkv", ".webm",
                                             ".epub", ".txt", ".csv"))
                is_tg = _telegram_group_file_uri(uri)
                current_allowed = _page_allowed(web.get_uri() or "", allow)
                uri_allowed = _page_allowed(uri, allow)
                if (is_attachment or unsupported_mime or is_file_ext or mime == "application/pdf" or is_tg):
                    if uri_allowed or current_allowed or uri.startswith(("blob:", "data:")) or is_tg:
                        decision.download()
                        return True
            if dtype == WebKit2.PolicyDecisionType.NAVIGATION_ACTION:
                uri = decision.get_navigation_action().get_request().get_uri()
                if uri and uri.startswith("file://"):
                    local_path = os.path.realpath(
                        urllib.parse.unquote(urlparse(uri).path))
                    media_ext = os.path.splitext(local_path)[1].lower()
                    trusted_dirs = [os.path.realpath(p) for p in
                                    (DOWNLOAD_DIR, STUDY_INBOX)]
                    if (media_ext in MEDIA_EXTS and os.path.isfile(local_path)
                            and any(local_path.startswith(d + os.sep)
                                    for d in trusted_dirs)):
                        decision.ignore()
                        GLib.idle_add(_open_media, local_path)
                        return True
                    return False
                if uri and uri.startswith(("blob:", "data:", "about:")):
                    return False  # in-page PDF/blob from an already-allowed page
                host = (urlparse(uri).hostname or "").lower() if uri else ""
                if uri and _telegram_group_file_uri(uri):
                    decision.ignore()
                    try:
                        web.download_uri(uri)
                    except Exception as e:
                        print(f"Telegram document download error: {e}", flush=True)
                        _toast("Telegram download failed; try the document again")
                    return True
                if uri and _page_allowed(uri, allow):
                    clean_path = uri.lower().split("?")[0]
                    if clean_path.endswith((".pdf", ".zip", ".rar", ".7z", ".tar", ".gz",
                                            ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
                                            ".mp3", ".m4a", ".wav", ".mp4", ".mkv", ".webm",
                                            ".epub", ".txt", ".csv")):
                        decision.ignore()
                        try:
                            web.download_uri(uri)
                        except Exception as e:
                            print(f"file download error: {e}", flush=True)
                        return True
                    return False
                decision.ignore()
                _toast(f"Blocked: {host or uri} \u2014 not in study list")
                return True
            if dtype == WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION:
                uri = decision.get_navigation_action().get_request().get_uri()
                host = (urlparse(uri).hostname or "").lower() if uri else ""
                decision.ignore()
                if uri:
                    clean_path = uri.lower().split("?")[0]
                    if clean_path.endswith((".pdf", ".zip", ".rar", ".7z", ".tar", ".gz",
                                            ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
                                            ".mp3", ".m4a", ".wav", ".mp4", ".mkv", ".webm",
                                            ".epub", ".txt", ".csv")):
                        try:
                            web.download_uri(uri)
                        except Exception:
                            pass
                        return True
                if uri and (_page_allowed(uri, allow) or uri.startswith(("blob:", "data:", "about:"))):
                    GLib.idle_add(_open_popup, uri)
                else:
                    print(f"popup blocked: {uri}", flush=True)
                    _toast("Popup blocked: site is not in the study list")
                return True
        except Exception as e:
            print(f"policy error: {e}", flush=True)
        return False

    def _on_create(web_view, navigation_action):
        try:
            req = navigation_action.get_request() if navigation_action else None
            uri = req.get_uri() if req else None
            if uri and uri != "about:blank":
                clean_path = uri.lower().split("?")[0]
                if clean_path.endswith((".pdf", ".zip", ".rar", ".7z", ".tar", ".gz",
                                        ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
                                        ".mp3", ".m4a", ".wav", ".mp4", ".mkv", ".webm",
                                        ".epub", ".txt", ".csv")):
                    web_view.download_uri(uri)
                    return None
                if _page_allowed(uri, allow) or uri.startswith(("blob:", "data:")):
                    GLib.idle_add(_open_popup, uri)
                    return None

            temp_view = WebKit2.WebView.new_with_context(web_view.get_context())
            try:
                _configure_study_settings(temp_view.get_settings())
            except Exception:
                pass

            def _temp_policy(_v, decision, dtype):
                try:
                    if dtype == WebKit2.PolicyDecisionType.RESPONSE:
                        resp = decision.get_response()
                        resp_uri = resp.get_uri() or ""
                        mime = (resp.get_mime_type() or "").lower().split(";", 1)[0].strip()
                        rpath = urlparse(resp_uri).path.lower()
                        is_att = bool(resp.get_suggested_filename())
                        unsupported = not decision.is_mime_type_supported()
                        is_file_dl = (mime == "application/pdf" or rpath.endswith(
                            (".pdf", ".zip", ".rar", ".7z", ".tar", ".gz",
                             ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
                             ".mp3", ".m4a", ".wav", ".mp4", ".mkv", ".webm",
                             ".epub", ".txt", ".csv")))
                        if is_att or unsupported or is_file_dl:
                            decision.download()
                            GLib.idle_add(temp_view.destroy)
                            return True
                    if dtype == WebKit2.PolicyDecisionType.NAVIGATION_ACTION:
                        nuri = decision.get_navigation_action().get_request().get_uri() or ""
                        npath = urlparse(nuri).path.lower()
                        if npath.endswith((".pdf", ".zip", ".rar", ".7z", ".tar", ".gz",
                                           ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
                                           ".mp3", ".m4a", ".wav", ".mp4", ".mkv", ".webm",
                                           ".epub", ".txt", ".csv")):
                            decision.ignore()
                            web_view.download_uri(nuri)
                            GLib.idle_add(temp_view.destroy)
                            return True
                        if _page_allowed(nuri, allow):
                            decision.ignore()
                            web_view.load_uri(nuri)
                            GLib.idle_add(temp_view.destroy)
                            return True
                except Exception as e:
                    print(f"temp view policy error: {e}", flush=True)
                return False

            temp_view.connect("decide-policy", _temp_policy)
            temp_view.connect("close", lambda *_: temp_view.destroy())
            GLib.timeout_add_seconds(60, lambda: (temp_view.destroy(), False)[1])
            return temp_view
        except Exception as e:
            print(f"create popup error: {e}", flush=True)
        return None

    def _on_context_menu(*_a):
        return True

    def _on_download(download):
        req = download.get_request()
        init_uri = req.get_uri() if req else ""
        init_name = os.path.basename(urlparse(init_uri).path) if init_uri else ""
        if not init_name:
            init_name = "download"
        init_name = os.path.basename(urllib.parse.unquote(init_name.replace("\\", "/")))

        active_downloads[download] = {
            "name": init_name,
            "path": "",
            "progress": 0.0,
            "received": 0,
            "total": 0,
            "status": "downloading",
        }
        _update_download_ui()

        def _on_progress_changed(dl, _pspec):
            if dl in active_downloads:
                active_downloads[dl]["progress"] = dl.get_estimated_progress()
                active_downloads[dl]["received"] = dl.get_received_data_length()
                resp = dl.get_response()
                if resp:
                    active_downloads[dl]["total"] = resp.get_content_length()
                _update_download_ui()

        download.connect("notify::estimated-progress", _on_progress_changed)

        def _on_decide_destination(dl, suggested_filename):
            try:
                response = dl.get_response()
                name = suggested_filename or ""
                if not name and response:
                    try:
                        name = response.get_suggested_filename() or ""
                    except Exception:
                        pass
                if not name:
                    req_dl = dl.get_request()
                    if req_dl and req_dl.get_uri():
                        name = os.path.basename(urlparse(req_dl.get_uri()).path)
                if not name:
                    name = "download"
                name = os.path.basename(urllib.parse.unquote(name.replace("\\", "/")))
                ext = os.path.splitext(name)[1].lower()
                mime = (response.get_mime_type() or "").lower().split(";", 1)[0].strip() \
                    if response else ""
                inferred_ext = {
                    "application/pdf": ".pdf",
                    "image/jpeg": ".jpg",
                    "image/jpg": ".jpg",
                    "image/png": ".png",
                    "image/webp": ".webp",
                    "image/gif": ".gif",
                    "image/bmp": ".bmp",
                    "image/svg+xml": ".svg",
                    "image/heic": ".heic",
                    "image/heif": ".heif",
                    "application/zip": ".zip",
                    "application/x-zip-compressed": ".zip",
                    "application/msword": ".doc",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
                    "application/vnd.ms-excel": ".xls",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
                    "application/vnd.ms-powerpoint": ".ppt",
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
                    "audio/mpeg": ".mp3",
                    "video/mp4": ".mp4",
                    "text/plain": ".txt",
                }.get(mime, "")
                if not ext and inferred_ext:
                    name = name + inferred_ext
                    ext = inferred_ext

                try:
                    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
                    if not os.access(DOWNLOAD_DIR, os.W_OK):
                        raise OSError("Downloads folder is not writable")
                    download_dir = DOWNLOAD_DIR
                except OSError:
                    os.makedirs(STUDY_INBOX, exist_ok=True)
                    download_dir = STUDY_INBOX
                    _toast("Downloads folder unavailable; saving to Study Inbox")

                dst = os.path.join(download_dir, name)
                if os.path.exists(dst):
                    stem, e = os.path.splitext(name)
                    i = 1
                    while os.path.exists(os.path.join(download_dir, f"{stem} ({i}){e}")):
                        i += 1
                    dst = os.path.join(download_dir, f"{stem} ({i}){e}")
                    name = os.path.basename(dst)

                if dl in active_downloads:
                    active_downloads[dl]["name"] = name
                    active_downloads[dl]["path"] = dst

                dest_uri = GLib.filename_to_uri(os.path.abspath(dst), None)
                dl.set_destination(dest_uri)
                try:
                    dl.set_allow_overwrite(True)
                except Exception:
                    pass

                def _done(_dl):
                    info = active_downloads.pop(_dl, None)
                    final_path = dst
                    dest = _dl.get_destination()
                    if dest and dest.startswith("file://"):
                        try:
                            final_path, _ = GLib.filename_from_uri(dest)
                        except Exception:
                            pass
                    f_name = os.path.basename(final_path)
                    f_size = os.path.getsize(final_path) if os.path.isfile(final_path) else 0
                    if not os.path.isfile(final_path) or f_size <= 0:
                        _toast("Download did not finish; try downloading again")
                        recent_downloads.insert(0, {
                            "name": f_name or (info["name"] if info else "Download"),
                            "path": final_path,
                            "size": 0,
                            "status": "failed",
                            "time": time.time(),
                        })
                    else:
                        location = "Downloads" if download_dir == DOWNLOAD_DIR else "Study Inbox"
                        _toast(f"Downloaded to {location}: {f_name}")
                        recent_downloads.insert(0, {
                            "name": f_name,
                            "path": final_path,
                            "size": f_size,
                            "status": "completed",
                            "time": time.time(),
                        })
                        if f_name.lower().endswith((".pdf", ".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp")):
                            _open_media(final_path)
                    del recent_downloads[30:]
                    _write_state_file(STUDY_DOWNLOADS_STATE, recent_downloads)
                    _update_download_ui()

                def _failed(_dl, error):
                    info = active_downloads.pop(_dl, None)
                    f_name = info["name"] if info else "Download"
                    recent_downloads.insert(0, {
                        "name": f_name,
                        "path": info.get("path", "") if info else "",
                        "size": 0,
                        "status": "failed",
                        "time": time.time(),
                    })
                    del recent_downloads[30:]
                    _write_state_file(STUDY_DOWNLOADS_STATE, recent_downloads)
                    print(f"download failed: {error}", flush=True)
                    _toast(f"Download failed: {error}")
                    _update_download_ui()

                dl.connect("finished", _done)
                dl.connect("failed", _failed)
                _update_download_ui()
                return True
            except Exception as e:
                print(f"decide destination error: {e}", flush=True)
                active_downloads.pop(dl, None)
                _update_download_ui()
                return False

        try:
            download.connect("decide-destination", _on_decide_destination)
        except Exception as e:
            print(f"download connect error: {e}", flush=True)

    web.connect("decide-policy", _on_decide_policy)
    web.connect("create", _on_create)
    web.connect("context-menu", _on_context_menu)
    web.connect("permission-request", lambda _v, req: (req.allow(), True)[1])
    download_context = None
    download_handler_id = 0
    try:
        download_context = web.get_context()
        download_handler_id = download_context.connect(
            "download-started", lambda _c, d: _on_download(d))
    except Exception:
        pass

    # ---- home (bismillah) ----
    home = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
    home.set_valign(Gtk.Align.CENTER)
    home.set_halign(Gtk.Align.CENTER)
    home.get_style_context().add_class("homepage")
    bism = Gtk.Label()
    bism.set_markup('<span font_family="Amiri" size="52000" foreground="#e8eefc">'
                    '\u0628\u0650\u0633\u0652\u0645\u0650 \u0627\u0644\u0644\u064e\u0651\u0647\u0650 '
                    '\u0627\u0644\u0631\u064e\u0651\u062d\u0652\u0645\u064e\u0670\u0646\u0650 '
                    '\u0627\u0644\u0631\u064e\u0651\u062d\u0650\u064a\u0645\u0650</span>')
    bism.set_halign(Gtk.Align.CENTER)
    home.pack_start(bism, False, False, 0)
    flavor = Gtk.Label()
    flavor.set_markup('<span font_family="Amiri" size="20000" foreground="#9cb3d9">'
                      '\u0628\u0650\u0633\u0652\u0645\u0650 \u0627\u0644\u0644\u064e\u0651\u0647\u0650 '
                      '\u0627\u0644\u0631\u064e\u0651\u062d\u0652\u0645\u064e\u0670\u0646\u0650 '
                      '\u0627\u0644\u0631\u064e\u0651\u062d\u0650\u064a\u0645\u0650</span>')
    flavor.set_opacity(0.55)
    flavor.set_halign(Gtk.Align.CENTER)
    home.pack_start(flavor, False, False, 0)
    stack.add_named(home, "home")

    # ---- PDF / image reader with annotation layer ----
    reader = Gtk.Overlay()
    canvas = Gtk.DrawingArea()
    canvas.set_hexpand(True)
    canvas.set_vexpand(True)
    canvas.set_can_focus(True)
    img_scroll = Gtk.ScrolledWindow()
    img_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
    img_scroll.set_vexpand(True)
    img_scroll.add(canvas)
    img_scroll.set_overlay_scrolling(False)
    reader.add(img_scroll)

    floatbar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
    floatbar.get_style_context().add_class("floatbar")
    floatbar.set_halign(Gtk.Align.END)
    floatbar.set_valign(Gtk.Align.CENTER)
    floatbar.set_margin_end(14)
    floatbar.set_margin_top(14)
    floatbar.set_margin_bottom(14)

    prev_btn = Gtk.Button(label="\u25b2")
    next_btn = Gtk.Button(label="\u25bc")
    zoom_in = Gtk.Button(label="+")
    zoom_out = Gtk.Button(label="\u2212")
    fit_btn = Gtk.Button(label="Fit")
    fit_btn.set_tooltip_text("Fit PDF page width to the viewer")
    actual_size_btn = Gtk.Button(label="100%")
    undo_btn = Gtk.Button(label="\u21b6")
    redo_btn = Gtk.Button(label="\u21b7")
    save_btn = Gtk.Button(label="\U0001F4BE")
    pen_btn = Gtk.Button(label="\u270e")
    high_btn = Gtk.Button(label="\u25ad")
    erase_btn = Gtk.Button(label="\u232b")
    page_lbl = Gtk.Label(label="1/1")
    page_lbl.get_style_context().add_class("floatpage")
    for b in (prev_btn, next_btn, zoom_in, zoom_out, fit_btn, actual_size_btn,
              undo_btn, redo_btn, save_btn,
              pen_btn, high_btn, erase_btn):
        b.get_style_context().add_class("floatbtn")
        b.set_size_request(38, 38)
        floatbar.pack_start(b, False, False, 0)
    fit_btn.set_size_request(48, 34)
    actual_size_btn.set_size_request(52, 34)
    floatbar.pack_start(page_lbl, False, False, 0)
    floatbar.set_no_show_all(False)
    reader.add_overlay(floatbar)
    toolbar_edge = Gtk.EventBox()
    toolbar_edge.set_visible_window(False)
    toolbar_edge.set_size_request(10, -1)
    toolbar_edge.set_halign(Gtk.Align.END)
    toolbar_edge.set_valign(Gtk.Align.FILL)
    toolbar_edge.add_events(Gdk.EventMask.ENTER_NOTIFY_MASK
                            | Gdk.EventMask.LEAVE_NOTIFY_MASK
                            | Gdk.EventMask.POINTER_MOTION_MASK)
    reader.add_overlay(toolbar_edge)
    toolbar_hover = {"inside": False, "hide_id": 0}

    def _cancel_toolbar_hide():
        if toolbar_hover["hide_id"]:
            try:
                GLib.source_remove(toolbar_hover["hide_id"])
            except Exception:
                pass
            toolbar_hover["hide_id"] = 0

    def _schedule_toolbar_hide(delay=1200):
        _cancel_toolbar_hide()
        def _hide():
            toolbar_hover["hide_id"] = 0
            if not toolbar_hover["inside"]:
                floatbar.set_opacity(0.0)
                floatbar.set_sensitive(False)
            return False
        toolbar_hover["hide_id"] = GLib.timeout_add(delay, _hide)

    def _reveal_toolbar(*_args):
        if not pdf_layout["active"]:
            return False
        floatbar.set_sensitive(True)
        floatbar.set_opacity(1.0)
        if not toolbar_hover["inside"]:
            _schedule_toolbar_hide()
        return False

    def _toolbar_enter(*_args):
        toolbar_hover["inside"] = True
        _cancel_toolbar_hide()
        _reveal_toolbar()
        return False

    def _toolbar_leave(*_args):
        toolbar_hover["inside"] = False
        _schedule_toolbar_hide()
        return False

    toolbar_edge.connect("enter-notify-event", _toolbar_enter)
    toolbar_edge.connect("motion-notify-event", _toolbar_enter)
    toolbar_edge.connect("leave-notify-event", _toolbar_leave)
    floatbar.connect("enter-notify-event", _toolbar_enter)
    floatbar.connect("leave-notify-event", _toolbar_leave)
    for _tool in floatbar.get_children():
        _tool.connect("enter-notify-event", _toolbar_enter)
        _tool.connect("leave-notify-event", _toolbar_leave)
    stack.add_named(web_host, "web")
    stack.add_named(reader, "reader")
    stack.add_named(split_panel, "split")

    # ---------- Native Video Player Page ----------
    player_state = {"active": False, "title": "", "vid": "", "minimized": False}
    player_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
    player_panel.get_style_context().add_class("player-page")

    player_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
    player_header.get_style_context().add_class("player-header")

    player_icon_lbl = Gtk.Label(label="▶ NATIVE VIDEO PLAYER")
    player_icon_lbl.get_style_context().add_class("player-title")
    player_header.pack_start(player_icon_lbl, False, False, 0)

    player_sub_lbl = Gtk.Label(label="")
    player_sub_lbl.get_style_context().add_class("player-sub")
    player_sub_lbl.set_ellipsize(Pango.EllipsizeMode.END)
    player_sub_lbl.set_max_width_chars(45)
    player_header.pack_start(player_sub_lbl, False, False, 4)

    player_theater_btn = Gtk.Button(label="⛶ Theater")
    player_theater_btn.get_style_context().add_class("topbar-btn")
    player_theater_btn.set_size_request(80, 24)
    player_theater_btn.set_tooltip_text("Toggle sidebar for wide theater mode")
    player_theater_btn.connect("clicked", lambda *_: _toggle_sidebar())
    player_header.pack_end(player_theater_btn, False, False, 0)

    player_close_btn = Gtk.Button(label="✕ Close")
    player_close_btn.get_style_context().add_class("topbar-btn")
    player_close_btn.set_size_request(68, 24)
    player_close_btn.set_tooltip_text("Close video player and return")
    player_header.pack_end(player_close_btn, False, False, 0)

    player_panel.pack_start(player_header, False, False, 0)

    try:
        player_web = WebKit2.WebView()
    except Exception:
        player_web = WebKit2.WebView.new()
    player_web.set_hexpand(True)
    player_web.set_vexpand(True)
    try:
        pst = player_web.get_settings()
        if hasattr(pst, "set_enable_media"):
            pst.set_enable_media(True)
        if hasattr(pst, "set_media_playback_requires_user_gesture"):
            pst.set_media_playback_requires_user_gesture(False)
        if hasattr(pst, "set_enable_developer_extras"):
            pst.set_enable_developer_extras(False)
        if hasattr(pst, "set_enable_write_console_messages_to_stdout"):
            pst.set_enable_write_console_messages_to_stdout(False)
    except Exception:
        pass

    def _on_player_decide_policy(_v, decision, decision_type):
        try:
            if decision_type == WebKit2.PolicyDecisionType.NAVIGATION_ACTION:
                action = decision.get_navigation_action()
                uri = (action.get_request().get_uri() or "").lower()
                if (uri.startswith(("about:", "data:", "blob:", "file:"))
                        or "youtube-nocookie.com" in uri
                        or "googlevideo.com" in uri):
                    return False
                decision.ignore()
                return True
            if decision_type == WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION:
                decision.ignore()
                return True
        except Exception:
            pass
        return False

    player_web.connect("decide-policy", _on_player_decide_policy)
    player_web.connect("permission-request", lambda _v, req: (req.allow(), True)[1])
    player_web.connect("context-menu", lambda *_: True)
    player_panel.pack_start(player_web, True, True, 0)

    stack.add_named(player_panel, "player")

    # ---------- Read History Page (Excel / Spreadsheet style) ----------
    history_return_page = {"name": "home"}
    history_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
    history_panel.get_style_context().add_class("history-page")

    history_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
    history_header.get_style_context().add_class("history-header")

    hist_title = Gtk.Label(label="📖 READING HISTORY")
    hist_title.get_style_context().add_class("history-title")
    history_header.pack_start(hist_title, False, False, 0)

    history_count_lbl = Gtk.Label(label="0 records")
    history_count_lbl.get_style_context().add_class("history-badge")
    history_header.pack_start(history_count_lbl, False, False, 0)

    hist_spacer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
    hist_spacer.set_hexpand(True)
    history_header.pack_start(hist_spacer, True, True, 0)

    history_search_entry = Gtk.Entry()
    history_search_entry.set_width_chars(24)
    history_search_entry.set_placeholder_text("🔍 Search history…")
    history_search_entry.set_tooltip_text("Search across Book Name, Page, Date or SL No")
    history_search_entry.get_style_context().add_class("history-search")
    history_header.pack_start(history_search_entry, False, False, 0)

    add_row_btn = Gtk.Button(label="+ Add Entry")
    add_row_btn.get_style_context().add_class("topbar-btn")
    add_row_btn.set_tooltip_text("Add a new book or reading record")
    history_header.pack_start(add_row_btn, False, False, 0)

    delete_row_btn = Gtk.Button(label="🗑 Delete")
    delete_row_btn.get_style_context().add_class("topbar-btn")
    delete_row_btn.set_tooltip_text("Delete selected reading log entry")
    history_header.pack_start(delete_row_btn, False, False, 0)

    close_history_btn = Gtk.Button(label="← Back to Study")
    close_history_btn.get_style_context().add_class("topbar-btn")
    close_history_btn.set_tooltip_text("Return to previous study view")
    history_header.pack_start(close_history_btn, False, False, 0)

    history_panel.pack_start(history_header, False, False, 0)

    history_store = Gtk.ListStore(str, str, str, str, str, str)

    def _history_search_filter(model, it, _data):
        q = (history_search_entry.get_text() or "").strip().lower()
        if not q:
            return True
        sl = (model.get_value(it, 0) or "").lower()
        dt = (model.get_value(it, 1) or "").lower()
        bk = (model.get_value(it, 2) or "").lower()
        pg = (model.get_value(it, 3) or "").lower()
        return q in bk or q in pg or q in dt or q in sl

    history_filter = history_store.filter_new()
    history_filter.set_visible_func(_history_search_filter)

    history_search_entry.connect("changed", lambda *_: history_filter.refilter())

    history_tree = Gtk.TreeView(model=history_filter)
    history_tree.set_rules_hint(True)
    history_tree.set_grid_lines(Gtk.TreeViewGridLines.BOTH)
    history_tree.get_style_context().add_class("excel-table")

    def _save_history_from_store():
        items = []
        for idx, row in enumerate(history_store, start=1):
            row[0] = str(idx)
            items.append({
                "id": row[4],
                "date": row[1],
                "book": row[2],
                "page": row[3],
                "path": row[5]
            })
        _save_read_history(items)
        history_count_lbl.set_text(f"{len(items)} records")

    def _reload_history_store():
        history_store.clear()
        items = _load_read_history()
        for idx, it in enumerate(items, start=1):
            history_store.append([
                str(idx),
                str(it.get("date") or time.strftime("%Y-%m-%d %H:%M")),
                str(it.get("book") or ""),
                str(it.get("page") or "1"),
                str(it.get("id") or secrets.token_hex(4)),
                str(it.get("path") or "")
            ])
        history_count_lbl.set_text(f"{len(items)} records")
        history_filter.refilter()

    sl_col = Gtk.TreeViewColumn("SL (ক্রমিক)")
    sl_col.set_fixed_width(75)
    sl_col.set_alignment(0.5)
    sl_cell = Gtk.CellRendererText()
    sl_cell.set_alignment(0.5, 0.5)
    sl_col.pack_start(sl_cell, False)
    sl_col.add_attribute(sl_cell, "text", 0)
    history_tree.append_column(sl_col)

    date_col = Gtk.TreeViewColumn("Date (তারিখ)")
    date_col.set_fixed_width(170)
    date_col.set_alignment(0.5)
    date_cell = Gtk.CellRendererText()
    date_cell.set_alignment(0.5, 0.5)
    date_col.pack_start(date_cell, False)
    date_col.add_attribute(date_cell, "text", 1)
    history_tree.append_column(date_col)

    book_col = Gtk.TreeViewColumn("Book Name (বইয়ের নাম) ✎")
    book_col.set_expand(True)
    book_col.set_min_width(220)
    book_cell = Gtk.CellRendererText()
    book_cell.set_property("editable", True)
    book_col.pack_start(book_cell, True)
    book_col.add_attribute(book_cell, "text", 2)

    def _on_book_cell_edited(_cell, path_str, new_text):
        new_text = str(new_text or "").strip()
        if not new_text:
            return
        try:
            f_iter = history_filter.get_iter(path_str)
            c_iter = history_filter.convert_iter_to_child_iter(f_iter)
            if history_store[c_iter][2] != new_text:
                history_store[c_iter][2] = new_text
                history_store[c_iter][1] = time.strftime("%Y-%m-%d %H:%M")
                _save_history_from_store()
                _toast(f"Updated '{new_text}' (Date auto-synced)")
        except Exception as e:
            print(f"book cell edit error: {e}", flush=True)

    book_cell.connect("edited", _on_book_cell_edited)
    history_tree.append_column(book_col)

    def _find_history_book_path(book, stored_path, deep=False):
        """Resolve a history book name to a real file on disk."""
        if stored_path and os.path.isfile(stored_path):
            return stored_path
        name = str(book or "").strip().lower()
        if not name:
            return ""
        for item in list(recent_items):
            if item.get("kind") != "doc":
                continue
            p = item.get("path") or ""
            if not p or not os.path.isfile(p):
                continue
            stem = os.path.splitext(os.path.basename(p))[0].strip().lower()
            title = str(item.get("title") or "").strip().lower()
            if name in (stem, title):
                return p
        roots = [STUDY_INBOX, DOWNLOAD_DIR]
        for root in roots:
            try:
                for entry in os.scandir(root):
                    if not entry.is_file():
                        continue
                    if os.path.splitext(entry.name)[1].lower() not in MEDIA_EXTS:
                        continue
                    if os.path.splitext(entry.name)[0].strip().lower() == name:
                        return entry.path
            except Exception:
                pass
        if deep:
            try:
                scan_roots = roots + [os.path.expanduser(r) for r in
                                      (cfg.get("scan_roots") or [])]
                for _mtime, p in _scan_media(scan_roots):
                    if (os.path.splitext(os.path.basename(p))[0]
                            .strip().lower() == name):
                        return p
            except Exception:
                pass
        return ""

    def _open_history_row(path_str):
        try:
            f_iter = history_filter.get_iter(path_str)
            c_iter = history_filter.convert_iter_to_child_iter(f_iter)
            book = history_store[c_iter][2]
            stored = history_store[c_iter][5]
            target = _find_history_book_path(book, stored)
            if target:
                if target != stored:
                    history_store[c_iter][5] = target
                    _save_history_from_store()
                _open_media(target)
                return

            _toast(f"Looking for '{book}'…")
            def _finish(found):
                if found:
                    _open_media(found)
                else:
                    _toast(f"File not found for '{book}'. Use 📂 Open to select it.")
                return False

            def _worker():
                found = _find_history_book_path(book, "", deep=True)
                GLib.idle_add(_finish, found)

            threading.Thread(target=_worker, daemon=True).start()
        except Exception as e:
            print(f"history open error: {e}", flush=True)
            _toast("Could not open this book")

    open_col = Gtk.TreeViewColumn("")
    open_col.set_fixed_width(104)
    open_col.set_alignment(0.5)
    open_cell = Gtk.CellRendererText()
    open_cell.set_property("markup", "<b>📂 Open</b>")
    open_cell.set_property("foreground", "#ffffff")
    open_cell.set_property("cell-background", "#2563eb")
    open_cell.set_property("xpad", 8)
    open_cell.set_property("ypad", 4)
    open_col.pack_start(open_cell, False)
    history_tree.append_column(open_col)

    def _on_history_click(_tree, event):
        if event.button != 1 or event.type != Gdk.EventType.BUTTON_PRESS:
            return False
        try:
            pos = history_tree.get_path_at_pos(int(event.x), int(event.y))
        except Exception:
            pos = None
        if not pos:
            return False
        path, column, _cx, _cy = pos
        if column is open_col:
            _open_history_row(path)
            return True
        return False

    history_tree.connect("button-press-event", _on_history_click)

    page_col = Gtk.TreeViewColumn("Page (পৃষ্ঠা) ✎")
    page_col.set_fixed_width(120)
    page_col.set_alignment(0.5)
    page_cell = Gtk.CellRendererText()
    page_cell.set_alignment(0.5, 0.5)
    page_cell.set_property("editable", True)
    page_col.pack_start(page_cell, False)
    page_col.add_attribute(page_cell, "text", 3)

    def _on_page_cell_edited(_cell, path_str, new_text):
        new_text = str(new_text or "").strip()
        if not new_text:
            return
        try:
            f_iter = history_filter.get_iter(path_str)
            c_iter = history_filter.convert_iter_to_child_iter(f_iter)
            if history_store[c_iter][3] != new_text:
                history_store[c_iter][3] = new_text
                history_store[c_iter][1] = time.strftime("%Y-%m-%d %H:%M")
                _save_history_from_store()
                _toast(f"Page set to {new_text} (Date auto-synced)")
        except Exception as e:
            print(f"page cell edit error: {e}", flush=True)

    page_cell.connect("edited", _on_page_cell_edited)
    history_tree.append_column(page_col)

    def _add_history_row(*_):
        now_str = time.strftime("%Y-%m-%d %H:%M")
        new_id = secrets.token_hex(4)
        history_store.insert(0, ["1", now_str, "New Book Title", "1", new_id, ""])
        _save_history_from_store()
        try:
            history_tree.set_cursor(Gtk.TreePath.new_first(), book_col, True)
        except Exception:
            pass
        _toast("New book entry added — click to edit")

    add_row_btn.connect("clicked", _add_history_row)

    def _delete_history_row(*_):
        selection = history_tree.get_selection()
        model, f_iter = selection.get_selected()
        if f_iter:
            c_iter = history_filter.convert_iter_to_child_iter(f_iter)
            bk_name = history_store[c_iter][2]
            history_store.remove(c_iter)
            _save_history_from_store()
            _toast(f"Deleted '{bk_name or 'entry'}'")

    delete_row_btn.connect("clicked", _delete_history_row)

    close_history_btn.connect("clicked", lambda *_: stack.set_visible_child_name(
        history_return_page.get("name") or "home"))

    history_scroll = Gtk.ScrolledWindow()
    history_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
    history_scroll.set_hexpand(True)
    history_scroll.set_vexpand(True)
    history_scroll.get_style_context().add_class("excel-scroll")
    history_scroll.add(history_tree)
    history_panel.pack_start(history_scroll, True, True, 0)

    history_footer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
    history_footer_lbl = Gtk.Label(
        label="ℹ️ Click 📂 Open beside a book to read it instantly. Click Book Name or Page to edit inline. Date auto-syncs on edit.")
    history_footer_lbl.get_style_context().add_class("history-footer")
    history_footer.pack_start(history_footer_lbl, False, False, 4)
    history_panel.pack_start(history_footer, False, False, 4)

    _reload_history_store()
    stack.add_named(history_panel, "history")

    def _open_read_history(*_):
        cur = stack.get_visible_child_name()
        if cur != "history":
            history_return_page["name"] = cur or "home"
        _reload_history_store()
        stack.set_visible_child_name("history")

    history_btn.connect("clicked", _open_read_history)

    import cairo as _pcairo  # pycairo: pixbuf filter + annotation PDF surface

    state = {
        "path": None, "page": 1, "pages": 1, "zoom": 1.0,
        "pb": None, "tool": "pen",
        "strokes": [], "redo": [], "drawing": None,
        "page_pts": (595.0, 842.0), "backup_done": False,
    }
    TOOL_STYLE = {"pen": ((0.85, 0.10, 0.10), 3.0, 1.0),
                  "high": ((1.0, 0.85, 0.10), 16.0, 0.35)}
    PDF_GAP = 22
    pdf_layout = {"active": False, "page_w": 0, "page_h": 0,
                  "canvas_w": 0, "canvas_h": 0, "fit_width": True,
                  "restoring": False, "restore_page": 1}
    pdf_needed_pages = set()
    pdf_pending = set()

    def _canvas_size():
        return canvas.get_allocated_width(), canvas.get_allocated_height()

    def _chaikin(pts, iters=2):
        """Round a raw pointer trail into a natural ink stroke."""
        for _ in range(iters):
            if len(pts) < 3:
                break
            out = [pts[0]]
            for i in range(len(pts) - 1):
                px, py = pts[i]
                qx, qy = pts[i + 1]
                out.append((0.75 * px + 0.25 * qx, 0.75 * py + 0.25 * qy))
                out.append((0.25 * px + 0.75 * qx, 0.25 * py + 0.75 * qy))
            out.append(pts[-1])
            pts = out
        return pts

    def _trace(cr, pts, sx, sy):
        if not pts:
            return
        if len(pts) == 1:
            return
        cr.move_to(pts[0][0] * sx, pts[0][1] * sy)
        for x, y in pts[1:]:
            cr.line_to(x * sx, y * sy)

    def _draw_stroke(cr, s, w, h):
        pts = _chaikin(s["pts"])
        if len(pts) < 1:
            return
        (r, g, b), wdt, alpha = TOOL_STYLE.get(s["tool"], TOOL_STYLE["pen"])
        cr.set_source_rgba(r, g, b, alpha)
        cr.set_line_width(wdt)
        cr.set_line_cap(1)   # round
        cr.set_line_join(1)
        if len(pts) == 1:
            cr.arc(pts[0][0] * w, pts[0][1] * h, wdt / 2.0, 0, 6.283)
            cr.fill()
        else:
            _trace(cr, pts, w, h)
            cr.stroke()

    def _on_draw(_w, cr):
        w, h = _canvas_size()
        if pdf_layout["active"]:
            return _draw_pdf_continuous(cr, w, h)
        pb = state["pb"]
        if pb is not None and w > 1 and h > 1:
            x = max(0, (w - pb.get_width()) // 2)
            y = max(0, (h - pb.get_height()) // 2)
            Gdk.cairo_set_source_pixbuf(cr, pb, x, y)
            cr.get_source().set_filter(_pcairo.Filter.BILINEAR)
            cr.paint()
        for s in state["strokes"]:
            _draw_stroke(cr, s, w, h)
        cur = state["drawing"]
        if cur is not None:
            _draw_stroke(cr, cur, w, h)
        return False

    canvas.connect("draw", _on_draw)

    def _set_pb(pb, natural=False):
        state["pb"] = pb
        if pb is not None:
            canvas.set_size_request(pb.get_width(), pb.get_height())
            canvas.queue_draw()

    pdf_meta_cache = {}
    page_cache = {}
    page_cache_order = []
    page_request = {"id": 0}
    pdf_meta_lock = threading.Lock()
    media_worker_lock = threading.Lock()

    def _fit_zoom():
        page_w = max(1.0, float(state["page_pts"][0]))
        view_w = img_scroll.get_allocated_width()
        if view_w <= 1:
            view_w = max(360, win.get_allocated_width() - 310)
        return max(0.10, min(3.0, (view_w - PDF_GAP * 2) * 72.0 / (96.0 * page_w)))

    def _update_pdf_layout():
        if not pdf_layout["active"]:
            return
        page_pts_w, page_pts_h = state["page_pts"]
        page_w = max(1, int(page_pts_w * 96.0 / 72.0 * state["zoom"]))
        page_h = max(1, int(page_pts_h * 96.0 / 72.0 * state["zoom"]))
        viewport_w = img_scroll.get_allocated_width()
        if viewport_w <= 1:
            viewport_w = max(360, win.get_allocated_width() - 290)
        canvas_w = max(viewport_w, page_w + PDF_GAP * 2)
        canvas_h = max(1, (page_h + PDF_GAP) * state["pages"] + PDF_GAP)
        pdf_layout.update(page_w=page_w, page_h=page_h,
                          canvas_w=canvas_w, canvas_h=canvas_h)
        canvas.set_size_request(canvas_w, canvas_h)
        canvas.queue_draw()

    def _draw_pdf_continuous(cr, width, height):
        page_w = pdf_layout["page_w"]
        page_h = pdf_layout["page_h"]
        stride = page_h + PDF_GAP
        clip = cr.clip_extents()
        first = max(0, int(max(0, clip[1] - PDF_GAP) // stride))
        last = min(state["pages"] - 1,
                   int(max(0, clip[3] - PDF_GAP) // stride))
        cr.save()
        cr.set_source_rgb(0.12, 0.15, 0.19)
        cr.paint()
        path = state["path"]
        for index in range(first, last + 1):
            page = index + 1
            x = max(PDF_GAP, (width - page_w) // 2)
            y = PDF_GAP + index * stride
            cr.set_source_rgb(0.07, 0.09, 0.12)
            cr.rectangle(x - 3, y - 3, page_w + 6, page_h + 6)
            cr.fill()
            cr.set_source_rgb(1.0, 1.0, 1.0)
            cr.rectangle(x, y, page_w, page_h)
            cr.fill()
            key = (path, page, round(state["zoom"], 2))
            pb = page_cache.get(key)
            if pb is not None:
                cr.save()
                cr.translate(x, y)
                cr.scale(page_w / float(pb.get_width()),
                         page_h / float(pb.get_height()))
                Gdk.cairo_set_source_pixbuf(cr, pb, 0, 0)
                cr.get_source().set_filter(_pcairo.Filter.BILINEAR)
                cr.paint()
                cr.restore()
            else:
                cr.set_source_rgb(0.32, 0.37, 0.44)
                cr.select_font_face("Sans", _pcairo.FONT_SLANT_NORMAL,
                                    _pcairo.FONT_WEIGHT_NORMAL)
                cr.set_font_size(15)
                cr.move_to(x + 18, y + 32)
                cr.show_text(f"Loading page {page}")
            strokes, _redo_mem = _page_strokes(path, page)
            cr.save()
            cr.translate(x, y)
            for stroke in strokes:
                _draw_stroke(cr, stroke, page_w, page_h)
            drawing = state["drawing"]
            if drawing is not None and drawing.get("page") == page:
                _draw_stroke(cr, drawing, page_w, page_h)
            cr.restore()
        cr.restore()
        return False

    def _apply_pdf_page(request_id, path, page, zoom, pb, error):
        key = (path, page, round(zoom, 2))
        pdf_pending.discard(key)
        if request_id != page_request["id"] or state["path"] != path:
            return False
        if not win.get_visible() or page not in pdf_needed_pages:
            return False
        if error or pb is None:
            if error != "cancelled" and page == state["page"]:
                _toast(f"Could not render PDF page {page}: {error or 'render failed'}")
            return False
        page_cache[key] = pb
        if key in page_cache_order:
            page_cache_order.remove(key)
        page_cache_order.append(key)
        keep = set((path, n, round(zoom, 2)) for n in pdf_needed_pages)
        while len(page_cache_order) > max(8, len(keep)):
            old_key = page_cache_order.pop(0)
            if old_key not in keep:
                page_cache.pop(old_key, None)
            else:
                page_cache_order.append(old_key)
                if all(k in keep for k in page_cache_order):
                    break
        canvas.queue_draw()
        return False

    def _request_pdf_page(page):
        path = state["path"]
        zoom = float(state["zoom"])
        key = (path, page, round(zoom, 2))
        if not path or key in page_cache or key in pdf_pending:
            return
        pdf_pending.add(key)
        request_id = page_request["id"]

        def _work():
            with media_worker_lock:
                if request_id != page_request["id"] or page not in pdf_needed_pages:
                    GLib.idle_add(_apply_pdf_page, request_id, path, page, zoom,
                                  None, "cancelled")
                    return
                try:
                    pb = _render_pdf_page(
                        path, page, zoom,
                        cancel=lambda: (request_id != page_request["id"]
                                        or page not in pdf_needed_pages))
                    error = None if pb is not None else (
                        "cancelled" if page not in pdf_needed_pages else "render failed")
                except Exception as e:
                    pb, error = None, str(e)
            GLib.idle_add(_apply_pdf_page, request_id, path, page, zoom, pb, error)

        threading.Thread(target=_work, daemon=True).start()

    def _ensure_pdf_pages(*_):
        if not pdf_layout["active"]:
            return False
        adjustment = img_scroll.get_vadjustment()
        top = adjustment.get_value()
        view_h = max(1, img_scroll.get_allocated_height())
        stride = pdf_layout["page_h"] + PDF_GAP
        first = max(1, int(max(0, top - PDF_GAP) // stride) + 1)
        last = min(state["pages"], int(max(0, top + view_h - PDF_GAP) // stride) + 1)
        needed = set(range(max(1, first - 1), min(state["pages"], last + 1) + 1))
        pdf_needed_pages.clear()
        pdf_needed_pages.update(needed)
        for page in sorted(needed):
            _request_pdf_page(page)
        canvas.queue_draw()
        return False

    def _select_pdf_page(page, save=True):
        page = max(1, min(state["pages"], int(page)))
        if page != state["page"]:
            _remember()
            state["page"] = page
            state["strokes"], state["redo"] = _page_strokes(state["path"], page)
            if save:
                _save_reading_page(state["path"], page)
        page_lbl.set_text(f"{state['page']}/{state['pages']}")
        prev_btn.set_sensitive(state["page"] > 1)
        next_btn.set_sensitive(state["page"] < state["pages"])

    def _on_pdf_scroll(*_):
        if not pdf_layout["active"] or pdf_layout["restoring"]:
            return False
        adjustment = img_scroll.get_vadjustment()
        stride = pdf_layout["page_h"] + PDF_GAP
        page = int(max(0, adjustment.get_value() - PDF_GAP) // stride) + 1
        _select_pdf_page(page)
        _ensure_pdf_pages()
        return False

    def _restore_pdf_scroll():
        if not pdf_layout["active"]:
            return False
        stride = pdf_layout["page_h"] + PDF_GAP
        adjustment = img_scroll.get_vadjustment()
        page = max(1, min(state["pages"], int(pdf_layout["restore_page"])))
        target = max(0, PDF_GAP + (page - 1) * stride)
        maximum = max(0, adjustment.get_upper() - adjustment.get_page_size())
        if target > maximum + 2:
            attempts = getattr(_restore_pdf_scroll, "attempts", 0)
            if attempts < 60:
                _restore_pdf_scroll.attempts = attempts + 1
                GLib.timeout_add(80, _restore_pdf_scroll)
                return False
        _restore_pdf_scroll.attempts = 0
        state["page"] = page
        pdf_layout["restoring"] = False
        adjustment.set_value(min(target, maximum))
        _on_pdf_scroll()
        return False

    def _show_page():
        if pdf_layout["active"]:
            _ensure_pdf_pages()
        canvas.queue_draw()

    def _init_pdf_document(request_id, path, resume_page, meta, error):
        if request_id != page_request["id"] or state["path"] != path:
            return False
        if error:
            page_lbl.set_text("PDF unavailable")
            _toast(f"Could not read PDF: {error}")
            return False
        pdf_meta_cache[path] = meta
        state["pages"], state["page_pts"] = meta
        state["page"] = max(1, min(state["pages"], resume_page))
        pdf_layout["restore_page"] = state["page"]
        pdf_layout["restoring"] = True
        state["zoom"] = _fit_zoom()
        pdf_layout["active"] = True
        pdf_layout["fit_width"] = True
        _update_pdf_layout()
        state["strokes"], state["redo"] = _page_strokes(path, state["page"])
        _save_reading_page(path, state["page"])
        _select_pdf_page(state["page"], save=False)
        _reveal_toolbar()
        GLib.idle_add(_restore_pdf_scroll)
        return False

    def _load_pdf_document(request_id, path, resume_page):
        def _work():
            try:
                with media_worker_lock:
                    with pdf_meta_lock:
                        meta = pdf_meta_cache.get(path)
                        if meta is None:
                            meta = _pdf_metadata(path)
                            pdf_meta_cache[path] = meta
                error = None
            except Exception as e:
                meta, error = None, str(e)
            GLib.idle_add(_init_pdf_document, request_id, path, resume_page, meta, error)
        threading.Thread(target=_work, daemon=True).start()

    def _goto_pdf_page(page):
        if not pdf_layout["active"]:
            return
        page = max(1, min(state["pages"], int(page)))
        stride = pdf_layout["page_h"] + PDF_GAP
        img_scroll.get_vadjustment().set_value(max(0, PDF_GAP + (page - 1) * stride))
        _select_pdf_page(page)
        _ensure_pdf_pages()

    img_scroll.get_vadjustment().connect("value-changed", _on_pdf_scroll)

    def _on_reader_resize(_widget, _allocation):
        if pdf_layout["active"] and pdf_layout["fit_width"]:
            new_zoom = _fit_zoom()
            if abs(new_zoom - state["zoom"]) > 0.05:
                pdf_layout["restore_page"] = state["page"]
                pdf_layout["restoring"] = True
                page_request["id"] += 1
                pdf_pending.clear()
                pdf_needed_pages.clear()
                page_cache.clear()
                page_cache_order.clear()
                state["zoom"] = new_zoom
                _update_pdf_layout()
                GLib.idle_add(_restore_pdf_scroll)
                return
        _ensure_pdf_pages()

    img_scroll.connect("size-allocate", _on_reader_resize)

    STROKE_MEM = {}

    def _page_strokes(path, page):
        return STROKE_MEM.get((path, page), ([], []))

    def _remember():
        STROKE_MEM[(state["path"], state["page"])] = (state["strokes"], state["redo"])

    def _open_media(path, force_fullscreen=False):
        ext = os.path.splitext(path)[1].lower()
        if ext in (".mp4", ".mkv", ".webm", ".avi", ".mov"):
            _play_local_video_native(path)
            return
        if ext in (".flv", ".mp3", ".m4a", ".wav", ".ogg", ".flac", ".aac",
                   ".zip", ".rar", ".7z", ".tar", ".gz",
                   ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".odt", ".ods"):
            try:
                subprocess.Popen(["xdg-open", path])
                _toast(f"Opening {os.path.basename(path)}…")
            except Exception as e:
                _toast(f"Could not open: {e}")
            return
        if stack.get_visible_child_name() == "split" and not force_fullscreen and ext == ".pdf":
            target = split_right_load_pdf if split_active_pane.get("current") == "right" else split_left_load_pdf
            target(path)
            doc_state.update(active=True, title=os.path.basename(path), icon="📄")
            try:
                _render_dock()
            except Exception:
                pass
            _toast(f"Opened {os.path.basename(path)} in split view")
            return
        doc_state.update(active=True, title=os.path.basename(path),
                         icon="📄" if ext == ".pdf" else "🖼️")
        try:
            _render_dock()
        except Exception:
            pass
        state.update(backup_done=False)
        page_request["id"] += 1
        request_id = page_request["id"]
        pdf_needed_pages.clear()
        pdf_pending.clear()
        pdf_layout["active"] = False
        state["drawing"] = None
        stack.set_visible_child_name("reader")
        state["pb"] = None
        canvas.set_size_request(1, 1)
        canvas.queue_draw()
        if ext == ".pdf":
            floatbar.show_all()
            toolbar_edge.show()
            toolbar_hover["inside"] = False
            _reveal_toolbar()
            resume_page = max(1, int(reading_pages.get(os.path.realpath(path), 1)))
            state.update(path=path, page=resume_page, pages=1, zoom=1.0,
                         strokes=[], redo=[], drawing=None)
            page_lbl.set_text(f"Resuming at page {resume_page}…" if resume_page > 1
                              else "Loading PDF…")
            _record_recent_document(path, resume_page)
            prev_btn.set_sensitive(False)
            next_btn.set_sensitive(False)
            page_cache.clear()
            page_cache_order.clear()
            _load_pdf_document(request_id, path, resume_page)
            canvas.grab_focus()
        else:
            _cancel_toolbar_hide()
            toolbar_hover["inside"] = False
            toolbar_edge.hide()
            floatbar.hide()
            state.update(path=path, pages=1, page=1, zoom=1.0,
                         strokes=[], redo=[], drawing=None)
            _record_recent_document(path, 1)
            page_lbl.set_text("Loading image…")
            view_w = img_scroll.get_allocated_width()
            view_h = img_scroll.get_allocated_height()
            if view_w <= 1 or view_h <= 1:
                screen = Gdk.Screen.get_default()
                screen_w = screen.get_width() if screen else 1440
                screen_h = screen.get_height() if screen else 900
                view_w = max(view_w, screen_w - 300)
                view_h = max(view_h, screen_h - 150)

            def _load_image():
                with media_worker_lock:
                    if request_id != page_request["id"]:
                        return
                    try:
                        info = GdkPixbuf.Pixbuf.get_file_info(path)
                        if info and info[1] > 0 and info[2] > 0:
                            source_w, source_h = info[1], info[2]
                            max_w = max(1, min(2400, view_w - 24 if view_w > 1 else 1200))
                            max_h = max(1, min(3000, view_h - 24 if view_h > 1 else 1400))
                            scale = min(1.0, max_w / float(source_w), max_h / float(source_h))
                            target_w = max(1, int(source_w * scale))
                            target_h = max(1, int(source_h * scale))
                            pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                                path, target_w, target_h, True)
                        else:
                            pb = GdkPixbuf.Pixbuf.new_from_file(path)
                        error = None
                    except Exception as e:
                        pb, error = None, str(e)
                def _apply_image():
                    if (request_id != page_request["id"] or state["path"] != path
                            or not win.get_visible()):
                        return False
                    if pb is None:
                        page_lbl.set_text("Image unavailable")
                        _toast(f"Cannot open image: {error}")
                    else:
                        _set_pb(pb)
                        page_lbl.set_text("Image")
                    canvas.grab_focus()
                    return False
                GLib.idle_add(_apply_image)

            threading.Thread(target=_load_image, daemon=True).start()

    # ---- annotation input ----
    def _pdf_point(x, y, page=None, clamp=False):
        if not pdf_layout["active"]:
            return None
        page_w, page_h = pdf_layout["page_w"], pdf_layout["page_h"]
        stride = page_h + PDF_GAP
        if page is None:
            page = int((y - PDF_GAP) // stride) + 1
        page = max(1, min(state["pages"], page))
        px = max(PDF_GAP, (_canvas_size()[0] - page_w) // 2)
        py = PDF_GAP + (page - 1) * stride
        local_x, local_y = x - px, y - py
        if not clamp and (local_x < 0 or local_x > page_w
                          or local_y < 0 or local_y > page_h):
            return None
        norm = (max(0.0, min(1.0, local_x / max(1, page_w))),
                max(0.0, min(1.0, local_y / max(1, page_h))))
        return page, norm

    def _on_press(_w, ev):
        if state["path"] is None or not state["path"].lower().endswith(".pdf"):
            return False
        if ev.button != 1:
            return False
        point = _pdf_point(ev.x, ev.y)
        if point is None:
            return False
        page, norm_point = point
        if page != state["page"]:
            _select_pdf_page(page)
        if state["tool"] == "erase":
            x, y = norm_point
            before = len(state["strokes"])
            state["strokes"] = [
                s for s in state["strokes"]
                if not any(abs(px - x) < 0.02 and abs(py - y) < 0.02 for px, py in s["pts"])
            ]
            if len(state["strokes"]) != before:
                _remember()
                canvas.queue_draw()
            return True
        state["drawing"] = {"tool": state["tool"], "page": page,
                             "pts": [norm_point]}
        canvas.queue_draw()
        return True

    def _on_motion(_w, ev):
        if state["drawing"] is None:
            return False
        pts = state["drawing"]["pts"]
        point = _pdf_point(ev.x, ev.y, state["drawing"]["page"], clamp=True)
        if point is None:
            return False
        p = point[1]
        if pts:
            w, h = pdf_layout["page_w"], pdf_layout["page_h"]
            dx = (p[0] - pts[-1][0]) * w
            dy = (p[1] - pts[-1][1]) * h
            dist = (dx * dx + dy * dy) ** 0.5
            if dist > 3.0:
                n = min(40, int(dist / 3.0))
                ox, oy = pts[-1]
                for k in range(1, n):
                    pts.append((ox + (p[0] - ox) * k / n, oy + (p[1] - oy) * k / n))
        pts.append(p)
        canvas.queue_draw()
        return True

    def _on_release(_w, _ev):
        cur = state["drawing"]
        state["drawing"] = None
        if cur and cur["pts"]:
            state["strokes"].append(cur)
            state["redo"] = []
            _remember()
            canvas.queue_draw()
        return True

    canvas.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK
                      | Gdk.EventMask.POINTER_MOTION_MASK
                      | Gdk.EventMask.BUTTON_MOTION_MASK
                      | Gdk.EventMask.BUTTON1_MOTION_MASK)
    canvas.connect("button-press-event", _on_press)
    canvas.connect("motion-notify-event", _on_motion)
    canvas.connect("button-release-event", _on_release)

    def _undo():
        if state["strokes"]:
            state["redo"].append(state["strokes"].pop())
            _remember()
            canvas.queue_draw()

    def _redo():
        if state["redo"]:
            state["strokes"].append(state["redo"].pop())
            _remember()
            canvas.queue_draw()

    def _save_annotations():
        path = state["path"]
        if not path or not path.lower().endswith(".pdf"):
            _toast("Save works on PDFs")
            return
        if not state["strokes"]:
            _toast("Nothing to save")
            return
        try:
            import cairo as _cairo
            from pypdf import PdfReader, PdfWriter

            w_pts, h_pts = state["page_pts"]
            tmp_pdf = os.path.join(tempfile.gettempdir(),
                                   f"focus-annot-{os.getpid()}-{state['page']}.pdf")
            surf = _cairo.PDFSurface(tmp_pdf, w_pts, h_pts)
            cr = _cairo.Context(surf)
            cr.set_line_cap(1)
            cr.set_line_join(1)
            for s in state["strokes"]:
                pts = _chaikin(s["pts"])
                (r, g, b), wdt, alpha = TOOL_STYLE.get(s["tool"], TOOL_STYLE["pen"])
                cr.set_source_rgba(r, g, b, alpha)
                cr.set_line_width(max(0.6, wdt * w_pts / 900.0))
                if len(pts) == 1:
                    cr.arc(pts[0][0] * w_pts, pts[0][1] * h_pts,
                           max(0.6, wdt * w_pts / 1800.0), 0, 6.283)
                    cr.fill()
                elif len(pts) > 1:
                    _trace(cr, pts, w_pts, h_pts)
                    cr.stroke()
            surf.finish()

            reader_pdf = PdfReader(path)
            overlay = PdfReader(tmp_pdf).pages[0]
            idx = min(len(reader_pdf.pages) - 1, max(0, state["page"] - 1))
            reader_pdf.pages[idx].merge_page(overlay)

            if not state["backup_done"]:
                shutil.copy2(path, path + ".bak")
                state["backup_done"] = True

            out = path + ".annot-tmp"
            writer = PdfWriter()
            for pg in reader_pdf.pages:
                writer.add_page(pg)
            with open(out, "wb") as f:
                writer.write(f)
            os.replace(out, path)
            state["strokes"], state["redo"] = [], []
            STROKE_MEM[(path, state["page"])] = ([], [])
            for cache_key in [k for k in page_cache if k[0] == path]:
                page_cache.pop(cache_key, None)
                if cache_key in page_cache_order:
                    page_cache_order.remove(cache_key)
            _toast(f"Saved into {os.path.basename(path)}")
            _show_page()
        except Exception as e:
            print(f"annot save error: {e}", flush=True)
            _toast(f"Save failed: {e}")

    def _set_tool(t):
        state["tool"] = t
        for b, name in ((pen_btn, "pen"), (high_btn, "high"), (erase_btn, "erase")):
            b.get_style_context().remove_class("floatbtn-on")
            if name == t:
                b.get_style_context().add_class("floatbtn-on")

    pen_btn.connect("clicked", lambda *_: _set_tool("pen"))
    high_btn.connect("clicked", lambda *_: _set_tool("high"))
    erase_btn.connect("clicked", lambda *_: _set_tool("erase"))
    undo_btn.connect("clicked", lambda *_: _undo())
    redo_btn.connect("clicked", lambda *_: _redo())
    save_btn.connect("clicked", lambda *_: _save_annotations())
    _set_tool("pen")

    def _change_page(delta):
        if pdf_layout["active"]:
            _goto_pdf_page(state["page"] + delta)

    def _change_zoom(delta):
        if not pdf_layout["active"]:
            return
        _remember()
        pdf_layout["restore_page"] = state["page"]
        pdf_layout["restoring"] = True
        page_request["id"] += 1
        pdf_pending.clear()
        pdf_needed_pages.clear()
        page_cache.clear()
        page_cache_order.clear()
        pdf_layout["fit_width"] = False
        state["zoom"] = max(0.10, min(3.0, state["zoom"] + delta))
        _update_pdf_layout()
        GLib.idle_add(_restore_pdf_scroll)

    def _fit_page(*_):
        if not pdf_layout["active"]:
            return
        pdf_layout["restore_page"] = state["page"]
        pdf_layout["restoring"] = True
        page_request["id"] += 1
        pdf_pending.clear()
        pdf_needed_pages.clear()
        page_cache.clear()
        page_cache_order.clear()
        pdf_layout["fit_width"] = True
        state["zoom"] = _fit_zoom()
        _update_pdf_layout()
        GLib.idle_add(_restore_pdf_scroll)

    def _actual_size(*_):
        if not pdf_layout["active"]:
            return
        pdf_layout["restore_page"] = state["page"]
        pdf_layout["restoring"] = True
        page_request["id"] += 1
        pdf_pending.clear()
        pdf_needed_pages.clear()
        page_cache.clear()
        page_cache_order.clear()
        pdf_layout["fit_width"] = False
        state["zoom"] = 1.0
        _update_pdf_layout()
        GLib.idle_add(_restore_pdf_scroll)

    prev_btn.connect("clicked", lambda *_: _change_page(-1))
    next_btn.connect("clicked", lambda *_: _change_page(1))
    zoom_in.connect("clicked", lambda *_: _change_zoom(0.25))
    zoom_out.connect("clicked", lambda *_: _change_zoom(-0.25))
    fit_btn.connect("clicked", _fit_page)
    actual_size_btn.connect("clicked", _actual_size)

    FILE_DL_EXTS = (".pdf", ".zip", ".rar", ".7z", ".tar", ".gz",
                    ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
                    ".mp3", ".m4a", ".wav", ".mp4", ".mkv", ".webm",
                    ".epub", ".txt", ".csv")
    _tab_seq = [0]
    _popup_seen = {}

    def _tab_icon(url, title=""):
        raw = f"{urlparse(url or '').hostname or ''} {title}".lower()
        if "notebook" in raw or "gemini" in raw:
            return "🧠"
        if "medical" in raw:
            return "🩺"
        if "boimate" in raw:
            return "📘"
        if "muslimbangla" in raw:
            return "🕌"
        if "ihadis" in raw or "hadith" in raw:
            return "📖"
        if "livemcq" in raw:
            return "🧪"
        if "translate" in raw:
            return "🔤"
        if "telegram" in raw:
            return "✈️"
        if "youtube" in raw or "youtu.be" in raw:
            return "▶️"
        if "drive.google" in raw or "docs.google" in raw:
            return "📚"
        return "🌐"

    def _tab_label(tab):
        title = (tab.get("title") or "").strip()
        if not title or title.startswith(("http://", "https://")):
            title = (urlparse(tab.get("url") or "").hostname or "New page")
        return title

    def _new_dock_row(icon, title, active, on_open, on_min=None,
                      on_close=None, minimized=False):
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=1)
        row.get_style_context().add_class("dockrow")
        if active:
            row.get_style_context().add_class("dockrow-active")
        open_btn = Gtk.Button()
        open_btn.get_style_context().add_class("dock-title-btn")
        open_btn.set_relief(Gtk.ReliefStyle.NONE)
        open_btn.set_hexpand(True)
        open_btn.set_tooltip_text(title)
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        icon_lbl = Gtk.Label(label=icon)
        icon_lbl.set_size_request(18, -1)
        title_lbl = Gtk.Label(label=("▁ " if minimized else "") + title)
        title_lbl.set_xalign(0.0)
        title_lbl.set_ellipsize(Pango.EllipsizeMode.END)
        title_lbl.set_max_width_chars(17)
        inner.pack_start(icon_lbl, False, False, 0)
        inner.pack_start(title_lbl, True, True, 0)
        open_btn.add(inner)
        open_btn.connect("clicked", lambda *_: on_open())
        row.pack_start(open_btn, True, True, 0)
        if on_close is not None:
            close_btn = Gtk.Button(label="×")
            close_btn.get_style_context().add_class("dockbtn")
            close_btn.get_style_context().add_class("dockclose")
            close_btn.set_tooltip_text("Close")
            close_btn.connect("clicked", lambda *_: on_close())
            row.pack_end(close_btn, False, False, 0)
        if on_min is not None:
            min_btn = Gtk.Button(label="▣" if minimized else "—")
            min_btn.get_style_context().add_class("dockbtn")
            min_btn.set_tooltip_text("Restore" if minimized else "Minimize")
            min_btn.connect("clicked", lambda *_: on_min())
            row.pack_end(min_btn, False, False, 0)
        return row

    def _render_dock(*_):
        try:
            for child in dock_box.get_children():
                dock_box.remove(child)
            current = stack.get_visible_child_name()
            active_web = (web_stack.get_visible_child_name()
                          if current == "web" else None)
            count = 0
            for tab in list(web_tabs):
                url = tab.get("url") or tab["view"].get_uri() or ""
                tab["url"] = url
                if tab["view"].get_title():
                    tab["title"] = tab["view"].get_title()
                row = _new_dock_row(
                    _tab_icon(url, tab.get("title", "")),
                    _tab_label(tab),
                    bool(active_web == tab["name"]),
                    lambda t=tab: _show_tab(t),
                    on_min=(lambda t=tab: _minimize_tab(t)),
                    on_close=(lambda t=tab: _close_tab(t)),
                    minimized=bool(tab.get("minimized")))
                dock_box.pack_start(row, False, False, 0)
                count += 1
            if doc_state.get("active"):
                doc_title = doc_state.get("title") or "Document"
                row = _new_dock_row(
                    doc_state.get("icon") or "📄",
                    doc_title,
                    current == "reader",
                    on_open=_show_doc,
                    on_min=_minimize_doc,
                    on_close=_close_doc,
                    minimized=bool(doc_state.get("minimized")))
                dock_box.pack_start(row, False, False, 0)
                count += 1
            if player_state.get("active"):
                p_title = player_state.get("title") or "Video Player"
                row = _new_dock_row(
                    "▶️",
                    p_title,
                    current == "player",
                    on_open=_show_player,
                    on_min=_minimize_player,
                    on_close=_close_player,
                    minimized=bool(player_state.get("minimized")))
                dock_box.pack_start(row, False, False, 0)
                count += 1
            if count == 0:
                empty = Gtk.Label(label="Websites open in Edge; PDFs/images open\n"
                                        "here in the reader.")
                empty.get_style_context().add_class("dockempty")
                empty.set_halign(Gtk.Align.START)
                empty.set_line_wrap(True)
                dock_box.pack_start(empty, False, False, 0)
                dock_count.set_text("Nothing open yet")
            else:
                dock_count.set_text(f"{count} open — click to switch")
            dock_box.show_all()
        except Exception as e:
            print(f"dock render error: {e}", flush=True)

    def _show_tab(tab):
        try:
            tab["minimized"] = False
            stack.set_visible_child_name("web")
            web_stack.set_visible_child_name(tab["name"])
            host = (urlparse(tab["view"].get_uri() or tab.get("url") or "")
                    .hostname or "").lower()
            _set_group_ui(host == TELEGRAM_WEB_HOST)
            _render_dock()
        except Exception as e:
            print(f"dock switch error: {e}", flush=True)

    def _minimize_tab(tab):
        tab["minimized"] = True
        try:
            if (stack.get_visible_child_name() == "web"
                    and web_stack.get_visible_child_name() == tab["name"]):
                stack.set_visible_child_name("home")
            _render_dock()
        except Exception:
            pass

    def _close_tab(tab):
        try:
            was_current = (stack.get_visible_child_name() == "web"
                           and web_stack.get_visible_child_name() == tab["name"])
            if tab.get("main"):
                try:
                    tab["view"].stop_loading()
                    tab["view"].load_uri("about:blank")
                except Exception:
                    pass
            else:
                try:
                    web_stack.remove(tab["wrap"])
                except Exception:
                    pass
                try:
                    tab["view"].destroy()
                except Exception:
                    pass
            if tab in web_tabs:
                web_tabs.remove(tab)
            if was_current:
                remaining = [t for t in web_tabs if not t.get("minimized")]
                if remaining:
                    _show_tab(remaining[-1])
                elif doc_state.get("active") and not doc_state.get("minimized"):
                    _show_doc()
                else:
                    stack.set_visible_child_name("home")
            _render_dock()
        except Exception as e:
            print(f"dock close error: {e}", flush=True)

    def _show_doc():
        try:
            doc_state["minimized"] = False
            stack.set_visible_child_name("reader")
            _set_group_ui(False)
            _render_dock()
        except Exception:
            pass

    def _minimize_doc():
        doc_state["minimized"] = True
        try:
            if stack.get_visible_child_name() == "reader":
                stack.set_visible_child_name("home")
            _render_dock()
        except Exception:
            pass

    def _close_doc():
        try:
            if state.get("path") and str(state["path"]).lower().endswith(".pdf"):
                _save_reading_page(state["path"], state.get("page", 1))
        except Exception:
            pass
        doc_state.update(active=False, title="", icon="📄", minimized=False)
        try:
            if stack.get_visible_child_name() == "reader":
                stack.set_visible_child_name("home")
            _render_dock()
        except Exception:
            pass

    def _tab_policy(view, decision, dtype):
        try:
            if dtype == WebKit2.PolicyDecisionType.RESPONSE:
                response = decision.get_response()
                uri = response.get_uri() or ""
                mime = (response.get_mime_type() or "").lower().split(";", 1)[0].strip()
                path = urlparse(uri).path.lower()
                is_attachment = bool(response.get_suggested_filename())
                unsupported = not decision.is_mime_type_supported()
                is_file = path.endswith(FILE_DL_EXTS)
                if (is_attachment or unsupported or is_file
                        or mime == "application/pdf"):
                    if (_page_allowed(uri, allow)
                            or _page_allowed(view.get_uri() or "", allow)
                            or (uri.startswith("blob:") and _page_allowed(uri, allow))):
                        decision.download()
                        return True
            if dtype == WebKit2.PolicyDecisionType.NAVIGATION_ACTION:
                uri = decision.get_navigation_action().get_request().get_uri() or ""
                parsed = urlparse(uri)
                if uri == "about:blank":
                    return False
                if parsed.scheme == "blob" and _page_allowed(uri, allow):
                    return False
                if parsed.scheme not in ("http", "https", "file"):
                    decision.ignore()
                    return True
                if parsed.scheme == "file":
                    local_path = os.path.realpath(
                        urllib.parse.unquote(parsed.path))
                    media_ext = os.path.splitext(local_path)[1].lower()
                    trusted = [os.path.realpath(p) for p in
                               (DOWNLOAD_DIR, STUDY_INBOX)]
                    if (media_ext in MEDIA_EXTS and os.path.isfile(local_path)
                            and any(local_path.startswith(d + os.sep)
                                    for d in trusted)):
                        decision.ignore()
                        GLib.idle_add(_open_media, local_path)
                        return True
                    decision.ignore()
                    _toast("Blocked: local file access is limited to opened study materials")
                    return True
                if _page_allowed(uri, allow):
                    if uri.lower().split("?")[0].endswith(FILE_DL_EXTS):
                        decision.ignore()
                        try:
                            view.download_uri(uri)
                        except Exception:
                            pass
                        return True
                    return False
                decision.ignore()
                print(f"nav blocked (tab): {uri}", flush=True)
                _toast(f"Blocked: {parsed.hostname or uri} — not in study list")
                return True
            if dtype == WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION:
                uri = decision.get_navigation_action().get_request().get_uri() or ""
                decision.ignore()
                if uri:
                    if uri.lower().split("?")[0].endswith(FILE_DL_EXTS):
                        try:
                            view.download_uri(uri)
                        except Exception:
                            pass
                        return True
                    if (_page_allowed(uri, allow)
                            or uri == "about:blank"
                            or (uri.startswith("blob:") and _page_allowed(uri, allow))):
                        GLib.idle_add(_open_popup, uri)
                    else:
                        print(f"popup blocked: {uri}", flush=True)
                        _toast("Popup blocked: site is not in the study list")
                return True
        except Exception as e:
            print(f"tab policy error: {e}", flush=True)
        return False

    def _tab_create(parent_view, navigation_action):
        try:
            req = navigation_action.get_request() if navigation_action else None
            uri = req.get_uri() if req else ""
            if uri:
                if uri.lower().split("?")[0].endswith(FILE_DL_EXTS):
                    parent_view.download_uri(uri)
                    return None
                if (_page_allowed(uri, allow)
                        or uri == "about:blank"
                        or (uri.startswith("blob:") and _page_allowed(uri, allow))):
                    GLib.idle_add(_open_popup, uri)
                else:
                    print(f"popup blocked (create): {uri}", flush=True)
                    _toast("Popup blocked: site is not in the study list")
        except Exception as e:
            print(f"popup create error: {e}", flush=True)
        try:
            tmp = WebKit2.WebView.new_with_context(parent_view.get_context())
            GLib.timeout_add_seconds(10, lambda: (tmp.destroy(), False)[1])
            return tmp
        except Exception:
            return None

    def _open_popup(uri):
        now = time.time()
        if _popup_seen.get(uri, 0) > now - 2:
            return
        _popup_seen[uri] = now
        _open_web_url(uri, force_new=True, allow_special=True)

    def _create_web_tab(url, main=False):
        if main:
            name = "web-main"
            view, wrap = web, web_wrap
        else:
            _tab_seq[0] += 1
            name = f"web-tab-{_tab_seq[0]}"
            try:
                if _study_web_context is not None and _study_ucm is not None:
                    view = WebKit2.WebView(
                        web_context=_study_web_context,
                        user_content_manager=_study_ucm)
                elif _study_web_context is not None:
                    view = WebKit2.WebView.new_with_context(_study_web_context)
                else:
                    view = WebKit2.WebView()
            except Exception:
                view = WebKit2.WebView()
            try:
                _configure_study_settings(view.get_settings())
            except Exception:
                pass
            view.set_hexpand(True)
            view.set_vexpand(True)
            scroll = Gtk.ScrolledWindow()
            scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            scroll.add(view)
            wrap = Gtk.Overlay()
            wrap.add(scroll)
            nav = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            nav.get_style_context().add_class("floatbar")
            nav.set_halign(Gtk.Align.END)
            nav.set_valign(Gtk.Align.START)
            nav.set_margin_top(10)
            nav.set_margin_end(12)
            back_b = Gtk.Button(label="‹")
            fwd_b = Gtk.Button(label="›")
            for nav_btn in (back_b, fwd_b):
                nav_btn.get_style_context().add_class("floatbtn")
                nav_btn.get_style_context().add_class("webnavbtn")
                nav_btn.set_size_request(30, 30)
                nav.pack_start(nav_btn, False, False, 0)
            back_b.set_tooltip_text("Back")
            fwd_b.set_tooltip_text("Forward")
            back_b.connect("clicked", lambda *_: view.go_back()
                           if view.can_go_back() else None)
            fwd_b.connect("clicked", lambda *_: view.go_forward()
                          if view.can_go_forward() else None)
            wrap.add_overlay(nav)
            web_stack.add_named(wrap, name)
            wrap.show_all()
            view.connect("authenticate", _on_web_authenticate)
            view.connect("permission-request",
                         lambda _v, req: (req.allow(), True)[1])
            view.connect("context-menu", lambda *_: True)
            view.connect("decide-policy",
                         lambda _v, d, t: _tab_policy(view, d, t))
            view.connect("create", lambda _v, nav_a: _tab_create(view, nav_a))
            view.connect("load-changed",
                         lambda _v, ev: _on_tab_load(tab, ev))
        tab = {"id": name, "name": name, "view": view, "wrap": wrap,
               "url": url, "title": "", "minimized": False, "main": main}
        web_tabs.append(tab)
        return tab

    def _on_tab_load(tab, event):
        try:
            if event == WebKit2.LoadEvent.STARTED:
                tab["url"] = tab["view"].get_uri() or tab["url"]
                _show_loading()
            elif event == WebKit2.LoadEvent.FINISHED:
                tab["url"] = tab["view"].get_uri() or tab["url"]
                title = tab["view"].get_title()
                if title:
                    tab["title"] = title
                _hide_loading()
                _record_recent_website(tab["url"], title)
                _render_dock()
        except Exception as e:
            print(f"tab load event error: {e}", flush=True)

    edge_watch = {"id": 0, "ticks": 0, "seen": False}

    def _edge_profile_running():
        try:
            for entry in os.listdir("/proc"):
                if not entry.isdigit():
                    continue
                try:
                    with open(f"/proc/{entry}/cmdline", "rb") as f:
                        if b"study-edge-profile" in f.read():
                            return True
                except Exception:
                    continue
        except Exception:
            pass
        return False

    def _pause_focus_for_edge():
        global EXTERNAL_BROWSER_ACTIVE
        EXTERNAL_BROWSER_ACTIVE = True
        try:
            win.unfullscreen()
            win.set_keep_above(False)
        except Exception:
            pass

    def _resume_focus_after_edge():
        global EXTERNAL_BROWSER_ACTIVE
        EXTERNAL_BROWSER_ACTIVE = False
        try:
            win.set_keep_above(True)
            win.fullscreen()
            win.present()
        except Exception:
            pass

    def _watch_edge_close():
        edge_watch["ticks"] += 1
        if _edge_profile_running():
            edge_watch["seen"] = True
            return True
        # Give a newly launched Edge a few seconds to appear before restoring.
        if not edge_watch["seen"] and edge_watch["ticks"] < 5:
            return True
        edge_watch["id"] = 0
        _resume_focus_after_edge()
        return False

    def _open_edge_and_watch(raw):
        _pause_focus_for_edge()
        if not _open_in_edge(raw):
            _resume_focus_after_edge()
            return False
        if not edge_watch["id"]:
            edge_watch["ticks"] = 0
            edge_watch["seen"] = False
            edge_watch["id"] = GLib.timeout_add(1000, _watch_edge_close)
        return True

    def _show_player():
        player_state["minimized"] = False
        stack.set_visible_child_name("player")
        _render_dock()

    def _minimize_player():
        player_state["minimized"] = True
        stack.set_visible_child_name("home")
        _render_dock()

    def _close_player(*_):
        player_state["active"] = False
        player_web.load_uri("about:blank")
        _render_dock()
        if doc_state.get("active"):
            _show_doc()
        else:
            stack.set_visible_child_name("home")

    player_close_btn.connect("clicked", _close_player)

    def _play_youtube_native(vid, raw_url=None):
        if not vid:
            _toast("Enter a valid YouTube video link or ID")
            return False
        player_state["active"] = True
        player_state["vid"] = vid
        player_state["title"] = f"YouTube · {vid}"
        player_state["minimized"] = False
        player_sub_lbl.set_text(f"ID: {vid}")
        html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  html, body {{ margin: 0; padding: 0; width: 100%; height: 100%; background: #000; overflow: hidden; }}
  iframe {{ border: 0; width: 100%; height: 100%; display: block; }}
</style>
</head>
<body>
  <iframe src="https://www.youtube-nocookie.com/embed/{vid}?autoplay=1&controls=1&modestbranding=1&rel=0&iv_load_policy=3&playsinline=1"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</body>
</html>"""
        player_web.load_html(html, "https://www.youtube-nocookie.com")
        stack.set_visible_child_name("player")
        _render_dock()
        _record_recent("web", raw_url or f"https://www.youtube.com/watch?v={vid}", f"YouTube · {vid}")
        _toast(f"▶ Playing video in Native Player: {vid}")
        return True

    def _play_local_video_native(path):
        if not os.path.isfile(path):
            _toast("Video file not found")
            return
        fname = os.path.basename(path)
        player_state["active"] = True
        player_state["vid"] = fname
        player_state["title"] = fname
        player_state["minimized"] = False
        player_sub_lbl.set_text(fname)
        file_uri = Gio.File.new_for_path(os.path.abspath(path)).get_uri()
        html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  html, body {{ margin: 0; padding: 0; width: 100%; height: 100%; background: #000; overflow: hidden; display: flex; justify-content: center; align-items: center; }}
  video {{ max-width: 100%; max-height: 100%; width: 100%; height: 100%; outline: none; }}
</style>
</head>
<body>
  <video src="{file_uri}" controls autoplay></video>
</body>
</html>"""
        player_web.load_html(html, "file:///")
        stack.set_visible_child_name("player")
        _render_dock()
        _record_recent_document(path, 1)
        _toast(f"▶ Playing: {fname}")

    def _launch_study_edge(url, title=""):
        """Open a web target in restricted Edge app mode."""
        raw = str(url or "").strip()
        if not raw:
            return False
        if "://" not in raw:
            raw = "https://" + raw
        parsed = urlparse(raw)
        host = (parsed.hostname or "").lower()
        if _host_blocked(host):
            _toast("Blocked: search engines, social media and adult sites are disabled")
            return False
        if host == TELEGRAM_WEB_HOST or host.endswith((".telegram.org", ".t.me")):
            if not parsed.fragment or parsed.fragment.lower() in ("-1004415493319", "4415493319", "pdf258upload"):
                raw = TELEGRAM_GROUP_URL
            host = TELEGRAM_WEB_HOST
        if _is_youtube_host(host):
            vid = _youtube_video_id(raw)
            if not vid:
                _toast("Full YouTube is blocked — only a specific video link/ID works")
                return False
            # Specific YouTube video plays in the Native Video Player
            return _play_youtube_native(vid, raw)

        # In Study Mode, any website not in blocked categories opens in restricted Edge
        if not _open_edge_and_watch(raw):
            _toast("Microsoft Edge is not installed")
            return False
        _record_recent("web", raw, title or host or raw)
        _toast(f"↗ Opened {host or 'page'} in Edge")
        return True

    def _open_address_entry(entry):
        raw = (entry.get_text() or "").strip()
        if not raw:
            return
        entry.set_text("")

        # 1. Check explicit keyword filter
        hit = _explicit_hit(raw)
        if hit:
            _record_input_violation()
            if _study_block_count_updater:
                _study_block_count_updater()
            _toast(f"⛔ Blocked explicit keyword: {hit}")
            return

        # 2. Check if input is a YouTube video link or 11-char video ID
        vid = _youtube_video_id(raw)
        if not vid and re.fullmatch(r"[A-Za-z0-9_-]{11}", raw):
            vid = raw

        target_url = raw if "://" in raw else "https://" + raw
        parsed = urlparse(target_url)
        host = (parsed.hostname or "").lower()

        if _is_youtube_host(host):
            if vid:
                _play_youtube_native(vid, raw)
                return
            else:
                _toast("Blocked: Full YouTube browsing is disabled. Only specific video links work.")
                return

        if vid and ("youtube" in raw or "youtu.be" in raw):
            _play_youtube_native(vid, raw)
            return

        # 3. Check website scheme
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            _toast("Enter a website address starting with http:// or https://")
            return

        # 4. Check blocked categories: search engines, social media, adult domains
        if _host_blocked(host):
            _toast("Blocked: Search engines, social media, and adult sites are disabled")
            return

        # 5. Open allowed website in restricted Edge (never WebKit)
        _launch_study_edge(target_url)

    address_entry.connect("activate", _open_address_entry)

    def _open_web_url(url, force_new=False, allow_special=False, title=""):
        raw = str(url or "").strip()
        if not raw:
            return None
        if raw.startswith(("about:", "blob:", "data:")):
            if not allow_special:
                return None
        elif raw.startswith("file:"):
            pass
        else:
            _launch_study_edge(raw, title=title)
            return None
        if not force_new:
            for tab in web_tabs:
                current = tab.get("url") or tab["view"].get_uri() or ""
                if current == raw:
                    _show_tab(tab)
                    return tab
            for tab in web_tabs:
                if (tab["view"].get_uri() or "") == raw:
                    _show_tab(tab)
                    return tab
        main = not any(t.get("main") for t in web_tabs)
        tab = _create_web_tab(raw, main=main)
        if title:
            tab["title"] = title
        _show_tab(tab)
        _show_loading()
        try:
            tab["view"].load_uri(raw)
        except Exception as e:
            print(f"tab load error: {e}", flush=True)
        _render_dock()
        return tab

    def _load_link(url):
        url_clean = str(url or "").strip().lower()
        if (url_clean in ("tg-materials", "pdf-materials", "pdf materials (cloud)", "pdf materials cloud")
                or "telegram-materials" in url_clean
                or (urlparse(url or "").hostname or "").lower() == TELEGRAM_WEB_HOST
                or str(url).strip() == TELEGRAM_GROUP_URL):
            _launch_study_edge(TELEGRAM_GROUP_URL, title="PDF Materials")
            return
        if url_clean in ("tg-biprova", "biprova", "biprova 20", "biprov", "biprova (cloud)", "biprova 20 (cloud)"):
            b_peer = _load_telegram_biprova_peer()
            b_target = f"https://{TELEGRAM_WEB_HOST}{TELEGRAM_WEB_PATH}/#{b_peer}" if b_peer else f"https://{TELEGRAM_WEB_HOST}{TELEGRAM_WEB_PATH}/#biprova"
            _launch_study_edge(b_target, title="Biprova 20")
            return
        if url.startswith("file://"):
            _open_web_url(url)
            return
        _launch_study_edge(url)

    def _make_side_btn(icon_text, tooltip, on_click):
        btn = Gtk.Button()
        btn.get_style_context().add_class("sidebtn")
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.set_halign(Gtk.Align.FILL)
        btn.set_hexpand(False)
        lbl = Gtk.Label(label=icon_text)
        lbl.set_xalign(0.0)
        lbl.set_ellipsize(Pango.EllipsizeMode.END)
        lbl.set_max_width_chars(21)
        btn.add(lbl)
        if tooltip:
            btn.set_tooltip_text(str(tooltip))
        btn.connect("clicked", on_click)
        return btn

    for item in cfg.get("links", []):
        t = str(item.get("title", "Link"))
        u = str(item.get("url", ""))
        b = _make_side_btn(f"↗  {t}", f"{t}\n{u}", lambda _b, target=u: _load_link(target))
        links_box.pack_start(b, False, False, 0)


    def _open_files(*_):
        chooser = Gtk.FileChooserDialog(
            title="Open PDF / Image",
            parent=win,
            action=Gtk.FileChooserAction.OPEN)
        chooser.set_transient_for(win)
        chooser.set_modal(True)
        chooser.set_keep_above(True)
        chooser.set_position(Gtk.WindowPosition.CENTER_ON_PARENT)
        chooser.add_button("Cancel", Gtk.ResponseType.CANCEL)
        chooser.add_button("Open", Gtk.ResponseType.ACCEPT)
        chooser.set_select_multiple(True)
        if os.path.isdir(STUDY_INBOX):
            try:
                chooser.set_current_folder(STUDY_INBOX)
            except Exception:
                pass
        for mnt_cand in (os.path.expanduser("~/PDF-Materials"), os.path.expanduser("~/Telegram-Materials")):
            if os.path.isdir(mnt_cand):
                try:
                    chooser.add_shortcut_folder(mnt_cand)
                except Exception:
                    pass

        all_filter = Gtk.FileFilter()
        all_filter.set_name("PDF and Images (*.pdf, *.png, *.jpg…)")
        all_filter.add_mime_type("application/pdf")
        for ext_p in ("*.pdf", "*.PDF", "*.jpg", "*.jpeg", "*.png", "*.webp", "*.gif", "*.bmp",
                      "*.JPG", "*.JPEG", "*.PNG", "*.WEBP", "*.GIF", "*.BMP"):
            all_filter.add_pattern(ext_p)
        chooser.add_filter(all_filter)

        response = chooser.run()
        uris = chooser.get_uris() if response == Gtk.ResponseType.ACCEPT else []
        chooser.destroy()
        if not uris:
            return
        opened = None
        rejected = 0
        for uri in uris:
            if not uri.startswith("file://"):
                rejected += 1
                continue
            path = os.path.realpath(urllib.parse.unquote(uri[7:]))
            if (os.path.isfile(path)
                    and os.path.splitext(path)[1].lower() in MEDIA_EXTS):
                opened = path
            else:
                rejected += 1
        if opened:
            _open_media(opened)
            if rejected:
                _toast(f"Opened last file; {rejected} not supported")
        else:
            _toast("Only PDF/image files can be opened")

    usb_import_btn.connect("clicked", _open_files)

    kw_popover = Gtk.Popover.new(add_kw_btn)
    kw_popover.set_position(Gtk.PositionType.BOTTOM)

    kw_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
    kw_box.get_style_context().add_class("kw-popover")
    kw_box.set_margin_top(6)
    kw_box.set_margin_bottom(6)
    kw_box.set_margin_start(8)
    kw_box.set_margin_end(8)

    kw_entry = Gtk.Entry()
    kw_entry.set_width_chars(20)
    kw_entry.set_placeholder_text("Add blocked keyword…")
    kw_box.pack_start(kw_entry, True, True, 0)

    kw_submit_btn = Gtk.Button(label="Add")
    kw_submit_btn.get_style_context().add_class("topbar-btn")
    kw_box.pack_start(kw_submit_btn, False, False, 0)

    kw_feedback_lbl = Gtk.Label(label="")
    kw_feedback_lbl.get_style_context().add_class("kw-feedback")
    kw_box.pack_start(kw_feedback_lbl, False, False, 0)

    kw_popover.add(kw_box)

    def _submit_kw(*_):
        raw = (kw_entry.get_text() or "").strip()
        if not raw:
            return
        kw_entry.set_text("")
        if _is_keyword_blocked(raw):
            kw_feedback_lbl.set_text("Already blocked")
            _toast("That keyword is already blocked")
        else:
            if not _add_blocked_keyword(raw):
                kw_feedback_lbl.set_text("Save failed")
                _toast("Could not save that blocked keyword")
                GLib.idle_add(kw_entry.grab_focus)
                return
            # Refresh the unpacked Edge extension on disk. Edge applies a
            # changed content script after its Study Mode process restarts.
            _ensure_edge_extension()
            js = f"if (window.__focusAddWord) window.__focusAddWord({json.dumps(raw.lower())});"
            for tab in list(web_tabs):
                try:
                    tab["view"].run_javascript(js, None, None, None)
                except Exception:
                    try:
                        tab["view"].run_javascript(js)
                    except Exception:
                        pass
            kw_feedback_lbl.set_text("✔ Done")
            _toast("Keyword saved and filter updated")
        GLib.idle_add(kw_entry.grab_focus)

    def _toggle_kw_popover(*_):
        if kw_popover.get_visible():
            kw_popover.popdown()
        else:
            kw_entry.set_text("")
            kw_feedback_lbl.set_text("")
            kw_popover.show_all()
            kw_popover.popup()
            GLib.idle_add(kw_entry.grab_focus)

    kw_entry.connect("activate", _submit_kw)
    kw_submit_btn.connect("clicked", _submit_kw)
    add_kw_btn.connect("clicked", _toggle_kw_popover)

    back_btn = Gtk.Button(label="\u2190 Back to Lockout" if end_ts else "\u2190 Back to Work")
    back_btn.get_style_context().add_class("backbtn")
    back_btn.set_size_request(-1, 30)
    side.pack_start(back_btn, False, False, 2)

    right.pack_start(bar, False, False, 0)
    right.pack_start(telegram_header, False, False, 0)
    right.pack_start(stack_wrap, True, True, 0)
    outer.pack_start(side, False, False, 0)
    outer.pack_start(right, True, True, 0)

    root = Gtk.Overlay()
    root.add(outer)
    toast_lbl = Gtk.Label(label="")
    toast_lbl.get_style_context().add_class("toastlbl")
    toast_lbl.set_halign(Gtk.Align.CENTER)
    toast_lbl.set_valign(Gtk.Align.END)
    toast_lbl.set_margin_bottom(70)
    toast_lbl.set_no_show_all(True)
    root.add_overlay(toast_lbl)

    recent_panel = Gtk.EventBox()
    recent_panel.set_visible_window(False)
    recent_panel.set_halign(Gtk.Align.END)
    recent_panel.set_valign(Gtk.Align.START)
    recent_panel.set_margin_top(58)
    recent_panel.set_margin_end(14)
    recent_panel.add_events(Gdk.EventMask.ENTER_NOTIFY_MASK | Gdk.EventMask.LEAVE_NOTIFY_MASK)
    recent_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
    recent_card.get_style_context().add_class("recentpanel")
    recent_card.set_size_request(320, -1)
    recent_heading = Gtk.Label(label="RECENT SITES & DOCUMENTS")
    recent_heading.get_style_context().add_class("recentheading")
    recent_heading.set_halign(Gtk.Align.START)
    recent_headrow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
    recent_headrow.pack_start(recent_heading, True, True, 0)
    recent_close_btn = Gtk.Button(label="×")
    recent_close_btn.get_style_context().add_class("webnavbtn")
    recent_close_btn.set_relief(Gtk.ReliefStyle.NONE)
    recent_close_btn.set_tooltip_text("Close recent items")
    recent_headrow.pack_end(recent_close_btn, False, False, 0)
    recent_card.pack_start(recent_headrow, False, False, 0)
    recent_scroll = Gtk.ScrolledWindow()
    recent_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    recent_scroll.set_min_content_height(260)
    recent_scroll.set_max_content_height(520)
    recent_scroll.set_vexpand(True)
    recent_rows = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
    recent_scroll.add(recent_rows)
    recent_card.pack_start(recent_scroll, True, True, 0)
    recent_panel.add(recent_card)
    recent_panel.set_no_show_all(True)
    root.add_overlay(recent_panel)

    def _render_recent():
        if recent_rows is None:
            return
        for child in recent_rows.get_children():
            recent_rows.remove(child)
        if not recent_items:
            empty = Gtk.Label(label="Websites and documents you open will appear here.")
            empty.set_line_wrap(True)
            empty.set_halign(Gtk.Align.START)
            empty.set_margin_top(12)
            empty.set_margin_bottom(12)
            recent_rows.pack_start(empty, False, False, 0)
        for item in recent_items[:30]:
            kind = item.get("kind")
            if kind == "doc":
                path = item.get("path", "")
                page = max(1, int(item.get("page", reading_pages.get(path, 1))))
                icon = "PDF" if path.lower().endswith(".pdf") else "FILE"
                subtitle = f"{icon}  Page {page}  ·  {os.path.dirname(path)}"
            elif kind == "web":
                path = ""
                url = item.get("url", "")
                subtitle = urlparse(url).hostname or url
            else:
                continue
            button = Gtk.Button()
            button.set_relief(Gtk.ReliefStyle.NONE)
            button.set_halign(Gtk.Align.FILL)
            button.get_style_context().add_class("recentrow")
            row = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
            title_lbl = Gtk.Label(label=("📄  " if kind == "doc" else "↗  ")
                                  + str(item.get("title") or os.path.basename(path)))
            title_lbl.set_halign(Gtk.Align.START)
            title_lbl.set_ellipsize(Pango.EllipsizeMode.END)
            subtitle_lbl = Gtk.Label(label=subtitle)
            subtitle_lbl.set_halign(Gtk.Align.START)
            subtitle_lbl.set_ellipsize(Pango.EllipsizeMode.END)
            row.pack_start(title_lbl, False, False, 0)
            row.pack_start(subtitle_lbl, False, False, 0)
            button.add(row)
            button.set_tooltip_text(item.get("path") or item.get("url", ""))
            button.connect("clicked", lambda _b, recent=dict(item): _open_recent(recent))
            recent_rows.pack_start(button, False, False, 0)
        recent_rows.show_all()

    def _open_recent(item):
        if item.get("kind") == "doc":
            path = item.get("path", "")
            if os.path.isfile(path):
                _open_media(path)
            else:
                _toast("That document is no longer available at its saved location")
        elif item.get("kind") == "web":
            url = item.get("url", "")
            if (urlparse(url).hostname or "").lower() == TELEGRAM_WEB_HOST:
                url = TELEGRAM_GROUP_URL
            if url:
                _launch_study_edge(url, title=str(item.get("title") or ""))
            else:
                _toast("This recent website is no longer available")
        _hide_recent_panel()

    def _hide_recent_panel(*_):
        if recent_hide_state["id"]:
            GLib.source_remove(recent_hide_state["id"])
            recent_hide_state["id"] = 0
        recent_panel.hide()
        recent_panel.set_no_show_all(True)

    def _show_recent_panel(*_):
        if recent_hide_state["id"]:
            GLib.source_remove(recent_hide_state["id"])
            recent_hide_state["id"] = 0
        if not recent_panel.get_visible():
            _render_recent()
        recent_panel.set_no_show_all(False)
        recent_panel.show_all()
        recent_panel.set_no_show_all(True)
        return False

    recent_close_btn.connect("clicked", _hide_recent_panel)
    recent_btn.connect("clicked", lambda *_: _hide_recent_panel()
                       if recent_panel.get_visible() else _show_recent_panel())

    load_screen = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
    load_screen.get_style_context().add_class("loadscreen")
    load_screen.set_no_show_all(True)
    load_screen.set_halign(Gtk.Align.START)
    load_screen.set_valign(Gtk.Align.START)
    load_screen.set_margin_top(12)
    load_screen.set_margin_start(12)
    load_inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
    load_inner.set_halign(Gtk.Align.END)
    load_inner.set_valign(Gtk.Align.START)
    load_head = Gtk.Label(label="Please Don't Waste Your Time")
    load_head.get_style_context().add_class("loadhead")
    load_inner.pack_start(load_head, False, False, 0)
    load_screen.pack_start(load_inner, True, True, 0)
    stack_wrap.add_overlay(load_screen)

    load_timer = {"safety_id": 0}

    def _do_hide():
        load_timer["safety_id"] = 0
        try:
            load_screen.hide()
            load_screen.set_no_show_all(True)
        except Exception:
            pass
        return False

    def _show_loading():
        try:
            if load_screen.get_visible():
                return
            load_screen.set_no_show_all(False)
            load_screen.show_all()
            load_timer["safety_id"] = GLib.timeout_add_seconds(20, _do_hide)
        except Exception:
            pass

    def _hide_loading():
        """Hide the non-blocking status immediately when WebKit finishes."""
        try:
            if load_timer["safety_id"]:
                GLib.source_remove(load_timer["safety_id"])
                load_timer["safety_id"] = 0
            _do_hide()
        except Exception:
            pass

    if WebKit2 is not None:
        def _on_load_changed(_v, ev):
            try:
                if ev == WebKit2.LoadEvent.STARTED:
                    _show_loading()
                elif ev == WebKit2.LoadEvent.FINISHED:
                    _hide_loading()
                    _record_recent_website(web.get_uri(), web.get_title())
                    _render_dock()
            except Exception:
                pass

        def _on_load_failed(*_a):
            _hide_loading()

        web.connect("load-changed", _on_load_changed)
        web.connect("load-failed", _on_load_failed)

    win.add(root)

    # ---- intake: drag & drop / clipboard ----
    try:
        win.drag_dest_set(Gtk.DestDefaults.ALL, [Gtk.TargetEntry.new("text/uri-list", 0, 0)],
                          Gdk.DragAction.COPY)
    except Exception:
        pass

    def _on_drop(_w, _ctx, _x, _y, data, _info, _time):
        try:
            uris = data.get_uris()
            paths = [urllib.parse.unquote(u[7:]) for u in uris if u.startswith("file://")]
            n = _copy_into_inbox(paths, MEDIA_EXTS)
            if n:
                newest = None
                try:
                    candidates = [os.path.join(STUDY_INBOX, name)
                                  for name in os.listdir(STUDY_INBOX)]
                    media = [p for p in candidates
                             if os.path.isfile(p)
                             and os.path.splitext(p)[1].lower() in MEDIA_EXTS]
                    if media:
                        newest = max(media, key=os.path.getmtime)
                except Exception:
                    pass
                if newest:
                    _open_media(newest)
                else:
                    _toast(f"Saved {n} file(s) to study inbox")
            else:
                _toast("Only PDF/image files are accepted")
        except Exception as e:
            print(f"drop error: {e}", flush=True)
        return True

    win.connect("drag-data-received", _on_drop)

    def _paste_image():
        try:
            cb = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
            pb = cb.wait_for_image()
            if pb is None:
                _toast("Clipboard has no image")
                return
            os.makedirs(STUDY_INBOX, exist_ok=True)
            dst = os.path.join(STUDY_INBOX,
                               time.strftime("clipboard-%Y%m%d-%H%M%S.png"))
            pb.savev(dst, "png", [], [])
            _toast(f"Opened {os.path.basename(dst)}")
            _open_media(dst)
        except Exception as e:
            print(f"paste error: {e}", flush=True)

    def _on_back_clicked(*_):
        _clear_study_active()
        _clear_study_starting()
        t_end = time.time() + 0.15
        while time.time() < t_end:
            while Gtk.events_pending():
                Gtk.main_iteration_do(False)
            time.sleep(0.01)
        if _study_parent is not None:
            try:
                _study_parent.show()
                _study_parent.present()
                while Gtk.events_pending():
                    Gtk.main_iteration_do(False)
            except Exception:
                pass
        win.destroy()

    def _handle_key(kv, state_mask):
        try:
            st = state_mask
            mods = st & Gtk.accelerator_get_default_mod_mask()
            ctrl = bool(mods & Gdk.ModifierType.CONTROL_MASK)
            if kv == Gdk.KEY_Escape:
                if stack.get_visible_child_name() == "player":
                    _close_player()
                    return True
                _on_back_clicked()
                return True
            if (ctrl and kv in (Gdk.KEY_b, Gdk.KEY_B)) or kv == Gdk.KEY_F9:
                _toggle_sidebar()
                return True
            if ctrl and kv in (Gdk.KEY_l, Gdk.KEY_t, Gdk.KEY_n, Gdk.KEY_w,
                               Gdk.KEY_p, Gdk.KEY_j, Gdk.KEY_u):
                return True
            if kv in (Gdk.KEY_F6, Gdk.KEY_F11, Gdk.KEY_F12):
                return True
            if ctrl and kv == Gdk.KEY_v and stack.get_visible_child_name() != "web":
                _paste_image()
                return True
            if stack.get_visible_child_name() == "reader":
                if pdf_layout["active"] and kv in (
                        Gdk.KEY_Up, Gdk.KEY_Left, Gdk.KEY_KP_Up, Gdk.KEY_KP_Left):
                    _change_page(-1)
                    return True
                if pdf_layout["active"] and kv in (
                        Gdk.KEY_Down, Gdk.KEY_Right, Gdk.KEY_KP_Down, Gdk.KEY_KP_Right):
                    _change_page(1)
                    return True
                if kv in (Gdk.KEY_Page_Down, Gdk.KEY_KP_Page_Down):
                    next_btn.emit("clicked")
                    return True
                if kv in (Gdk.KEY_Page_Up, Gdk.KEY_KP_Page_Up):
                    prev_btn.emit("clicked")
                    return True
                if ctrl and kv in (Gdk.KEY_plus, Gdk.KEY_equal, Gdk.KEY_KP_Add):
                    zoom_in.emit("clicked")
                    return True
                if ctrl and kv in (Gdk.KEY_minus, Gdk.KEY_KP_Subtract):
                    zoom_out.emit("clicked")
                    return True
                if ctrl and kv == Gdk.KEY_0:
                    _actual_size()
                    return True
                if ctrl and kv == Gdk.KEY_s:
                    _save_annotations()
                    return True
                if ctrl and kv == Gdk.KEY_z:
                    if st & Gdk.ModifierType.SHIFT_MASK:
                        _redo()
                    else:
                        _undo()
                    return True
                if ctrl and kv == Gdk.KEY_y:
                    _redo()
                    return True
                if kv == Gdk.KEY_z:
                    _undo()
                    return True
                if kv == Gdk.KEY_y:
                    _redo()
                    return True
                if kv == Gdk.KEY_1:
                    _set_tool("pen")
                    return True
                if kv == Gdk.KEY_2:
                    _set_tool("high")
                    return True
                if kv == Gdk.KEY_3:
                    _set_tool("erase")
                    return True
        except Exception:
            pass
        return False

    def _on_key(_w, ev):
        return _handle_key(ev.keyval, ev.state)

    win.connect("key-press-event", _on_key)
    for _kw in [canvas, img_scroll, floatbar, *floatbar.get_children()]:
        _kw.connect("key-press-event", _on_key)

    back_btn.connect("clicked", _on_back_clicked)

    def _get_current_lockout_info():
        nonlocal end_ts
        cur_end = max(float(end_ts or 0), _load_suspend_state())
        schedule = _load_lockout_schedule(cur_end)
        stage_seconds = None
        extra_days = None
        can_extend = False
        if schedule:
            stage = int(schedule.get("stage", 0))
            segments = schedule.get("segments", [])
            if 0 <= stage < len(segments):
                stage_seconds = int(segments[stage])
                can_extend = len(segments) <= stage + 1
                if stage_seconds in (3 * 86400, 7 * 86400):
                    extra_days = 3 if stage_seconds == 7 * 86400 else 7
        return cur_end, schedule, stage_seconds, extra_days, can_extend

    def _update_extend_btn():
        cur_end, schedule, stage_seconds, extra_days, can_extend = _get_current_lockout_info()
        now = time.time()
        if cur_end > now:
            if stage_seconds in (3 * 86400, 7 * 86400):
                extend_btn.set_label(f"➕ Extend (+{extra_days}d)")
                extend_btn.set_sensitive(can_extend)
                if can_extend:
                    extend_btn.set_tooltip_text(f"Extend lockout by {extra_days} days (Rule: 3d ↔ 7d)")
                else:
                    extend_btn.set_tooltip_text("Already extended for this cycle")
            else:
                extend_btn.set_label("➕ Extend (+3d/7d)")
                extend_btn.set_sensitive(True)
                extend_btn.set_tooltip_text("Extend lockout by 3 days or 7 days")
        else:
            extend_btn.set_label("➕ Extend (3d/7d)")
            extend_btn.set_sensitive(True)
            extend_btn.set_tooltip_text("Start or extend lockout by 3 days or 7 days")

    def _on_extend_clicked(*_):
        global suspend_until
        nonlocal end_ts
        cur_end, schedule, stage_seconds, extra_days, can_extend = _get_current_lockout_info()
        now = time.time()

        if cur_end > now and stage_seconds in (3 * 86400, 7 * 86400):
            if not can_extend:
                notify("Lockout has already been extended for this cycle.")
                return
            extra_sec = extra_days * 86400
            dlg = Gtk.MessageDialog(
                transient_for=win, modal=True, message_type=Gtk.MessageType.QUESTION,
                buttons=Gtk.ButtonsType.OK_CANCEL,
                text=f"Extend Lockout by {extra_days} Days?"
            )
            dlg.set_keep_above(True)
            dlg.set_position(Gtk.WindowPosition.CENTER_ON_PARENT)
            dlg.format_secondary_text(
                f"Current stage is {stage_seconds // 86400} days.\n"
                f"Policy rule extends by {extra_days} days.\n"
                f"Device unlock countdown will be adjusted automatically."
            )
            resp = dlg.run()
            dlg.destroy()
            if resp != Gtk.ResponseType.OK:
                return

            if schedule is None:
                schedule = {"segments": [stage_seconds], "stage": 0,
                            "stage_start": time.time(), "origin_start": time.time()}
            schedule["segments"].append(extra_sec)
            _save_lockout_schedule(schedule)
            new_end = _schedule_end(schedule)
            _save_suspend_state(new_end)
            suspend_until = new_end
            end_ts = new_end
            notify(f"Lockout extended by {extra_days} days.")
            _update_extend_btn()
            _tick()
        else:
            dlg = Gtk.Dialog(
                title="Extend Lockout Time", transient_for=win, modal=True
            )
            dlg.set_keep_above(True)
            dlg.set_position(Gtk.WindowPosition.CENTER_ON_PARENT)
            dlg.set_default_size(360, 160)
            c_area = dlg.get_content_area()
            c_area.set_spacing(12)
            c_area.set_border_width(16)

            lbl = Gtk.Label(label="Choose lockout extension duration:\n(Device stays locked in study/emergency mode)")
            lbl.set_line_wrap(True)
            lbl.set_halign(Gtk.Align.CENTER)
            c_area.pack_start(lbl, False, False, 0)

            btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            btn_box.set_halign(Gtk.Align.CENTER)
            b3 = Gtk.Button(label="➕ 3 Days")
            b7 = Gtk.Button(label="➕ 7 Days")
            b_cancel = Gtk.Button(label="Cancel")

            b3.get_style_context().add_class("topbar-btn")
            b3.get_style_context().add_class("extend-btn")
            b7.get_style_context().add_class("topbar-btn")
            b7.get_style_context().add_class("extend-btn")
            b_cancel.get_style_context().add_class("topbar-btn")

            b3.connect("clicked", lambda *_: dlg.response(3))
            b7.connect("clicked", lambda *_: dlg.response(7))
            b_cancel.connect("clicked", lambda *_: dlg.response(Gtk.ResponseType.CANCEL))

            btn_box.pack_start(b3, False, False, 0)
            btn_box.pack_start(b7, False, False, 0)
            btn_box.pack_start(b_cancel, False, False, 0)
            c_area.pack_start(btn_box, True, True, 0)

            dlg.show_all()
            resp = dlg.run()
            dlg.destroy()

            if resp in (3, 7):
                chosen_days = resp
                extra_sec = chosen_days * 86400
                if schedule is None or cur_end <= now:
                    now_ts = time.time()
                    schedule = {"segments": [extra_sec], "stage": 0,
                                "stage_start": now_ts, "origin_start": now_ts}
                else:
                    schedule["segments"].append(extra_sec)
                _save_lockout_schedule(schedule)
                new_end = _schedule_end(schedule)
                _save_suspend_state(new_end, mode="active")
                suspend_until = new_end
                end_ts = new_end
                notify(f"Lockout extended by {chosen_days} days.")
                _update_extend_btn()
                _tick()

    extend_btn.connect("clicked", _on_extend_clicked)

    def _tick():
        _touch_study_active()
        if _is_study_suspended():
            _trigger_study_suspension()
            return False
        _update_block_counter()
        _update_extend_btn()
        clock_lbl.set_text(time.strftime("🕒 %I:%M:%S %p"))
        clock_lbl.set_tooltip_text(time.strftime("%A, %d %B %Y"))
        nonlocal end_ts
        cur_end = max(float(end_ts or 0), _load_suspend_state())
        now = time.time()
        ctx = time_lbl.get_style_context()
        if cur_end > now:
            left = max(0, int(cur_end - now))
            d, rem = divmod(left, 86400)
            h, rem = divmod(rem, 3600)
            m, s = divmod(rem, 60)
            time_lbl.set_text(f"⏳ {d}d {h:02d}:{m:02d}:{s:02d} left" if d
                              else f"⏳ {h:02d}:{m:02d}:{s:02d} left")
            ctx.remove_class("topbar-timer-normal")
            ctx.add_class("topbar-timer-lockout")
        else:
            next_alert = _load_next_alert()
            if next_alert <= now or next_alert > now + FOCUS_MINUTES * 60 + 60:
                next_alert = now + FOCUS_MINUTES * 60
                _save_next_alert(next_alert)
            left = max(0, int(next_alert - now))
            m, s = divmod(left, 60)
            time_lbl.set_text(f"⏳ {m:02d}:{s:02d} left")
            ctx.remove_class("topbar-timer-lockout")
            ctx.add_class("topbar-timer-normal")
        time_lbl.show()
        return True

    _tick()
    GLib.timeout_add_seconds(1, _tick)

    # start on the bismillah home page (no auto-load of a link)
    stack.set_visible_child_name("home")

    _study_sigs = _lockout_exe_signatures()
    _lockout_proc_sweep(_study_sigs)
    _study_sweep = GLib.timeout_add_seconds(
        1, lambda: (_lockout_proc_sweep(_study_sigs), True)[1])

    def _on_destroy(*_a):
        global _study_win, _study_parent
        global _study_auto_closing
        global _study_block_count_updater
        global EXTERNAL_BROWSER_ACTIVE
        _study_block_count_updater = None
        EXTERNAL_BROWSER_ACTIVE = False
        _clear_study_active()
        _clear_study_starting()
        if _study_sweep:
            try:
                GLib.source_remove(_study_sweep)
            except Exception:
                pass
        if download_context is not None and download_handler_id:
            try:
                download_context.disconnect(download_handler_id)
            except Exception:
                pass
        for source_id in (guard_id, battery_timer,
                          recent_hide_state.get("id", 0),
                          edge_watch.get("id", 0)):
            try:
                if source_id:
                    GLib.source_remove(source_id)
            except Exception:
                pass
        auto = _study_auto_closing
        if state.get("path") and str(state["path"]).lower().endswith(".pdf"):
            _save_reading_page(state["path"], state["page"])
        _study_win = None
        if not auto and _study_parent is not None:
            try:
                _study_parent.show()
                _study_parent.present()
            except Exception:
                pass
        _study_parent = None
        _study_auto_closing = False
        Gtk.main_quit()

    win.connect("destroy", _on_destroy)
    # Do not release the Shell lockout while the Study window is only being
    # constructed. The Shell accepts this handoff only after the window maps.
    def _on_study_mapped(*_a):
        _touch_study_active()
        _clear_study_starting()
        return False
    win.connect("map-event", _on_study_mapped)
    win.show_all()
    try:
        win.present_with_time(int(time.time()))
    except Exception:
        win.present()
    win.grab_focus()
    while Gtk.events_pending():
        Gtk.main_iteration_do(False)
    Gtk.main()
    # Lockout screen is maintained by GNOME Shell extension overlay. Clean exit.


def show_study_or_typing(parent, end_ts):
    show_study_window(parent=parent, end_ts=end_ts)


# ---------- main loop ----------

def main():
    # Single instance: never run twice (no duplicate alerts/ledgers).
    os.makedirs(LEDGER_DIR, exist_ok=True)
    _lock_fh = open(os.path.join(LEDGER_DIR, "instance.lock"), "w")
    try:
        fcntl.flock(_lock_fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print("Another instance is already running — exiting.", flush=True)
        raise SystemExit(0)
    print("Focus Reminder chalu. Automatic reminder off; lockout + Study mode active.", flush=True)
    tr = start_tracker()

    def _bye(*_):
        try:
            tr.stop_event.set()
            tr.flush()
        except Exception:
            pass
        # Never leave systemd/GNOME waiting on a nested GTK loop: a stop request
        # used to hang for 10s and then get SIGKILLed ("force quit" prompt).
        os._exit(0)

    signal.signal(signal.SIGTERM, _bye)
    signal.signal(signal.SIGINT, _bye)
    # Python signal handlers cannot run while the main thread sits inside the C
    # Gtk.main() loop (study/typing/lockout), which made systemd SIGKILL us
    # after 10s and show the "force quit" prompt. This lightweight GTK
    # heartbeat gives CPython a chance to run the pending handler every 200ms.
    try:
        GLib.timeout_add(200, lambda: True)
    except Exception as e:
        print(f"signal heartbeat unavailable: {e}", flush=True)
    global suspend_until
    suspend_until = 0
    pending = max(_restore_suspend_checkpoint(), _consume_pam_lock_flag())
    if pending > time.time():
        print("Unfinished suspension found — enforcing until countdown ends.", flush=True)
        enforce_suspension_until(pending)
    else:
        _clear_suspend_state()
        _gnome_heal()  # no lockout active: undo any stale shell lockdown
        _systemd_startup_ready()
    # The automatic 10-minute fullscreen reminder was removed by request: after
    # a lockout ends there must be no second timer screen. The lockout screen,
    # Study Mode and the manual tray reminder remain available.
    _sigs = _lockout_exe_signatures()
    while True:
        while time.time() < suspend_until or _load_suspend_state() > time.time():
            _lockout_proc_sweep(_sigs)
            time.sleep(0.5)
        if tr.limit_pending:
            tr.limit_pending = False
            notify(f"Daily waste limit ({DAILY_WASTE_LIMIT_MIN}m) exceeded!")
            print("Daily waste limit exceeded — notification sent.", flush=True)
        time.sleep(1)

def show_now_once():
    """One-shot reminder (app-menu entry). Full actions, no tracker, no locks."""
    while True:
        try:
            action = show_alert()
        except Exception as e:
            print(f"show-now error: {e}", flush=True)
            return
        print(f"show-now action={action}", flush=True)
        if action == "suspend":
            do_suspend(_take_chosen_minutes())
        elif action == "study":
            show_study_window()
        elif action == "poweroff":
            power_off()
            return
        elif action == "goal":
            try:
                show_goal_manager()
            except Exception as e:
                print(f"goal manager error: {e}", flush=True)
        else:
            return


def connect_wifi_cli(ssid, password=None):
    if not ssid:
        print("ERROR: SSID required", flush=True)
        sys.exit(1)

    try:
        res = subprocess.run(['nmcli', '-t', '-f', 'NAME,TYPE', 'connection', 'show'],
                             capture_output=True, text=True, timeout=5)
        existing_wifi = set()
        for line in res.stdout.strip().splitlines():
            parts = line.split(':')
            if len(parts) >= 2 and parts[1] == '802-11-wireless':
                existing_wifi.add(parts[0])
    except Exception:
        existing_wifi = set()

    if ssid in existing_wifi:
        if password:
            subprocess.run([
                'nmcli', 'connection', 'modify', ssid,
                'wifi-sec.key-mgmt', 'wpa-psk',
                'wifi-sec.psk', password
            ], capture_output=True, text=True, timeout=5)
        up = subprocess.run(['nmcli', 'connection', 'up', 'id', ssid],
                            capture_output=True, text=True, timeout=15)
        if up.returncode == 0:
            print(f"SUCCESS: Connected to {ssid}", flush=True)
            sys.exit(0)
        if not password:
            print("ERROR: Saved connection failed or requires password.", flush=True)
            sys.exit(1)

    cmd = ['nmcli', 'dev', 'wifi', 'connect', ssid]
    if password:
        cmd.extend(['password', password])
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    if proc.returncode == 0:
        print(f"SUCCESS: Connected to {ssid}", flush=True)
        sys.exit(0)
    else:
        err = (proc.stderr or proc.stdout or "Connection failed").strip()
        print(f"ERROR: {err}", flush=True)
        sys.exit(1)


if __name__ == "__main__":
    import sys
    if "--show-upload-password" in sys.argv:
        print(_ensure_phone_upload_password(), flush=True)
    elif "--connect-wifi" in sys.argv:
        idx = sys.argv.index("--connect-wifi")
        ssid = sys.argv[idx + 1] if len(sys.argv) > idx + 1 else ""
        password = sys.argv[idx + 2] if len(sys.argv) > idx + 2 else None
        connect_wifi_cli(ssid, password)
        sys.exit(0)
    elif "--restore-desktop-panels" in sys.argv:
        if _load_suspend_state() > time.time():
            print("Lockout is currently active. Panels remain locked down until countdown ends.", flush=True)
            sys.exit(1)
        _gnome_heal()
        print("Desktop Top Bar and Dock restored successfully.", flush=True)
        sys.exit(0)
    elif "--lockout" in sys.argv:
        # One-shot pseudo lockout: locks now, stays on, no sleep.
        _mins = SUSPEND_MINUTES
        _idx = sys.argv.index("--lockout")
        if len(sys.argv) > _idx + 1:
            try:
                _mins = max(1, min(24 * 60, int(sys.argv[_idx + 1])))
            except ValueError:
                pass
        # Only one CLI lockout loop may run at a time. A second launch must not
        # create another countdown after the first one finishes.
        try:
            os.makedirs(LEDGER_DIR, exist_ok=True)
            _lockout_lock_fp = open(
                os.path.join(LEDGER_DIR, "lockout.lock"), "w")
            fcntl.flock(_lockout_lock_fp, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            print("Another lockout is already running; not starting a "
                  "second countdown.", flush=True)
            sys.exit(0)
        while not _has_display() or not _gtk_display_ready():
            print("Lockout waiting for display…", flush=True)
            time.sleep(0.5)
        do_pseudo_lockout(_mins)
    elif "--show-now" in sys.argv:
        while not _has_display() or not _gtk_display_ready():
            print("Show-now waiting for display…", flush=True)
            time.sleep(0.5)
        show_now_once()
    elif "--study" in sys.argv:
        # Raise the Shell lockdown before waiting for the display/GTK startup,
        # otherwise the desktop is interactive during that delay and can be
        # right-clicked -> Settings -> Extensions to disable the lockout.
        if not _is_study_suspended():
            _touch_study_starting()
            _ensure_shell_extension_enabled(force=True)
        while not _has_display() or not _gtk_display_ready():
            time.sleep(0.02)
        if _is_study_suspended():
            _clear_study_active()
            _clear_study_starting()
            until = _get_study_suspended_until()
            rem_m = max(1, int(math.ceil((until - time.time()) / 60.0)))
            notify(f"Study Mode is temporarily suspended ({rem_m}m remaining).")
            sys.exit(0)
        try:
            show_study_window()
        finally:
            _clear_study_active()
            _clear_study_starting()
        sys.exit(0)
    elif "--wifi" in sys.argv:
        _touch_wifi_active()
        while not _has_display() or not _gtk_display_ready():
            time.sleep(0.02)
        try:
            show_wifi_dialog()
        finally:
            _clear_wifi_active()
        sys.exit(0)
    elif "--tray" in sys.argv or "--emergency-button" in sys.argv:
        # single instance for the tray process too (separate lock from main)
        try:
            os.makedirs(LEDGER_DIR, exist_ok=True)
            _tray_fh = open(os.path.join(LEDGER_DIR, "tray.lock"), "w")
            fcntl.flock(_tray_fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            print("Tray already running — exiting.", flush=True)
            raise SystemExit(0)
        tray_loop()
    else:
        main()
